from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    return render(request, 'app1/index.html')

def contact(request):
    return render(request, 'app1/contact.html')

def search(request):
    return render(request, 'app1/search.html')

def productview(request):
    return render(request, 'app1/productview.html')

def about(request):
    return render(request, 'app1/about.html')

def checkout(request):
    return render(request, 'app1/checkout.html')
