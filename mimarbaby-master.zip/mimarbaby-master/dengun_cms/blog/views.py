# Create your views here.
from django.shortcuts import Http404
from django.template.response import TemplateResponse
from django.core.exceptions import ObjectDoesNotExist

from dengun_cms.core.models import Tag
from dengun_cms.blog.models import Article, Archive
from dengun_webshop.products.models import SlugMapper
from django.utils.timezone import now
from django.db.models import Q

from django.db.models import Count
import itertools
import operator


def blog(request):
    articles = Article.objects.select_related('author',
                                              'author__user',
                                              'author__image',
                                              'archive').published().exclude(Q(slug__isnull=True) | Q(slug__exact=''))

    context = {
        'articles': articles,
        'archives': Archive.objects.all(),
        'is_excerpt': True,
        'is_blog': True
    }
    return TemplateResponse(request, 'blog/index.html', context)


def archive(request, slug):

    try:
        archive = Archive.objects.get(slug__exact=slug)
    except:
        raise Http404()

    articles = Article.objects.select_related('author',
                                              'author__user',
                                              'author__image',
                                              'archive').published().filter(archive=archive).exclude(Q(slug__isnull=True) | Q(slug__exact=''))

    context = {
        'articles': articles,
        'archive': archive,
        'archives': Archive.objects.all(),
        'is_excerpt': True,
        'is_blog': True
    }

    return TemplateResponse(request, 'blog/index.html', context)


def article(request, slug):

    try:
        try:
            slugmapper = SlugMapper.objects.get(slug_key=slug)
            article = Article.objects.select_related('author',
                                            'author__user',
                                            'author__image',
                                            'archive').get(slug__exact=slugmapper.slug_value)
        except: 
            article = Article.objects.select_related('author',
                                             'author__user',
                                             'author__image',
                                             'archive').get(slug__exact=slug)
    except Article.DoesNotExist:
        raise Http404()

    if article.publication_date > now() and not request.user.is_staff:
        raise Http404()

    if not article.is_active and not request.user.is_staff:
        raise Http404()

    context = {
        'article': article,
        'archives': Archive.objects.all(),
        'is_blog': True
    }

    return TemplateResponse(request, 'blog/article.html', context)


def monthly(request, year, month=None):

    articles = Article.objects.select_related('author',
                                              'author__user',
                                              'author__image',
                                              'archive').published().by_date(year, month).exclude(Q(slug__isnull=True) | Q(slug__exact=''))

    current_blog = {
        'year': int(year) if year else None,
        'month': int(month) if month else None
    }
    context = {
        'articles': articles,
        'archives': Archive.objects.all(),
        'is_excerpt': True,
        'is_blog': True,
        'current_blog': current_blog
    }
    return TemplateResponse(request, 'blog/index.html', context)


def monthly_page(request, year=None, month=None):
    # TODO: correct this page, if needed

    yearMonthList = {}
    month_query = "MONTH(publication_date)"
    year_query = "YEAR(publication_date)"
    yearMonths = Article.objects.extra(select={'publ_year': year_query}).values('publ_year').annotate(total=Count('pk'))
    for key, items in itertools.groupby(yearMonths, operator.itemgetter('publ_year')):
        # print key
        yearMonthList[str(key)] = []
        for item in items:
            yearMonthList[key].append({
                'month': curDT.replace(month=item['publ_month']).strftime('%B'),
                # 'count': item['count'],
                'month_nr': str(item['publ_month'])
            })
    context = {
        'yearMonthList': yearMonthList,
    }

    return TemplateResponse(request, 'blog/monthly_page.html', context)


def tag(request, tag_slug=None):
    '''
    Index articles by tag
    :param tag_slug a slug related to the requested tag
    '''

    try:
        tag = Tag.objects.get(slug=tag_slug, name__isnull=False)
        articles = Article.objects.select_related('author',
                                              'author__user',
                                              'author__image',
                                              'archive').published().exclude(Q(slug__isnull=True) | Q(slug__exact='')).filter(tags=tag)
    except ObjectDoesNotExist:
        # no such tag
        tag = None
        articles = []

    context = {
        'articles': articles,
        'archives': Archive.objects.all(),
        'tag_current': tag,
        'current_tag': tag,
        'is_excerpt': True,
        'is_blog': True
    }
    # Marked for removal
    hierarchy = {
        'large': 10,
        'medium-large': 7,
        'medium': 5,
        'medium-small': 3,
        'small': 1
    }

    return TemplateResponse(request, 'blog/index.html', context)
