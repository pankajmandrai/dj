# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import mimarbaby.settings


class Migration(migrations.Migration):

    dependencies = [
        ('cms_blog', '0003_auto_20191118_0651'),
    ]

    operations = [
        migrations.AlterField(
            model_name='authorimage',
            name='image',
            field=models.ImageField(upload_to=mimarbaby.settings.image_file_namer, verbose_name='image'),
        ),
    ]
