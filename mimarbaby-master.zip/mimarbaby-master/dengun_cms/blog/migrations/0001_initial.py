# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import mimarbaby.settings
import dengun_cms.media.fields
import django.utils.timezone
from django.conf import settings
import dengun_cms.core.managers


class Migration(migrations.Migration):

    dependencies = [
        ('cms_media', '__first__'),
        ('cms', '__first__'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('photologue', '0008_auto_20150509_1557'),
        ('taggit', '0002_auto_20150616_2121'),
    ]

    operations = [
        migrations.CreateModel(
            name='Archive',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=50, verbose_name='Name', blank=True)),
                ('name_pt', models.CharField(max_length=50, null=True, verbose_name='Name', blank=True)),
                ('name_en', models.CharField(max_length=50, null=True, verbose_name='Name', blank=True)),
                ('name_es', models.CharField(max_length=50, null=True, verbose_name='Name', blank=True)),
                ('slug', models.SlugField(unique=True, verbose_name='Url / Handle')),
                ('slug_pt', models.SlugField(unique=True, null=True, verbose_name='Url / Handle')),
                ('slug_en', models.SlugField(unique=True, null=True, verbose_name='Url / Handle')),
                ('slug_es', models.SlugField(unique=True, null=True, verbose_name='Url / Handle')),
            ],
        ),
        migrations.CreateModel(
            name='Article',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('seo_title', models.CharField(help_text='Leave blank to use the default page title.', max_length=70, verbose_name='SEO Title', blank=True)),
                ('seo_title_pt', models.CharField(help_text='Leave blank to use the default page title.', max_length=70, null=True, verbose_name='SEO Title', blank=True)),
                ('seo_title_en', models.CharField(help_text='Leave blank to use the default page title.', max_length=70, null=True, verbose_name='SEO Title', blank=True)),
                ('seo_title_es', models.CharField(help_text='Leave blank to use the default page title.', max_length=70, null=True, verbose_name='SEO Title', blank=True)),
                ('seo_description', models.CharField(help_text='Leave blank to use the default page description.', max_length=155, verbose_name='SEO Description', blank=True)),
                ('seo_description_pt', models.CharField(help_text='Leave blank to use the default page description.', max_length=155, null=True, verbose_name='SEO Description', blank=True)),
                ('seo_description_en', models.CharField(help_text='Leave blank to use the default page description.', max_length=155, null=True, verbose_name='SEO Description', blank=True)),
                ('seo_description_es', models.CharField(help_text='Leave blank to use the default page description.', max_length=155, null=True, verbose_name='SEO Description', blank=True)),
                ('title', models.CharField(max_length=140, verbose_name='title')),
                ('title_pt', models.CharField(max_length=140, null=True, verbose_name='title')),
                ('title_en', models.CharField(max_length=140, null=True, verbose_name='title')),
                ('title_es', models.CharField(max_length=140, null=True, verbose_name='title')),
                ('excerpt', models.CharField(max_length=250, null=True, verbose_name='excerpt', blank=True)),
                ('excerpt_pt', models.CharField(max_length=250, null=True, verbose_name='excerpt', blank=True)),
                ('excerpt_en', models.CharField(max_length=250, null=True, verbose_name='excerpt', blank=True)),
                ('excerpt_es', models.CharField(max_length=250, null=True, verbose_name='excerpt', blank=True)),
                ('content', models.TextField(verbose_name='content')),
                ('content_pt', models.TextField(null=True, verbose_name='content')),
                ('content_en', models.TextField(null=True, verbose_name='content')),
                ('content_es', models.TextField(null=True, verbose_name='content')),
                ('slug', models.SlugField(null=True, blank=True, unique=True, verbose_name='Url / Handle')),
                ('slug_pt', models.SlugField(null=True, blank=True, unique=True, verbose_name='Url / Handle')),
                ('slug_en', models.SlugField(null=True, blank=True, unique=True, verbose_name='Url / Handle')),
                ('slug_es', models.SlugField(null=True, blank=True, unique=True, verbose_name='Url / Handle')),
                ('date_added', models.DateTimeField(auto_now_add=True)),
                ('publication_date', models.DateTimeField(default=django.utils.timezone.now, help_text='When the article should go live.', verbose_name='publication date', db_index=True)),
                ('is_active', models.BooleanField(default=True, help_text='Designates whether this article should be treated as active. Unselect this instead of deleting articles.', verbose_name='active')),
                ('is_featured', models.BooleanField(default=False, help_text='Designates whether this article should be treated as featured.', verbose_name='featured')),
                ('enable_comments', models.BooleanField(default=False, verbose_name='enable comments')),
                ('archive', models.ForeignKey(related_name='articles', blank=True, to='cms_blog.Archive', null=True)),
            ],
            options={
                'ordering': ['-publication_date'],
                'get_latest_by': 'publication_date',
            },
        ),
        migrations.CreateModel(
            name='Author',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('show_username', models.BooleanField(default=True, verbose_name='Show Username')),
                ('description', models.TextField(verbose_name='Description', blank=True)),
                ('description_pt', models.TextField(null=True, verbose_name='Description', blank=True)),
                ('description_en', models.TextField(null=True, verbose_name='Description', blank=True)),
                ('description_es', models.TextField(null=True, verbose_name='Description', blank=True)),
                ('website', models.URLField(verbose_name='Website', blank=True)),
                ('google', models.URLField(verbose_name='Google +', blank=True)),
                ('facebook', models.URLField(verbose_name='Facebook', blank=True)),
                ('twitter', models.URLField(verbose_name='Twitter', blank=True)),
                ('linkedin', models.URLField(verbose_name='Linkedin', blank=True)),
                ('user', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='AuthorImage',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('image', models.ImageField(upload_to=mimarbaby.settings.image_file_namer, verbose_name='image')),
                ('date_taken', models.DateTimeField(verbose_name='date taken', null=True, editable=False, blank=True)),
                ('view_count', models.PositiveIntegerField(default=0, verbose_name='view count', editable=False)),
                ('crop_from', models.CharField(default=b'center', max_length=10, verbose_name='crop from', blank=True, choices=[(b'top', 'Top'), (b'right', 'Right'), (b'bottom', 'Bottom'), (b'left', 'Left'), (b'center', 'Center (Default)')])),
                ('author', models.OneToOneField(related_name='image', to='cms_blog.Author')),
                ('effect', models.ForeignKey(related_name='authorimage_related', verbose_name='effect', blank=True, to='photologue.PhotoEffect', null=True)),
            ],
            options={
                'verbose_name': 'avatar',
                'verbose_name_plural': 'avatar',
            },
        ),
        migrations.AddField(
            model_name='article',
            name='author',
            field=models.ForeignKey(blank=True, to='cms_blog.Author', null=True),
        ),
        migrations.AddField(
            model_name='article',
            name='photos',
            field=dengun_cms.media.fields.MediaPhotoField(help_text=b'', related_name='article_photos', verbose_name='photos', to='cms_media.MediaPhoto', blank=True),
        ),
        migrations.AddField(
            model_name='article',
            name='tags',
            field=dengun_cms.core.managers.TaggableManager(to='cms.Tag', through='taggit.TaggedItem', blank=True, help_text='A comma-separated list of tags.', verbose_name='Tags'),
        ),
    ]
