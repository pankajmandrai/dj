from modeltranslation.translator import translator, TranslationOptions
from dengun_cms.blog.models import Archive, Author, Article

# BLOG TRANSLATIONS
class ArchiveTranslationOptions(TranslationOptions):
    fields = ('name','slug')
class AuthorTranslationOptions(TranslationOptions):
    fields = ('description',)
class ArticleTranslationOptions(TranslationOptions):
    fields = ('title','slug','excerpt','content','seo_title','seo_description')

translator.register(Archive, ArchiveTranslationOptions)
translator.register(Author, AuthorTranslationOptions)
translator.register(Article, ArticleTranslationOptions)