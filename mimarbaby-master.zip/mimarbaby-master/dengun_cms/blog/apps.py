from django.apps import AppConfig
from django.utils.translation import ugettext_lazy as _


class DengunCmsBlogConfig(AppConfig):
    name = 'dengun_cms.blog'
    label = "cms_blog"
    verbose_name = _("Blog")
