from django.conf.urls import *

urlpatterns = patterns('dengun_cms.blog.views',
    url(r'^$', 'blog', name="blog"),
    url(r'^(?P<year>\d{2,4})/(?P<month>\d{1,2})?/$', 'monthly', name="blog_monthly"),
    url(r'^(?P<year>\d{2,4})/$', 'monthly', name="blog_yearly"),
    #url(r'^dates-archive/$', 'monthly_page', name="blog_archive_dates"), # LIXO ?
    url(r'^archive/(?P<slug>.*)/$', 'archive', name="blog_archive"),
    url(r'^tag/(?P<tag_slug>.*)/$', 'tag', name="blog_tag"),
    url(r'^(?P<slug>.*)/$', 'article', name="blog_article"),
)
