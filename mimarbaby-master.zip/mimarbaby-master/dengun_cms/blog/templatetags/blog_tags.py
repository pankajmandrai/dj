from django import template
from django.utils.translation import ugettext_lazy as _
from django.utils.datastructures import SortedDict
from django.db.models import Q, Count

from django.core.exceptions import ObjectDoesNotExist

from classytags.core import Tag, Options
from classytags.arguments import Argument, MultiKeywordArgument

from dengun_cms.core.options import CmsInclusionTag
from dengun_cms.blog.forms import BlogLatestArticlesForm, BlogTagsForm, BlogMonthlyArticlesForm

import itertools
import operator
import datetime


register = template.Library()


class BlogLatestArticles(CmsInclusionTag):
    name = 'blog_latest_articles'
    template = 'cms/blog_latest_articles.html'

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    icon = 'file-text'
    form = BlogLatestArticlesForm
    verbose_name = _('Articles')
    app = _('Blog')

    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, options):
        from dengun_cms.blog.models import Article

        default_options = {
            'limit': 3,
            'offset': 0,
            'hide_date': False,
            'archive': None,
            'title': _("Latest Articles")
        }

        default_options.update(options or {})
        options = default_options

        articles = Article.objects.published().exclude(Q(slug__isnull=True) | Q(slug__exact=''))

        if default_options['archive']:
            articles = articles.filter(archive=default_options['archive'])

        context.update({
            'articles': articles[options['offset']:options['limit']],
            'options': options
        })

        return context


class BlogArchives(CmsInclusionTag):
    name = 'blog_archives'
    template = 'cms/blog_archives.html'

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    icon = 'archive'
    verbose_name = _('Archives')
    app = _('Blog')

    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, options):
        from dengun_cms.blog.models import Article, Archive

        default_options = {
            'title': _("Categories")
        }

        default_options.update(options or {})
        options = default_options

        archives = []
        archive_counter = Article.objects.values('archive').filter(archive__isnull=False).exclude(Q(slug__isnull=True) | Q(slug__exact='')).annotate(count=Count('archive'))
        for archive in Archive.objects.filter(pk__in=[o['archive'] for o in archive_counter]):
            archive.articles_count = max([c['count'] if c['archive'] == archive.pk else 0 for c in archive_counter])
            archives.append(archive)

        context.update({
            'archives': archives,
            'options': options
        })

        return context


class BlogMonthlyArticles(CmsInclusionTag):
    name = 'blog_monthly_articles'
    template = 'cms/blog_monthly_articles.html'

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    icon = 'calendar-o'
    form = BlogMonthlyArticlesForm
    verbose_name = _('Date Archives')
    app = _('Blog')

    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, options):
        from dengun_cms.blog.models import Article

        def compare_yearMonths(ym1, ym2):
            '''
            ## Compare yearMonths
            A helper function that compares two yearMonth items to see if they have the same year and month

            @param ym1 {Dictionary} A dictionary with month and year (both Integers)
            @param ym2 {Dictionary} Another dictionary with month and year
            @return {Boolean} True if both yearMonths have the same year and month. False otherwise
            '''
            return ym1['publ_month'] == ym2['publ_month'] and ym1['publ_year'] == ym2['publ_year']

        default_options = {
            'from_month': None,
            'to_month': None,
            'from_year': None,
            'to_year': None,
            'title': _("Archives")
        }

        default_options.update(options or {})
        options = default_options

        fromDate = toDate = None
        # yearMonths vai suportar data minima e data maxima
        # a data Maxima eh EXCLUSIVE, pelo que sera do PRIMEIRO DIA do mes seguinte
        if options['from_year'] and options['from_year'] != "-1":
            if options['from_month'] and options['from_month'] != "-1":
                fromDate = datetime.datetime(year=int(options['from_year']), month=int(options['from_month']), day=1)
            else:
                fromDate = datetime.datetime(year=int(options['from_year']), month=1, day=1)

        if options['to_year'] and options['to_year'] != "-1":

            if options['to_month'] and options['to_month'] != "-1":
                if int(options['to_month']) == 12:
                    options['to_month'] = 1
                    options['to_year'] = int(options['to_year']) + 1
                else:
                    options['to_month'] = int(options['to_month']) + 1
                toDate = datetime.datetime(year=int(options['to_year']), month=options['to_month'], day=1)
            else:
                toDate = datetime.datetime(year=int(options['to_year']) - 1, month=12, day=31, hour=23, minute=59, second=59)

        _yearMonths = Article.objects.exclude(Q(slug__isnull=True) | Q(slug__exact='')).year_months(fromDate, toDate)

        # yearMonths = Article.objects.raw(' SELECT (MONTH(publication_date)) AS `publ_month`, (YEAR(publication_date)) AS `publ_year`, COUNT(`blog_article`.`id`) AS `count` FROM `blog_article` GROUP BY (MONTH(publication_date)), (YEAR(publication_date)) ORDER BY `publ_year` ASC, `publ_month` ASC;')
        # print yearMonths
        #curDT = datetime.datetime.now()

        '''
        @painatalman is using a dummy date which is used to extract date month name after replacing it.
        So, it has to include a day that is generic, like 1st. The year is arbitrary.
        TODO: Look for better alternative to find month name.
        '''
        curDT = datetime.datetime(2000, 1, 1)
        yearMonthDict = SortedDict()
        yearMonths = []

        # por motivos de um bug, a contagem de cada artigo ainda nao vem da base de dados
        for _yearMonth in _yearMonths:
            # is this a new yearMonth or not?
            wasRepeated = False
            for yearMonth_withCounter in yearMonths:

                # print "comparing " + str(_yearMonth) + " with " + str(yearMonth_withCounter)
                if compare_yearMonths(_yearMonth, yearMonth_withCounter):
                    # print "was the same"
                    wasRepeated = True
                    yearMonth_withCounter['count'] += 1
                    break
            # new yearMonth object, start with counter 0
            if not wasRepeated:
                _yearMonth['count'] = 1
                # print "adding " + str(_yearMonth)
                _yearMonth['publ_month'] = _yearMonth['publ_month']
                _yearMonth['publ_year'] = _yearMonth['publ_year']
                yearMonths.append(_yearMonth)

        for key, items in itertools.groupby(yearMonths, operator.itemgetter('publ_year')):
            yearMonthDict[int(key)] = []
            for item in items:
                # print item
                ymd_date = curDT.replace(month=int(item['publ_month']))
                yearMonthDict[int(key)].append({
                    'month': ymd_date.strftime('%B'),
                    'count': item['count'],  # para quando o count funcionar
                    'month_nr': int(item['publ_month']),
                    'month_date': ymd_date,  # para depois usar o |date e traduzir nome do mes usando um django template
                    'year': int(key)
                })
        context.update({
            'yearMonthList': yearMonthDict,
            'options': options
        })

        return context


class BlogLatestArticlesList(Tag):
    name = 'blog_latest_articles_list'
    options = Options(
        Argument('offset', required=False, resolve=False),
        Argument('limit', required=False, resolve=False),
        'as',
        Argument('varname', required=False, resolve=False)
    )

    def render_tag(self, context, offset, limit, varname):
        from dengun_cms.blog.models import Article
        output = Article.objects.published().exclude(Q(slug__isnull=True) | Q(slug__exact=''))[offset:limit]

        if varname:
            context[varname] = output
            return ''
        else:
            return output


class BlogTags(CmsInclusionTag):
    name = 'blog_tags'
    template = 'cms/blog_tags.html'
    form = BlogTagsForm

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    icon = 'tags'
    # form = BlogMonthlyArticlesForm
    verbose_name = _('Tags')
    app = _('Blog')

    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, options):
        from dengun_cms.blog.models import Article

        default_options = {
            'nr_tags': 0,
            'title': _("Tags"),
            'style': 'cloud',  # out of 'cloud', 'list' or any other future possibility
            'highlighting': 'size',
            'article_id': None,
            'language_filter': None
        }

        default_options.update(options or {})
        options = default_options

        language_filter = options['language_filter']

        # flag for specific articles
        specArticle = False
        no_tags = True
        try:
            if context['article'].id is not None:
                specArticle = True
                # TODO: not working for specific article?
                try:
                    # tags = Article.objects.get(id=options['article_id']).tags.filter(language_filter=language_filter)
                    tags = Article.objects.get(id=context['article'].id).tags.all()
                    no_tags = False
                except ObjectDoesNotExist:
                    # TODO: exception for non-existant article
                    specArticle = False
        except:
            pass

        if no_tags:
            tags = Article.objects.exclude(Q(slug__isnull=True) | Q(slug__exact='')).tag_count(language_filter=language_filter)

        if options['nr_tags'] > 0:
            tags = tags[:options['nr_tags']]

        if tags and not specArticle:
            wMax = tags.first()['count']
            wMin = tags.last()['count']
        elif tags:
            wMax = wMin = 1

        renderTags = []

        for tag in tags:
            if specArticle:
                renderTag = {
                    'name': tag.name,
                    'slug': tag.slug,
                    'count': 1
                }
            else:

                renderTag = {
                    'name': tag['tags__name' if not language_filter else 'tags__name_'+language_filter],
                    'slug': tag['tags__slug' if not language_filter else 'tags__slug_'+language_filter],
                    'count': tag['count']
                }

            count = int(renderTag['count'])
            if options['highlighting'] == 'size':
                if count == wMax:
                    renderTag['class'] = '-lg'
                if count < wMax * 0.8:
                    renderTag['class'] = '-md'
                if count < wMax * 0.6:
                    renderTag['class'] = '-sm'
                if count < wMax * 0.4:
                    renderTag['class'] = '-xs'
                if count < wMax * 0.2 or count == wMin:
                    renderTag['class'] = '-xs text-muted'
            else:
                renderTag['class'] = '-sm'

            renderTags.append(renderTag)

        context.update({
            'tags': renderTags,
            'options': options
        })

        return context

register.tag(BlogTags)
register.tag(BlogArchives)
register.tag(BlogLatestArticles)
register.tag(BlogMonthlyArticles)
register.tag(BlogLatestArticlesList)
