from django.utils.translation import ugettext_lazy as _
#from django import forms
from dengun_cms.appsettings import fields
from dengun_cms import appsettings

register = appsettings.register('blog', _('Blog'))


@register(main=True)
class GeralSettings:

    date_format = fields.CharField(translate=True, initial='F j, Y', label=_('Date Format'), help_text=_('How should dates be displayed across the website and control panel? Using the <a target="_blank" href="http://php.net/manual/en/function.date.php">date format</a> from PHP - OR - Using the format of <a target="_blank" href="http://php.net/manual/en/function.strftime.php">strings formatted as date</a> from PHP.'))
    records_per_page = fields.IntegerField(initial='25', label=_('Records Per Page'), help_text=_('How many records should we show per page in the admin section?'))

    class Meta:
        sorting = 1
        help_text = _('Allows administrators to update settings like Site Name, messages and email address, etc.')
        verbose_name = _('Geral Configuration')
        verbose_name_plural = _('Geral Configurations')

        fieldsets = (
            ('Blog Settings', {
                'classes': ('collapse',),
                'fields': ('date_format', 'records_per_page',),
                'description': 'some description'
            }),
        )
