from django import forms
from django.utils.translation import ugettext_lazy as _
from dengun_cms.blog.models import Article, Archive
from dengun_cms.core.forms import NULL_FIELD_CHOICES
from dengun_cms.core.widgets import VisibilityWidget
from django.utils.timezone import now

from django.conf import settings


GRID_CHOICES = (
    (12, '1'),
    (6, '2'),
    (4, '3'),
    (3, '4'),
    (2, '6'),
    (1, '12'),
)

BLOG_TAGS_STYLES_CHOICES = (
    ('cloud', _('cloud')),
    ('list', _('list'))
)

BLOG_TAGS_HIGHLIGHTING_CHOICES = (
    ('size', _('size')),
    (None, _('nothing'))
)


BLOG_FORM_TEMPLATE_CHOICES = (
    ('cms/blog_latest_articles.html', _('List')),
    ('cms/blog_latest_articles_horizontal.html', _('Grid')),
)


class BlogLatestArticlesForm(forms.Form):
    limit = forms.IntegerField(label=_("Limit"), required=False, initial=3)
    offset = forms.IntegerField(label=_("Offset"), required=False)
    hide_date = forms.ChoiceField(label=_("hide date"), choices=NULL_FIELD_CHOICES, required=False)
    title = forms.CharField(label=_("title"), required=False)
    archive = forms.ChoiceField(label=_("category"), choices=NULL_FIELD_CHOICES, required=False)
    template = forms.ChoiceField(label=_("template"), choices=BLOG_FORM_TEMPLATE_CHOICES, required=False)

    def __init__(self, *args, **kwargs):

        super(BlogLatestArticlesForm, self).__init__(*args, **kwargs)
        ARCHIVE_CHOICES = [(None, "All")] + [(archive.pk, archive.name) for archive in Archive.objects.all()]
        self.fields['archive'].choices = ARCHIVE_CHOICES


class BlogMonthlyArticlesForm(forms.Form):
    from_year = forms.ChoiceField(
        label=_("Year (from)"),
        choices=NULL_FIELD_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control input-sm'}))
    from_month = forms.ChoiceField(
        label=_("(month)"),
        choices=NULL_FIELD_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control input-sm'}))
    to_year = forms.ChoiceField(
        label=_("Year (to)"),
        choices=NULL_FIELD_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control input-sm'}))
    to_month = forms.ChoiceField(
        label=_("(month)"),
        choices=NULL_FIELD_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control input-sm'}))

    def __init__(self, *args, **kwargs):

        super(BlogMonthlyArticlesForm, self).__init__(*args, **kwargs)
        curDT = now()
        MONTH_CHOICES = [(-1, "All")] + [(int(month), curDT.replace(month=month).strftime('%B')) for month in range(1, 13)]
        YEAR_CHOICES = [(-1, "All")] + [(int(year['publ_year']), int(year['publ_year'])) for year in Article.objects.years(None)]

        self.fields['from_month'].choices = MONTH_CHOICES
        self.fields['to_month'].choices = MONTH_CHOICES
        self.fields['from_year'].choices = YEAR_CHOICES
        self.fields['to_year'].choices = YEAR_CHOICES


class BlogTagsForm(forms.Form):
    # form for blog_tags options
    title = forms.CharField(
        label=_("Title"),
        required=False
    )
    nr_tags = forms.IntegerField(
        label=_("Max. number of tags"),
        required=False
    )
    style = forms.ChoiceField(
        label=_("Style (display)"),
        choices=BLOG_TAGS_STYLES_CHOICES,
        required='cloud',
        widget=forms.Select(attrs={'class': 'form-control input-sm'}))
    highlighting = forms.ChoiceField(
        label=_("Highlighting of tags (unavailable in 'list' style)"),
        choices=BLOG_TAGS_HIGHLIGHTING_CHOICES,
        required='cloud',
        widget=forms.Select(attrs={'class': 'form-control input-sm'}))
    article_id = forms.IntegerField(
        label=_("Article id (optional, to show tags of a specific article)"),
        required=False
    )
    # TODO: add better description
    language_filter = forms.ChoiceField(
        label=_("Language filter abbr."),
        choices=((None, 'default'),) + settings.LANGUAGES,
        required=False
    )


class ArticleAdminForm(forms.ModelForm):
    class Meta:
        model = Article
        fields = "__all__"
        widgets = {
            'is_active': VisibilityWidget
        }

    def __init__(self, *args, **kwargs):
        super(ArticleAdminForm, self).__init__(*args, **kwargs)
        for lang in settings.LANGUAGES:
            field_lang = 'excerpt_' + lang[0].replace('-', '_')
            mt_field_lang = "mt-field-" + field_lang.replace('_', '-')
            self.fields[field_lang].widget = forms.Textarea(attrs={'rows': '4', 'class': "mt "+mt_field_lang, 'maxlength': self.fields[field_lang].max_length})
