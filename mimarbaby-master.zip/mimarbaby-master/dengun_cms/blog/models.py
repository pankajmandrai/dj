from django.db import models
# from django.contrib.auth.models import User
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from django.core.urlresolvers import reverse
from django.utils.encoding import python_2_unicode_compatible
from django.utils.timezone import now

from photologue.models import ImageModel
from dengun_cms.media.fields import MediaPhotoField
from dengun_cms.blog.managers import ArticleManager
from dengun_cms.core.managers import TaggableManager
from dengun_cms.core.models import AbstractSeoModel

from django.apps import apps

@python_2_unicode_compatible
class Author(models.Model):
    """ Blog Author """
    user = models.OneToOneField(settings.AUTH_USER_MODEL, limit_choices_to={'is_staff': True})
    show_user = models.BooleanField(_('Show Username'), default=True)
    description = models.TextField(_('Description'), blank=True)
    # SOCIAL PAGES URLS
    website = models.URLField(_('Website'), blank=True)
    google = models.URLField(_('Google +'), blank=True)
    facebook = models.URLField(_('Facebook'), blank=True)
    twitter = models.URLField(_('Twitter'), blank=True)
    linkedin = models.URLField(_('Linkedin'), blank=True)

    def get_cover(self):
        try:
            return self.image
        except:
            pass
        return None

    def get_thumbnail(self):
        image = self.get_cover()
        if image:
            return '<img src="%s">' % image.get_admin_thumbnail_url()
        return '<img src="/static/admin/images/no_thumb.png" width="60">'

    get_thumbnail.allow_tags = True
    get_thumbnail.short_description = _("thumbnail")

    def get_link(self):
        if self.google:
            return self.google
        elif self.facebook:
            return self.facebook
        elif self.twitter:
            return self.twitter
        elif self.linkedin:
            return self.linkedin
        return self.website

    get_link.short_description = _("social link")

    class Menu:
        icon = "fa-male"

    class Meta:
        app_label = "cms_blog"

    def __str__(self):
        if self.show_user or (not self.user.last_name and not self.user.first_name):
            return u"%s" % self.user.username
        else:
            return self.user.get_full_name()


@python_2_unicode_compatible
class AuthorImage(ImageModel):
    author = models.OneToOneField(Author, related_name='image')

    class Meta:
        app_label = "cms_blog"
        verbose_name = _("avatar")
        verbose_name_plural = _("avatar")

    def __str__(self):
        return ""


@python_2_unicode_compatible
class Archive(models.Model):
    """ Blog Archive """
    name = models.CharField(_('Name'), blank=True, max_length=50)
    slug = models.SlugField(_('Url / Handle'), unique=True)

    class Meta:
        app_label = "cms_blog"

    class Menu:
        icon = "fa-archive"

    @classmethod
    def get_base_url(cls):
        try:
            from django.contrib.sites.models import Site
            domain = "http://%s" % Site.objects.get_current().domain
        except:
            domain = "http://example.com"

        try:
            reverse_url = reverse('blog_archive', args=("",))
        except:
            reverse_url = "/"

        return domain + reverse_url

    @models.permalink
    def get_absolute_url(self):
        return ('blog_archive', [str(self.slug)])

    def get_article_count(self):
        return self.articles.count()

    def get_blogpage_count(self):
        return self.blogpages.count()

    def __str__(self):
        return self.name


@python_2_unicode_compatible
class Article(AbstractSeoModel):
    """ Blog entries """
    title = models.CharField(_('title'), max_length=140)
    excerpt = models.CharField(_('excerpt'), max_length=250, blank=True, null=True)
    content = models.TextField(_('content'))

    # # SEO STUFF
    # seo_title = models.CharField(_('SEO Title'), max_length=70, help_text=_("Leave blank to use the default page title."), blank=True)
    # seo_description = models.CharField(_('SEO Description'), max_length=155, help_text=_("Leave blank to use the default page description."), blank=True)

    slug = models.SlugField(_('Url / Handle'), unique=True, blank=True, null=True)
    # MEDIA
    photos = MediaPhotoField(verbose_name=_('photos'), related_name='article_photos', blank=True)
    # CATEGORIZE
    author = models.ForeignKey(Author, blank=True, null=True)
    archive = models.ForeignKey(Archive, blank=True, null=True, related_name='articles')
    tags = TaggableManager(blank=True)
    # VISIBILITY
    date_added = models.DateTimeField(auto_now_add=True, blank=True)
    publication_date = models.DateTimeField(_("publication date"), default=now, help_text=_('When the article should go live.'), db_index=True)
    is_active = models.BooleanField(_('active'), default=True, help_text=_("Designates whether this article should be treated as active. Unselect this instead of deleting articles."))
    is_featured = models.BooleanField(_('featured'), default=False, help_text=_("Designates whether this article should be treated as featured."))
    enable_comments = models.BooleanField(_('enable comments'), default=False)

    # MANAGERS
    objects = ArticleManager()

    def get_cover(self):
        try:
            return self.photos.all()[0:1][0]
        except:
            pass
        return None

    def get_thumbnail(self):
        image = self.get_cover()
        if image:
            return '<img src="%s">' % image.get_admin_thumbnail_url()
        return '<img src="/static/admin/images/no_thumb.png" width="60">'

    get_thumbnail.allow_tags = True
    get_thumbnail.short_description = _("thumbnail")

    @classmethod
    def get_base_url(cls):
        try:
            from django.contrib.sites.models import Site
            domain = "http://%s" % Site.objects.get_current().domain
        except:
            domain = "http://example.com"

        try:
            reverse_url = reverse('blog_article', args=("",))
        except:
            reverse_url = "/"

        return domain + reverse_url

    @models.permalink
    def get_absolute_url(self):
        return ('blog_article', [str(self.slug)])

    def save(self, *args, **kwargs):
        SlugMapper = apps.get_model('webshop_products', 'SlugMapper')
        super(Article, self).save(*args, **kwargs)
                
        if self.slug_en not in self.slugmapper_set.filter(language='en').values_list('slug_value',flat=True):
            if self.slug_en:
                if SlugMapper.objects.filter(slug_key=self.slug_en).exists() == False:
                    SlugMapper.objects.create(article=self,slug_key=self.slug_en,slug_value=self.slug_en, language='en')

        if self.slug_pt not in self.slugmapper_set.filter(language='pt').values_list('slug_value',flat=True):
            if self.slug_pt:
                if SlugMapper.objects.filter(slug_key=self.slug_pt).exists() == False:
                    SlugMapper.objects.create(article=self,slug_key=self.slug_pt,slug_value=self.slug_pt, language='pt')
        
        if self.slug_es not in self.slugmapper_set.filter(language='es').values_list('slug_value',flat=True):
            if self.slug_es:
                if SlugMapper.objects.filter(slug_key=self.slug_es).exists() == False:
                    SlugMapper.objects.create(article=self,slug_key=self.slug_es,slug_value=self.slug_es, language='es')

        for slugmapper in self.slugmapper_set.filter(language='en'):
            if slugmapper.slug_value != self.slug_en:
                slugmapper.slug_value = self.slug_en
                slugmapper.save()

        for slugmapper in self.slugmapper_set.filter(language='pt'):
            if slugmapper.slug_value != self.slug_pt:
                slugmapper.slug_value = self.slug_pt
                slugmapper.save()
        
        for slugmapper in self.slugmapper_set.filter(language='es'):
            if slugmapper.slug_value != self.slug_es:
                slugmapper.slug_value = self.slug_es
                slugmapper.save()        

    class Meta:
        app_label = "cms_blog"
        ordering = ['-publication_date']
        get_latest_by = 'publication_date'

    class Menu:
        icon = "fa-file-text"

    def __str__(self):
        return self.title
