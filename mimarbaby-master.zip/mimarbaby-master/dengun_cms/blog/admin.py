from django.utils.translation import ugettext_lazy as _
from django.db import models
from django.contrib import admin
from django.forms.widgets import Textarea
from django.conf import settings

from dengun_cms.blog.models import Author, Archive, Article, AuthorImage
from dengun_cms.blog.forms import ArticleAdminForm
from dengun_cms.media.admin import MediaImageInline
from dengun_cms.core.widgets import SlugWidget
from dengun_cms.core.fields import SlugField
# GET MODEL TRANSLATION
from dengun_cms.core.translator import TranslationAdmin
from dengun_cms.core.utils import get_publication_status

if 'dengun_cms.file' in settings.INSTALLED_APPS:
    class FileGalleryInline(admin.TabularInline):
        extra = 1
        model = Article.files.through
        verbose_name = _('Article File')
        verbose_name_plural = _('Article Files')


class AuthorImageInline(MediaImageInline):
    model = AuthorImage


class AuthorAdmin(TranslationAdmin):

    inlines = [
        AuthorImageInline,
    ]

    fieldsets = (
        (None, {
            'fields': ('user', 'description',),
            'description': _('Choose user and leave a simple description about this author.')
        }),
        (_('Social Media Links'), {
            'classes': ('collapse',),
            'fields': ('website', 'google', 'facebook', 'twitter', 'linkedin'),
            'description': _('Set up the social media connections for this author.')
        }),
        (_('Visibility'), {
            'classes': ('collapse',),
            'fields': ('show_user',),
            'description': _('Control whether this author can be seen on your frontend.')
        })
    )

    class Media:
        js = (
            '/static/js/force_jquery.js',
            '/static/js/tabbed_translation_fields.js'
        )
        css = {
            'screen': ('/static/css/tabbed_translation_fields.css',),
        }

    list_display = ('get_thumbnail', '__unicode__', 'get_link')
    list_display_links = ('get_thumbnail', '__unicode__',)
    search_fields = ('user__username', 'user__first_name', 'user__last_name',)


class ArchiveAdmin(TranslationAdmin):
    formfield_overrides = {
        models.SlugField: {'widget': SlugWidget(url=Archive)},
    }

    fieldsets = (
        (None, {
            'fields': ('name', 'slug',),
            'description': _('Archives are useful to categorize your articles.')
        }),
    )

    list_display = ('id', 'name')

    prepopulated_fields = {'slug': ('name',)}

    class Media:
        js = (
            '/static/js/force_jquery.js',
            '/static/js/tabbed_translation_fields.js',
        )
        css = {
            'screen': ('/static/css/tabbed_translation_fields.css',),
        }


class ArticleAdmin(TranslationAdmin):
    form = ArticleAdminForm

    formfield_overrides = {
        models.SlugField: {
            'form_class': SlugField,
            'widget': SlugWidget(url=Article)
        },
    }

    fieldsets = (
        (None, {
            'fields': ('title', 'excerpt', 'content', ('author', 'archive')),
            'description': _('Write a title and content, and if you wish you can choose an author or archive this article.')
        }),
        (_('Media'), {
            'classes': ('collapse',),
            'fields': ('photos',),
            'description': _('Upload or choose images for this article.')
        }),
        (_('Search Engine'), {
            'classes': ('collapse',),
            'fields': ('seo_title', 'seo_description', 'slug'),
            'description': _('Set up the page title, meta description and handle. These help define how this object shows up on search engines.')
        }),
        (_('Tags'), {
            'classes': ('collapse',),
            'fields': ('tags',),
            'description': _('Tags can be used to categorize your blog articles.')
        }),
        ('settings', {
            'classes': ('collapse',),
            'fields': ('is_featured', 'enable_comments',),
            'description': _('Manage the settings for this article.')
        }),
        (_('Visibility'), {
            'classes': ('collapse',),
            'fields': ('is_active', 'publication_date',),
            'description': _('Control whether this blog article can be seen on your frontend.')
        })
    )

    list_display = ('get_thumbnail', 'title', 'slug', 'author', 'archive', 'is_featured', get_publication_status)
    list_display_links = ('get_thumbnail', 'title', 'slug',)
    list_filter = ('publication_date', 'archive', 'enable_comments', 'is_active', 'author__user__username',)
    list_editable = ('is_featured',)
    search_fields = ('title', 'slug',)

    prepopulated_fields = {'slug': ('title',)}

    def get_inline_instances(self, request, obj=None):
        if 'dengun_cms.file' in settings.INSTALLED_APPS:
            self.inlines = [FileGalleryInline, ]
        return super(ArticleAdmin, self).get_inline_instances(request)

    class Media:
        js = (
            '/static/js/force_jquery.js',
            '/static/js/tabbed_translation_fields.js',
            '/static/ckeditor/ckeditor.js',
        )
        css = {
            'screen': ('/static/css/tabbed_translation_fields.css',),
        }


admin.site.register(Author, AuthorAdmin)
admin.site.register(Archive, ArchiveAdmin)
admin.site.register(Article, ArticleAdmin)
