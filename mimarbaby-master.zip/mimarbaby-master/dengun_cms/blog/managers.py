# -*- coding: utf-8 -*-
from django.db import models

from dengun_cms.blog.query import ArticleQuerySet


class ArticleManager(models.Manager):
    """Use draft() and public() methods for accessing the corresponding
    instances.
    """
    def search(self, term):
        return self.get_queryset().filter(title__icontains=term)

    def get_queryset(self):
        """Change standard model queryset to our own.
        """
        return ArticleQuerySet(self.model)

    def published(self):
        return self.get_queryset().published()

    def by_date(self, year=None, month=None):
        return self.get_queryset().by_date(year, month)

    def year_months(self, fromDate=None, toDate=None):
        return self.get_queryset().year_months(fromDate, toDate)

    def years(self, year=None):
        return self.get_queryset().years(year)

    def tag_count(self, language_filter=None, limit=20):
        return self.get_queryset().tag_count(language_filter, limit)
