from django.apps import AppConfig


class DengunCmsConfig(AppConfig):
    name = 'dengun_cms'
    verbose_name = "Dengun CMS"

    def __init__(self, *args, **kwargs):
        super(DengunCmsConfig, self).__init__(*args, **kwargs)
