from django.contrib import admin
from django.db import models
from django.utils.translation import ugettext_lazy as _
from dengun_cms.core.widgets import SlugWidget
from dengun_cms.core.translator import TranslationAdmin
from dengun_cms.core.utils import get_publication_status
from dengun_cms.blogpages.models import BlogPage, BlogPageImage, Author, BlogAuthorImage, Archive, ArchiveImage
from dengun_cms.blogpages.forms import ArticleAdminForm
from dengun_cms.media.admin import MediaImageInline
from dengun_cms.media.widgets import ImageWidget
from dengun_cms.mypages.admin import PageAbstractAdmin


# Stuff from the old blog
class AuthorImageInline(MediaImageInline):
    model = BlogAuthorImage


class AuthorAdmin(TranslationAdmin):

    inlines = [
        AuthorImageInline,
    ]

    fieldsets = (
        (None, {
            'fields': ('user', 'description',),
            'description': _('Choose user and leave a simple description about this author.')
        }),
        (_('Social Media Links'), {
            'classes': ('collapse',),
            'fields': ('website', 'google', 'facebook', 'twitter', 'linkedin'),
            'description': _('Set up the social media connections for this author.')
        }),
        (_('Visibility'), {
            'classes': ('collapse',),
            'fields': ('show_user',),
            'description': _('Control whether this author can be seen on your frontend.')
        })
    )

    class Media:
        js = (
            '/static/js/force_jquery.js',
            '/static/js/tabbed_translation_fields.js'
        )
        css = {
            'screen': ('/static/css/tabbed_translation_fields.css',),
        }

    list_display = ('get_thumbnail', '__unicode__', 'get_link')
    list_display_links = ('get_thumbnail', '__unicode__',)
    search_fields = ('user__username', 'user__first_name', 'user__last_name',)


class ArchiveImageInline(MediaImageInline):
    model = ArchiveImage


class ArchiveAdmin(TranslationAdmin):

    formfield_overrides = {
        models.SlugField: {'widget': SlugWidget(url=BlogPage)},
    }

    inlines = [
        ArchiveImageInline,
    ]

    fieldsets = (
        (None, {
            'fields': ('name', 'slug',),
            'description': _('Archives are useful to categorize your articles.')
        }),
    )

    list_display = ('get_thumbnail', '__unicode__', 'id')
    list_display_links = ('get_thumbnail', '__unicode__',)

    prepopulated_fields = {'slug': ('name',)}

    class Media:
        js = (
            '/static/js/force_jquery.js',
            '/static/js/tabbed_translation_fields.js',
        )
        css = {
            'screen': ('/static/css/tabbed_translation_fields.css',),
        }


class BlogPageImageInline(admin.StackedInline):
    model = BlogPageImage
    verbose_name = _('Thumbnail')
    verbose_name_plural = _('Thumbnail')
    fields = ['image', ]
    min_num = 0
    extra = 1
    formfield_overrides = {
        models.ImageField: {'widget': ImageWidget},
    }


class BlogPageAdmin(PageAbstractAdmin):

    form = ArticleAdminForm

    inlines = [
        BlogPageImageInline,
    ]

    formfield_overrides = {
        models.SlugField: {
            'form_class': models.SlugField,
            'widget': SlugWidget(url=BlogPage)
        },
    }

    add_form_template = "admin/blogpages_add_form.html"
    change_form_template = "admin/blogpages_change_form.html"

    fieldsets = (
        (None, {
            'fields': ('title', 'excerpt', ('archive', 'author')),
            'description': _('Write a title and an excerpt for this article, and if you wish you can choose an author.')
        }),
        (_('Search Engine'), {
            'fields': ('seo_title', 'seo_description', 'page_url'),
            'description': _('Set up the page title, meta description and handle. These help define how this object shows up on search engines.')
        }),
        (_('Tags'), {
            'classes': ('collapse', 'tags-fieldset'),
            'fields': ('tags',),
            'description': _('Tags can be used to categorize your blog articles.')
        }),
        ('settings', {
            'classes': ('collapse',),
            'fields': ('extend_template', 'registration_required', 'site'),
            'description': _('Manage the settings for this article.')
        }),
        (_('Visibility'), {
            'fields': ('is_featured', 'is_active', 'publication_date', 'publication_end_date'),
            'description': _('Control how this article can be seen on your frontend.')
        })
    )

    list_display = ('get_thumbnail', '__unicode__', 'id', 'is_featured', 'get_absolute_url', get_publication_status)
    list_filter = ('publication_date', 'registration_required', 'is_active',)
    list_editable = ('is_featured',)
    search_fields = ('title', 'page_url',)

    prepopulated_fields = {'page_url': ('title',)}
    filter_include_ancestors = True


admin.site.register(Author, AuthorAdmin)
admin.site.register(Archive, ArchiveAdmin)
admin.site.register(BlogPage, BlogPageAdmin)
