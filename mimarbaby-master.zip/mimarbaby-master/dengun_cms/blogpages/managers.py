# -*- coding: utf-8 -*-
from dengun_cms.mypages.managers import PageManager
from dengun_cms.blogpages.query import BlogPageQuerySet


class BlogPageManager(PageManager):
    """Use draft() and public() methods for accessing the corresponding
    instances.
    """
    def get_queryset(self):
        """Change standard model queryset to our own.
        """
        return BlogPageQuerySet(self.model)

    def published(self, site=None):
        return self.get_queryset().published(site=site)

    def search(self, term):
        return self.get_queryset().filter(title__icontains=term)

    def by_date(self, year=None, month=None):
        return self.get_queryset().by_date(year, month)

    def year_months(self, fromDate=None, toDate=None):
        return self.get_queryset().year_months(fromDate, toDate)

    def years(self, year=None):
        return self.get_queryset().years(year)

    def tag_count(self, language_filter=None, limit=20):
        return self.get_queryset().tag_count(language_filter, limit)
