from django import template
from django.core.exceptions import ObjectDoesNotExist
from django.db.models import Q, Count
from django.utils.datastructures import SortedDict
from django.utils.translation import ugettext_lazy as _

from dengun_cms.core.options import CmsInclusionTag
from dengun_cms.core.tags import GetModelTag, FilterModelDictTag
from dengun_cms.blogpages.forms import BlogLatestArticlesForm, BlogTagsForm, BlogMonthlyArticlesForm
from dengun_cms.blogpages.models import BlogPage, Archive

from classytags.core import Tag, Options
from classytags.arguments import Argument, MultiKeywordArgument

import itertools
import operator
import datetime

register = template.Library()


class GetBlogPageTag(GetModelTag):
    '''
    TODO: chances are there won't be needed
    '''
    name = 'get_blogpage'
    model = BlogPage


class FilterBlogPageTag(FilterModelDictTag):
    name = 'filter_blogpage'
    model = BlogPage


class BlogPageUrlTag(Tag):
    '''
    TODO: set this a a generic method
    '''
    name = 'blogpage_url'
    options = Options(
        Argument('object_id'),
    )

    def render_tag(self, context, object_id):
        try:
            page = BlogPage.objects.get(pk=object_id)
        except ObjectDoesNotExist:
            page = None

        if page:
            return page.get_absolute_url()
        else:
            return "#page-%s-not-found" % object_id


class BlogPageLinkTag(Tag):
    name = 'blogpage_link'
    options = Options(
        Argument('object_id'),
    )

    def render_tag(self, context, object_id):
        try:
            page = BlogPage.objects.get(pk=object_id)
        except ObjectDoesNotExist:
            page = None

        if page:
            return '<a href="%s">%s</a>' % (page.get_absolute_url(), page.title)
        else:
            return '<a href="#page-%s-not-found">Page %s not Found</a>' % (object_id, object_id)


class BlogPageLatestArticles(CmsInclusionTag):
    name = 'blogpage_latest_articles'
    # uses the same template as the default blog
    template = 'cms/blogpages_latest_articles.html'

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    icon = 'file-text'
    form = BlogLatestArticlesForm
    verbose_name = _('Articles')
    app = _('Blog')

    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, options):

        default_options = {
            'limit': 3,
            'offset': 0,
            'hide_date': False,
            'archive': None,
            'exclude': None,
            'title': _("Latest Articles")
        }

        default_options.update(options or {})
        options = default_options

        articles = BlogPage.objects.published().exclude(Q(page_url__isnull=True) | Q(page_url__exact=''))

        if default_options['exclude']:
            articles = articles.exclude(pk=default_options['exclude'])

        if default_options['archive']:
            articles = articles.filter(archive=default_options['archive'])

        context.update({
            'articles': articles[options['offset']:options['limit']],
            'options': options
        })

        return context


class BlogPageArchives(CmsInclusionTag):
    name = 'blogpage_archives'
    # uses the same template as the default blog
    template = 'cms/blogpages_archives.html'

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    icon = 'archive'
    verbose_name = _('Archives')
    app = _('Blog')

    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, options):

        default_options = {
            'title': _("Categories")
        }

        default_options.update(options or {})
        options = default_options

        archives = []
        archive_counter = BlogPage.objects.values('archive').filter(archive__isnull=False).exclude(Q(page_url__isnull=True) | Q(page_url__exact='')).annotate(count=Count('archive'))
        for archive in Archive.objects.filter(pk__in=[o['archive'] for o in archive_counter]):
            archive.articles_count = max([c['count'] if c['archive'] == archive.pk else 0 for c in archive_counter])
            archives.append(archive)

        context.update({
            'archives': archives,
            'options': options
        })

        return context


class BlogPageMonthlyArticles(CmsInclusionTag):
    name = 'blogpage_monthly_articles'
    template = 'cms/blogpages_monthly_articles.html'

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    icon = 'calendar-o'
    # for now, it uses the same form
    form = BlogMonthlyArticlesForm
    verbose_name = _('Date Archives')
    app = _('Blog')

    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, options):

        def compare_yearMonths(ym1, ym2):
            '''
            ## Compare yearMonths
            A helper function that compares two yearMonth items to see if they have the same year and month

            @param ym1 {Dictionary} A dictionary with month and year (both Integers)
            @param ym2 {Dictionary} Another dictionary with month and year
            @return {Boolean} True if both yearMonths have the same year and month. False otherwise
            '''
            return ym1['publ_month'] == ym2['publ_month'] and ym1['publ_year'] == ym2['publ_year']

        default_options = {
            'from_month': None,
            'to_month': None,
            'from_year': None,
            'to_year': None,
            'title': _("Archives")
        }

        default_options.update(options or {})
        options = default_options

        fromDate = toDate = None
        # yearMonths vai suportar data minima e data maxima
        # a data Maxima eh EXCLUSIVE, pelo que sera do PRIMEIRO DIA do mes seguinte
        if options['from_year'] and options['from_year'] != "-1":
            if options['from_month'] and options['from_month'] != "-1":
                fromDate = datetime.datetime(year=int(options['from_year']), month=int(options['from_month']), day=1)
            else:
                fromDate = datetime.datetime(year=int(options['from_year']), month=1, day=1)

        if options['to_year'] and options['to_year'] != "-1":

            if options['to_month'] and options['to_month'] != "-1":
                if int(options['to_month']) == 12:
                    options['to_month'] = 1
                    options['to_year'] = int(options['to_year']) + 1
                else:
                    options['to_month'] = int(options['to_month']) + 1
                toDate = datetime.datetime(year=int(options['to_year']), month=options['to_month'], day=1)
            else:
                toDate = datetime.datetime(year=int(options['to_year']) - 1, month=12, day=31, hour=23, minute=59, second=59)

        _yearMonths = BlogPage.objects.exclude(Q(page_url__isnull=True) | Q(page_url__exact='')).year_months(fromDate, toDate)

        # yearMonths = BlogPage.objects.raw(' SELECT (MONTH(publication_date)) AS `publ_month`, (YEAR(publication_date)) AS `publ_year`, COUNT(`blog_article`.`id`) AS `count` FROM `blog_article` GROUP BY (MONTH(publication_date)), (YEAR(publication_date)) ORDER BY `publ_year` ASC, `publ_month` ASC;')
        # print yearMonths
        # curDT = datetime.datetime.now()

        '''
        @painatalman is using a dummy date which is used to extract date month name after replacing it.
        So, it has to include a day that is generic, like 1st. The year is arbitrary.
        TODO: Look for better alternative to find month name.
        '''
        curDT = datetime.datetime(2000, 1, 1)
        yearMonthDict = SortedDict()
        yearMonths = []

        # por motivos de um bug, a contagem de cada artigo ainda nao vem da base de dados
        for _yearMonth in _yearMonths:
            # is this a new yearMonth or not?
            wasRepeated = False
            for yearMonth_withCounter in yearMonths:

                # print "comparing " + str(_yearMonth) + " with " + str(yearMonth_withCounter)
                if compare_yearMonths(_yearMonth, yearMonth_withCounter):
                    # print "was the same"
                    wasRepeated = True
                    yearMonth_withCounter['count'] += 1
                    break
            # new yearMonth object, start with counter 0
            if not wasRepeated:
                _yearMonth['count'] = 1
                # print "adding " + str(_yearMonth)
                _yearMonth['publ_month'] = _yearMonth['publ_month']
                _yearMonth['publ_year'] = _yearMonth['publ_year']
                yearMonths.append(_yearMonth)

        for key, items in itertools.groupby(yearMonths, operator.itemgetter('publ_year')):
            yearMonthDict[int(key)] = []
            for item in items:
                # print item
                ymd_date = curDT.replace(month=int(item['publ_month']))
                yearMonthDict[int(key)].append({
                    'month': ymd_date.strftime('%B'),
                    'count': item['count'],  # para quando o count funcionar
                    'month_nr': int(item['publ_month']),
                    'month_date': ymd_date,  # para depois usar o |date e traduzir nome do mes usando um django template
                    'year': int(key)
                })
        context.update({
            'yearMonthList': yearMonthDict,
            'options': options
        })

        return context


class BlogPageLatestArticlesList(Tag):
    name = 'blogpage_latest_articles_list'
    options = Options(
        Argument('offset', required=False, resolve=False),
        Argument('limit', required=False, resolve=False),
        'as',
        Argument('varname', required=False, resolve=False)
    )

    def render_tag(self, context, offset, limit, varname):

        output = BlogPage.objects.published().exclude(Q(page_url__isnull=True) | Q(page_url__exact=''))[offset:limit]

        if varname:
            context[varname] = output
            return ''
        else:
            return output


class BlogPageTags(CmsInclusionTag):
    name = 'blogpage_tags'
    # uses the same template as the default blog
    template = 'cms/blogpages_tags.html'
    form = BlogTagsForm

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    icon = 'tags'
    # form = BlogMonthlyArticlesForm
    verbose_name = _('Tags')
    app = _('Blog')

    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, options):

        default_options = {
            'nr_tags': 0,
            'title': _("Tags"),
            'style': 'cloud',  # out of 'cloud', 'list' or any other future possibility
            'highlighting': 'size',
            'article_id': None,
            'language_filter': None
        }

        default_options.update(options or {})
        options = default_options

        language_filter = options['language_filter']

        # flag for specific articles
        specArticle = False
        no_tags = True
        if options['article_id'] is not None:
            specArticle = True
            # TODO: not working for specific article?
            try:
                tags = BlogPage.objects.get(id=options['article_id']).tags.filter(language_filter=language_filter)
                no_tags = False
            except ObjectDoesNotExist:
                # TODO: exception for non-existant article
                specArticle = False

        if no_tags:
            tags = BlogPage.objects.exclude(Q(page_url__isnull=True) | Q(page_url__exact='')).tag_count(language_filter=language_filter)

        if options['nr_tags'] > 0:
            tags = tags[:options['nr_tags']]

        if tags and not specArticle:
            wMax = tags.first()['count']
            wMin = tags.last()['count']
        elif tags:
            wMax = wMin = 1

        renderTags = []

        for tag in tags:
            if specArticle:
                renderTag = {
                    'name': tag.name,
                    'slug': tag.slug,
                    'count': 1
                }
            else:

                renderTag = {
                    'name': tag['tags__name' if not language_filter else 'tags__name_'+language_filter],
                    'slug': tag['tags__slug' if not language_filter else 'tags__slug_'+language_filter],
                    'count': tag['count']
                }

            count = int(renderTag['count'])
            if options['highlighting'] == 'size':
                if count == wMax:
                    renderTag['class'] = '-lg'
                if count < wMax * 0.8:
                    renderTag['class'] = '-md'
                if count < wMax * 0.6:
                    renderTag['class'] = '-sm'
                if count < wMax * 0.4:
                    renderTag['class'] = '-xs'
                if count < wMax * 0.2 or count == wMin:
                    renderTag['class'] = '-xs text-muted'
            else:
                renderTag['class'] = '-sm'

            renderTags.append(renderTag)

        context.update({
            'tags': renderTags,
            'options': options
        })

        return context


class BlogPageSidebar(CmsInclusionTag):
    name = 'blogpage_sidebar'
    # uses the same template as the default blog
    template = 'blogpages/sidebar.html'

    icon = 'magic'
    verbose_name = _('Sidebar')
    app = _('Blog')

    def get_context(self, context):
        return context


class BlogPageBreadcrumbs(CmsInclusionTag):
    name = 'blogpage_breadcrumbs'
    # uses the same template as the default blog
    template = 'blogpages/breadcrumbs.html'

    icon = 'link'
    verbose_name = _('Breadcrumbs')
    app = _('Blog')

    def get_context(self, context):
        return context


register.tag(BlogPageTags)
register.tag(BlogPageArchives)
register.tag(BlogPageLatestArticles)
register.tag(BlogPageMonthlyArticles)
register.tag(BlogPageLatestArticlesList)
register.tag(BlogPageSidebar)
register.tag(BlogPageBreadcrumbs)

register.tag(GetBlogPageTag)
register.tag(FilterBlogPageTag)
register.tag(BlogPageUrlTag)
register.tag(BlogPageLinkTag)
