# -*- coding: utf-8 -*-
from django.db.models import Q
from django.conf import settings
from django.db.models import Count
from django.db.models.query import QuerySet
from django.utils import timezone

from dengun_cms.mypages.query import PageQuerySet


class ArticleQuerySet(QuerySet):

    '''
    Helper function to get database commands
    ---
    , with MySQL and PostgreSQL as possible string values
    The default value is "MySQL"

    + This function is marked as SHAME, for it is only compatible with MySQL and PostgreSQL and it depends on the backend database engine name
    '''
    def get_current_db_date_extraction_commands(self):
        current_db = "MySQL"
        date_extraction = {
            "MySQL": {
                'month': {'publ_month': "MONTH(publication_date)"},
                'year': {'publ_year': "YEAR(publication_date)"}
            },
            "PostgreSQL": {
                'month': {'publ_month': "EXTRACT(month FROM publication_date)"},
                'year': {'publ_year': "EXTRACT(year FROM publication_date)"}
            }
        }

        if settings.DATABASES['default']['ENGINE'] == 'django.contrib.gis.db.backends.postgis' or settings.DATABASES['default']['ENGINE'] == 'django.db.backends.postgresql_psycopg2':
            current_db = "PostgreSQL"

        return date_extraction[current_db]

    def published(self, language=None, site=None):
        pub = self.filter(is_active=True).filter(
            Q(publication_date__lte=timezone.now()) | Q(publication_date__isnull=True)
        )
        return pub

    def by_date(self, year=None, month=None):
        articles = self.filter(is_active=True)

        date_extraction = self.get_current_db_date_extraction_commands()

        if month is None:
            articles = articles.filter(
                publication_date__year=year)
        elif year is not None:
            # articles = articles.filter(
            #     publication_date__month=month,
            #     publication_date__year=year)
            where = '%(date_extraction_year)s = %(year)s AND %(date_extraction_month)s = %(month)s' % {'date_extraction_year': date_extraction['year']['publ_year'], 'year': year, 'date_extraction_month': date_extraction['month']['publ_month'],  'month': month}
            articles = articles.extra(where=[where])
        else:
            articles = articles.filter(
                publication_date__month=month)

        return articles.order_by('publication_date')

    def year_months(self, fromDate=None, toDate=None):

        curDT = timezone.now
        filteredArticles = self.filter(is_active=True, publication_date__lte=curDT)
        if fromDate:
            if toDate:
                filteredArticles = filteredArticles.filter(publication_date__gte=fromDate, publication_date__lt=toDate)
            else:
                filteredArticles = filteredArticles.filter(publication_date__gte=fromDate)
        elif toDate:
            filteredArticles = filteredArticles.filter(publication_date__lt=toDate)

        # com counter: dá bug em django
        # return filteredArticles.extra(select={'publ_month': "MONTH(publication_date)"}).extra(select={'publ_year': "YEAR(publication_date)"}).values("publ_year","publ_month").annotate(count=Count('pk')).order_by("publ_year","publ_month")
        # sem counter

        # SHAME: database-dependent
        # extract month and year is different in both postgre and mysql
        date_extraction = self.get_current_db_date_extraction_commands()

        return filteredArticles.extra(select=date_extraction['month']).extra(select=date_extraction['year']).annotate(count=Count('pk')).values("pk", "publ_year", "publ_month").order_by("-publ_year", "publ_month")

    def years(self, year=None):

        date_extraction = self.get_current_db_date_extraction_commands()
        return self.extra(select=date_extraction['year']).values("publ_year").annotate(count=Count('pk')).order_by("-publ_year")

    def tag_count(self, language_filter=None, limit=20):
        slug_value = 'slug'
        tag_name_value = 'tags__name'
        tag_slug_value = 'tags__slug'

        if language_filter:
            slug_value += '_'+language_filter
            tag_name_value += '_'+language_filter
            tag_slug_value += '_'+language_filter

        return self.filter(**{slug_value+'__isnull': False, tag_name_value+'__isnull': False, tag_slug_value+'__isnull': False}).values(tag_name_value, tag_slug_value).annotate(count=Count('pk')).order_by("-count")[:limit]


class BlogPageQuerySet(ArticleQuerySet, PageQuerySet):
    # overriding the slug value
    def tag_count(self, language_filter=None, limit=20):
        slug_value = 'page_url'
        tag_name_value = 'tags__name'
        tag_slug_value = 'tags__slug'

        if language_filter:
            slug_value += '_'+language_filter
            tag_name_value += '_'+language_filter
            tag_slug_value += '_'+language_filter

        return self.filter(**{slug_value+'__isnull': False, tag_name_value+'__isnull': False, tag_slug_value+'__isnull': False}).values(tag_name_value, tag_slug_value).annotate(count=Count('pk')).order_by("-count")[:limit]
