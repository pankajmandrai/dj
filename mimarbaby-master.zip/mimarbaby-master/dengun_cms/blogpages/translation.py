from modeltranslation.translator import translator, TranslationOptions

from dengun_cms.blogpages.models import BlogPage, Author, Archive


class ArchiveTranslationOptions(TranslationOptions):
    fields = ('name', 'slug')


class AuthorTranslationOptions(TranslationOptions):
    fields = ('description',)


class BlogPageTranslationOptions(TranslationOptions):
    fields = ('page_url', 'excerpt', 'title', 'seo_title', 'seo_description',)

translator.register(Archive, ArchiveTranslationOptions)
translator.register(Author, AuthorTranslationOptions)
translator.register(BlogPage, BlogPageTranslationOptions)
