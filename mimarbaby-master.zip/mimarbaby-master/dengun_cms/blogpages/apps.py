from django.apps import AppConfig
from django.utils.translation import ugettext_lazy as _


class DengunCmsBlogpagesConfig(AppConfig):
    name = 'dengun_cms.blogpages'
    label = "cms_blogpages"
    verbose_name = _("Blog pages")
