# -*- coding: utf-8 -*-
from django.conf import settings
from django.conf.urls import url

from dengun_cms.blogpages.views import article_view, list_view, year_monthly_view, archive_view, tag_view

if settings.APPEND_SLASH:
    regex = r'^(?P<url>[0-9A-Za-z-_.//]+)/$'
else:
    regex = r'^(?P<url>[0-9A-Za-z-_.//]+)$'

urlpatterns = []

urlpatterns.extend([
    url(r'^(?P<year>\d{2,4})/(?P<month>\d{1,2})?/$', year_monthly_view, name="monthly"),
    url(r'^(?P<year>\d{2,4})/$', year_monthly_view, name="yearly"),
    url(r'^archive/(?P<slug>.*)/$', archive_view, name="archive"),
    url(r'^tag/(?P<tag_slug>.*)/$', tag_view, name="tag"),
    url(r'^$', list_view, name='index'),
    url(regex, article_view, name='article'),
])
