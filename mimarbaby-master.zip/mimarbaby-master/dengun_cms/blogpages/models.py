from django.conf import settings
from django.contrib.auth.models import User
from django.contrib.sites.models import Site
from django.core.urlresolvers import reverse, NoReverseMatch
from django.db import models
from django.utils import translation
from django.utils.encoding import python_2_unicode_compatible
from django.utils.translation import ugettext_lazy as _

from dengun_cms.core.managers import TaggableManager
from dengun_cms.blogpages.managers import BlogPageManager
from dengun_cms.mypages.models import PageAbstract

from photologue.models import ImageModel


@python_2_unicode_compatible
class Author(models.Model):
    """ Blog Author """
    user = models.OneToOneField(settings.AUTH_USER_MODEL, limit_choices_to={'is_staff': True}, related_name="blogpage_author")
    show_user = models.BooleanField(_('Show Username'), default=True)
    description = models.TextField(_('Description'), blank=True)
    # SOCIAL PAGES URLS
    website = models.URLField(_('Website'), blank=True)
    google = models.URLField(_('Google +'), blank=True)
    facebook = models.URLField(_('Facebook'), blank=True)
    twitter = models.URLField(_('Twitter'), blank=True)
    linkedin = models.URLField(_('Linkedin'), blank=True)

    def get_cover(self):
        try:
            return self.image
        except:
            pass
        return None

    def get_thumbnail(self):
        image = self.get_cover()
        if image:
            return '<img src="%s">' % image.get_admin_thumbnail_url()
        return '<img src="/static/admin/images/no_thumb.png" width="60">'

    get_thumbnail.allow_tags = True
    get_thumbnail.short_description = _("thumbnail")

    def get_link(self):
        if self.google:
            return self.google
        elif self.facebook:
            return self.facebook
        elif self.twitter:
            return self.twitter
        elif self.linkedin:
            return self.linkedin
        return self.website

    get_link.short_description = _("social link")

    class Menu:
        icon = "fa-male"

    class Meta:
        app_label = "cms_blogpages"

    def __str__(self):
        if self.show_user or (not self.user.last_name and not self.user.first_name):
            return u"%s" % self.user.username
        else:
            return self.user.get_full_name()


@python_2_unicode_compatible
class BlogAuthorImage(ImageModel):
    author = models.OneToOneField(Author, related_name='image')

    class Meta:
        app_label = "cms_blogpages"
        verbose_name = _("avatar")
        verbose_name_plural = _("avatar")

    def __str__(self):
        return ""


@python_2_unicode_compatible
class Archive(models.Model):
    """ Blog Archive """
    name = models.CharField(_('Name'), blank=True, max_length=50)
    slug = models.SlugField(_('Url / Handle'), unique=True)

    def get_cover(self):
        try:
            return self.image
        except:
            pass
        return None

    def get_thumbnail(self):
        image = self.get_cover()
        if image:
            return '<img src="%s">' % image.get_admin_thumbnail_url()
        return '<img src="/static/admin/images/no_thumb.png" width="60">'

    get_thumbnail.allow_tags = True
    get_thumbnail.short_description = _("thumbnail")

    class Meta:
        app_label = "cms_blogpages"

    class Menu:
        icon = "fa-archive"

    @classmethod
    def get_base_url(cls):
        try:
            from django.contrib.sites.models import Site
            domain = "http://%s" % Site.objects.get_current().domain
        except:
            domain = "http://example.com"

        try:
            reverse_url = reverse('blog_archive', args=("",))
        except:
            reverse_url = "/"

        return domain + reverse_url

    @models.permalink
    def get_absolute_url(self):
        return ('blog_archive', [str(self.slug)])

    def get_article_count(self):
        return self.articles.count()

    def get_blogpage_count(self):
        return self.blogpages.count()

    def __str__(self):
        return self.name


@python_2_unicode_compatible
class ArchiveImage(ImageModel):
    archive = models.OneToOneField(Archive, related_name='image')

    class Meta:
        app_label = "cms_blogpages"
        verbose_name = _("image")
        verbose_name_plural = _("image")

    def __str__(self):
        return ""


@python_2_unicode_compatible
class BlogPage(PageAbstract):
    """ Blog entries, MyPages Style """
    excerpt = models.CharField(_('excerpt'), max_length=250, blank=True, null=True)
    # TODO: make this a hidden field, for Eventual SEO purposes
    # TODO: actual remove this and use some kind of elastic search solution
    search_content = models.TextField(
        _('content'),
    )
    # CATEGORIZE
    author = models.ForeignKey(Author, blank=True, null=True, related_name="blogpages")
    archive = models.ForeignKey(Archive, blank=True, null=True, related_name='blogpages')
    tags = TaggableManager(blank=True)
    is_featured = models.BooleanField(_('featured'), default=False, help_text=_("Designates whether this article should be treated as featured."))
    enable_comments = models.BooleanField(_('enable comments'), default=False)
    site = models.ForeignKey(Site, help_text=_('The site the page is accessible at.'), verbose_name=_("site"),
                             related_name='blogpages', default="1")

    # MANAGERS
    objects = BlogPageManager()

    def get_cover(self):
        try:
            return self.main_thumbnail
        except:
            pass
        return None

    def get_thumbnail(self):
        image = self.get_cover()
        if image:
            return '<img src="%s">' % image.get_admin_thumbnail_url()
        return '<img src="/static/admin/images/no_thumb.png" width="60">'

    get_thumbnail.allow_tags = True
    get_thumbnail.short_description = _("thumbnail")

    def get_absolute_url(self):
        try:
            return reverse('blogpages:article', kwargs={'url': self.page_url})
        except NoReverseMatch as ex:
            # Print/log ex?
            return '#NoReverseMatch'

    @property
    def template(self):
        lang = translation.get_language()
        return "blogpages/%s/%s.html" % (self.pk, lang)

    @property
    def template_root(self):
        import os
        template_path = None
        # still uses the default mypages template folder
        if hasattr(settings, 'MYPAGES_TEMPLATE_DIR'):
            template_path = settings.MYPAGES_TEMPLATE_DIR
        elif settings.TEMPLATE_DIRS:
            template_path = settings.TEMPLATE_DIRS[0]

        if template_path and self.pk:
            return os.path.join(template_path, 'blogpages/%s' % self.pk)

        # RAISE ERROR
        return None

    def default_template(self):
        default_template = getattr(settings, 'DEFAULT_BLOGPAGE_TEMPLATE', None)
        if default_template:
            return default_template
        return super(BlogPage, self).default_template()

    def save(self, *args, **kwargs):
        super(BlogPage, self).save(*args, **kwargs)
        self.create_templates()

    class Meta:
        app_label = "cms_blogpages"
        ordering = ['-publication_date']
        get_latest_by = 'publication_date'
        verbose_name = _('Article')
        verbose_name_plural = _('Articles')

    class Menu:
        icon = "fa-file-text"

    def __str__(self):
        return self.title


@python_2_unicode_compatible
class BlogPageImage(ImageModel):
    blog_page = models.OneToOneField(BlogPage, related_name='main_thumbnail')

    class Meta:
        app_label = "cms_blogpages"
        verbose_name = _("Thumbnail")
        verbose_name_plural = _("Thumbnails")

    def __str__(self):
        return ""
