default_app_config = 'dengun_cms.blogpages.apps.DengunCmsBlogpagesConfig'
