from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import Http404
from django.template.response import TemplateResponse
from django.db.models import Q
from dengun_cms.blogpages.models import BlogPage, Archive
from dengun_cms.core.models import Tag
from dengun_cms.mypages.views import page_with_editor_view, get_page_from_request


DEFAULT_TEMPLATE = 'mypages/blogpage_default.html'


def list_view(request):
    articles = BlogPage.objects.select_related(
        'author',
        'author__user',
        'author__image',
        'archive').published().exclude(Q(page_url__isnull=True) | Q(page_url__exact=''))

    context = {
        'articles': articles,
        'archives': Archive.objects.all(),
        'is_excerpt': True,
        'is_blog': True
    }

    return TemplateResponse(request, 'blogpages/index.html', context)


def archive_view(request, slug):

    try:
        archive = Archive.objects.get(slug__exact=slug)
    except:
        raise Http404()

    articles = BlogPage.objects.select_related('author',
                                              'author__user',
                                              'author__image',
                                              'archive').published().filter(archive=archive).exclude(Q(page_url__isnull=True) | Q(page_url__exact=''))

    context = {
        'articles': articles,
        'archive': archive,
        'archives': Archive.objects.all(),
        'is_excerpt': True,
        'is_blog': True
    }

    return TemplateResponse(request, 'blogpages/index.html', context)


def year_monthly_view(request, year, month=None):

    articles = BlogPage.objects.select_related('author',
                                              'author__user',
                                              'author__image',
                                              'archive').published().by_date(year, month).exclude(Q(page_url__isnull=True) | Q(page_url__exact=''))

    current_blog = {
        'year': int(year) if year else None,
        'month': int(month) if month else None
    }
    context = {
        'articles': articles,
        'archives': Archive.objects.all(),
        'is_excerpt': True,
        'is_blog': True,
        'current_blog': current_blog
    }
    return TemplateResponse(request, 'blogpages/index.html', context)


def tag_view(request, tag_slug=None):
    '''
    Index articles by tag
    :param tag_slug a slug related to the requested tag
    '''

    try:
        tag = Tag.objects.get(slug=tag_slug, name__isnull=False)
        articles = BlogPage.objects.select_related('author',
                                              'author__user',
                                              'author__image',
                                              'archive').published().exclude(Q(page_url__isnull=True) | Q(page_url__exact='')).filter(tags=tag)
    except ObjectDoesNotExist:
        # no such tag
        tag = None
        articles = None

    context = {
        'articles': articles,
        'archives': Archive.objects.all(),
        'tag_current': tag,
        'current_tag': tag,
        'is_excerpt': True,
        'is_blog': True
    }

    return TemplateResponse(request, 'blogpages/index.html', context)


def article_view(request, url):
    # Get a Page model object from the request
    model = BlogPage
    preview = False
    if request.user.is_staff:
        preview = True

    page = get_page_from_request(request, model, use_path=url, preview=preview)

    extra_context = {
        'article': page
    }

    return page_with_editor_view(request, url, page, extra_context=extra_context)
