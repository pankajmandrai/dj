# region ImportExport Integration with TreeAdmin model
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured

from dengun_cms.contrib.treeadmin.admin import TreeAdmin

if 'import_export' in settings.INSTALLED_APPS:
    from import_export.admin import ImportExportMixin


    class ImportExportTreeAdminDependencies(ImportExportMixin, TreeAdmin):

        def __init__(self, *args, **kwargs):
            super(ImportExportTreeAdminDependencies, self).__init__(*args, **kwargs)
            self.change_list_template = 'admin/import_export/change_list_import_export_tree_editor.html'
else:
    class ImportExportTreeAdminDependencies(TreeAdmin):
        pass


class ImportExportTreeAdmin(ImportExportTreeAdminDependencies):
    """
      Import Export Tree Admin Model For import_export package integration with TreeAdmin model
    """

    def __init__(self, *args, **kwargs):
        super(ImportExportTreeAdmin, self).__init__(*args, **kwargs)
