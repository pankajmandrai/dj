# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('cms_tabs', '0003_auto_20180223_1537'),
    ]

    operations = [
        migrations.AlterField(
            model_name='tab',
            name='subtitle',
            field=models.CharField(max_length=100, null=True, verbose_name='Subtitle', blank=True),
        ),
        migrations.AlterField(
            model_name='tab',
            name='title',
            field=models.CharField(max_length=100, verbose_name='Title'),
        ),
    ]
