# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import dengun_cms.media.fields


class Migration(migrations.Migration):

    dependencies = [
        ('cms_media', '__first__'),
        ('cms_tabs', '0005_auto_20180223_1840'),
    ]

    operations = [
        migrations.AddField(
            model_name='tab',
            name='slider',
            field=models.ForeignKey(default='', verbose_name='Slider', blank=True, to='cms_media.Slider'),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='tab',
            name='photos',
            field=dengun_cms.media.fields.MediaPhotoField(help_text=b'', to='cms_tabs.TabMediaPhoto', verbose_name='Gallery', blank=True),
        ),
    ]
