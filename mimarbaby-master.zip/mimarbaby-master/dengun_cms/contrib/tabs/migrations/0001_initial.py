# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Tab',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=100, verbose_name='Name')),
                ('content', models.TextField(max_length=400, null=True, verbose_name='Content', blank=True)),
            ],
            options={
                'db_table': 'cms_tabs_tab',
                'verbose_name': 'Tab',
                'verbose_name_plural': 'Tabs',
            },
        ),
        migrations.CreateModel(
            name='Table',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100, verbose_name='Name')),
                ('is_active', models.BooleanField(default=True, verbose_name='Active')),
            ],
            options={
                'db_table': 'cms_tabs_table',
                'verbose_name': 'Table',
                'verbose_name_plural': 'Table',
            },
        ),
        migrations.AddField(
            model_name='tab',
            name='table',
            field=models.ForeignKey(related_name='tabs', verbose_name='Table', to='cms_tabs.Table'),
        ),
    ]
