# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('cms_tabs', '0006_auto_20180223_1902'),
    ]

    operations = [
        migrations.AddField(
            model_name='tab',
            name='caption',
            field=models.CharField(max_length=200, null=True, verbose_name='Caption', blank=True),
        ),
        migrations.AlterField(
            model_name='tab',
            name='slider',
            field=models.ForeignKey(verbose_name='Slider', blank=True, to='cms_media.Slider', null=True),
        ),
    ]
