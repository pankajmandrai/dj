# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('cms_tabs', '0002_auto_20171025_1414'),
    ]

    operations = [
        migrations.AddField(
            model_name='tab',
            name='file',
            field=models.FileField(upload_to='cms/tabs', null=True, verbose_name='File', blank=True),
        ),
        migrations.AddField(
            model_name='tab',
            name='image',
            field=models.ImageField(default='', upload_to='cms/tabs', verbose_name='image', blank=True),
        ),
        migrations.AddField(
            model_name='tab',
            name='subtitle',
            field=models.CharField(max_length=100, null=True, verbose_name='Name', blank=True),
        ),
    ]
