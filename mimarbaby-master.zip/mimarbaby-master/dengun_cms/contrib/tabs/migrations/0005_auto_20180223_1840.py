# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import dengun_cms.core.managers
import dengun_cms.media.fields


class Migration(migrations.Migration):

    dependencies = [
        ('taggit', '0002_auto_20150616_2121'),
        ('photologue', '0008_auto_20150509_1557'),
        ('cms', '__first__'),
        ('cms_tabs', '0004_auto_20180223_1540'),
    ]

    operations = [
        migrations.CreateModel(
            name='TabMediaPhoto',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('image', models.ImageField(upload_to=settings.PHOTOLOGUE_PATH, verbose_name='image')),
                ('date_taken', models.DateTimeField(verbose_name='date taken', null=True, editable=False, blank=True)),
                ('view_count', models.PositiveIntegerField(default=0, verbose_name='view count', editable=False)),
                ('crop_from', models.CharField(default=b'center', max_length=10, verbose_name='crop from', blank=True, choices=[(b'top', 'Top'), (b'right', 'Right'), (b'bottom', 'Bottom'), (b'left', 'Left'), (b'center', 'Center (Default)')])),
                ('caption', models.CharField(max_length=128, null=True, verbose_name='caption', blank=True)),
                ('effect', models.ForeignKey(related_name='tabmediaphoto_related', verbose_name='effect', blank=True, to='photologue.PhotoEffect', null=True)),
                ('tags', dengun_cms.core.managers.TaggableManager(to='cms.Tag', through='taggit.TaggedItem', blank=True, help_text='A comma-separated list of tags.', verbose_name='Tags')),
            ],
            options={
                'db_table': 'cms_tabs_tab_media_photo',
                'verbose_name': 'photo',
                'verbose_name_plural': 'photos',
            },
        ),
        migrations.RemoveField(
            model_name='tab',
            name='image',
        ),
        migrations.AddField(
            model_name='tab',
            name='photos',
            field=dengun_cms.media.fields.MediaPhotoField(help_text=b'', to='cms_tabs.TabMediaPhoto', blank=True),
        ),
    ]
