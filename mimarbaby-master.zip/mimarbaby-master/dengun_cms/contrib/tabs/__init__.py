default_app_config = 'dengun_cms.contrib.tabs.apps.TabsAppConfig'
