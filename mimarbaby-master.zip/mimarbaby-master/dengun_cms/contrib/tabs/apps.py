# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from django.apps import AppConfig


class TabsAppConfig(AppConfig):
    """
    Default config for the app.
    """
    name = 'dengun_cms.contrib.tabs'
    label = 'cms_tabs'
    verbose_name = _("Tabs")
