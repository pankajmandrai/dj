# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from dengun_cms.featured.models import Slider
from photologue.models import ImageModel

from django.db import models
from django.utils.encoding import python_2_unicode_compatible
from django.utils.translation import ugettext_lazy as _

from dengun_cms.contrib.tabs.managers import TableManager
from dengun_cms.media.fields import MediaPhotoField
from dengun_cms.core.managers import TaggableManager


@python_2_unicode_compatible
class Table(models.Model):
    """
    Model class for a table.
    """
    name = models.CharField(verbose_name=_('Name'), max_length=100)
    is_active = models.BooleanField(verbose_name=_('Active'), default=True)

    objects = TableManager()

    def __str__(self):
        return "{}".format(self.name)

    class Menu:
        icon = 'fa-table'

    class Meta:
        app_label = 'cms_tabs'
        db_table = 'cms_tabs_table'
        verbose_name = _('Table')
        verbose_name_plural = _('Table')


@python_2_unicode_compatible
class TabMediaPhoto(ImageModel):
    caption = models.CharField(_('caption'), blank=True, null=True, max_length=128)
    tags = TaggableManager(blank=True)

    class Meta:
        db_table = 'cms_tabs_tab_media_photo'
        verbose_name = _("photo")
        verbose_name_plural = _("photos")

    class Menu:
        icon = "fa-picture-o"

    def admin_photo_thumbnail(self):
        if hasattr(self, "get_admin_media_url"):
            return self.get_admin_media_url()
        return self.image.url

    def to_json(self):
        return {
            'id': self.pk,
            'original': self.image.url,
            'thumbnail': self.get_media_thumbnail_url()
        }

    def __str__(self):
        if self.caption:
            return "{}".format(self.caption)
        return "{}".format(self.pk)


@python_2_unicode_compatible
class Tab(models.Model):
    """
    Model class for the table's tabs.
    """
    table = models.ForeignKey(verbose_name=_('Table'), to=Table, related_name="tabs")
    title = models.CharField(verbose_name=_('Title'), max_length=100)
    subtitle = models.CharField(verbose_name=_('Subtitle'), max_length=100, null=True, blank=True)
    content = models.TextField(verbose_name=_('Content'), null=True, blank=True)
    photos = MediaPhotoField(verbose_name=_('Gallery'), to=TabMediaPhoto, can_select=False, blank=True)
    slider = models.ForeignKey(verbose_name=_('Slider'), to=Slider, blank=True, null=True)
    file = models.FileField(_("File"), upload_to='cms/tabs', null=True, blank=True)
    caption = models.CharField(verbose_name=_('Caption'), max_length=200, null=True, blank=True)

    def __str__(self):
        return "{}".format(self.title)

    class Menu:
        icon = 'fa-folder-open'

    class Meta:
        app_label = 'cms_tabs'
        db_table = 'cms_tabs_tab'
        verbose_name = _('Tab')
        verbose_name_plural = _('Tabs')
