from dengun_cms.contrib.tabs.models import Tab
from dengun_cms.media.translation import MediaPhotoTranslationOptions
from modeltranslation.translator import translator, TranslationOptions

from dengun_cms.contrib.tabs.models import TabMediaPhoto


class TabTranslationOptions(TranslationOptions):
    fields = ('title', 'subtitle', 'content', 'caption')


translator.register(Tab, TabTranslationOptions)
translator.register(TabMediaPhoto, MediaPhotoTranslationOptions)
