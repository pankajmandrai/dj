Dengun CMS Tabs
===============

**Description**

This app allows super-users to create custom tables in the back-office.

**Usage**

When creating a table, you are able to create the table's tabs as well.
Make sure the table you created is set as active.

**Minimum 2 tabs are required for each table.**

Maximum amount of tabs for each table is 4, as default.
If you need to have more than 4 tabs in your tables, define the following flag in your project's settings with the new maximum amount.

_Example:_ 
```
DENGUN_CMS_TABS_MAX_NUMBER = 10
```

Those tables will be available as options in the CMS Template tags.

In the section **Tabs** you will have the template tag. 
Once you drag it to the DOM, you will be required to pick one of the active tables.

As an optional input, there are the templates available for usage with this template tag. By default, there's only one available template. 

If you need more templates available because you need different displays for different tables, define the following flag in your project's settings.

_Example:_ 
```
DENGUN_CMS_TABS_TEMPLATE_CHOICES = (
    ('cms/tabs_table_block_accordion.html', 'Accordion'),
)
```

**Make sure this custom template is inside a directory named "cms".**

Have fun!
 