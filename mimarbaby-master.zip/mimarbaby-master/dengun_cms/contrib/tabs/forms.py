# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django import forms
from django.conf import settings
from django.utils.translation import ugettext_lazy as _

from dengun_cms.contrib.tabs.models import Table


TEMPLATE_CHOICES = (
    ('cms/tabs_table_block.html', 'Default'),
) + getattr(settings, 'DENGUN_CMS_TABS_TEMPLATE_CHOICES', tuple())


class TabsTableBlockForm(forms.Form):
    """
    Dengun CMS Tag configuration form
    """
    table_id = forms.ModelChoiceField(label=_('Table'), queryset=Table.objects.active(), required=True)
    template = forms.ChoiceField(label=_('Custom Template'), choices=TEMPLATE_CHOICES, required=False)
