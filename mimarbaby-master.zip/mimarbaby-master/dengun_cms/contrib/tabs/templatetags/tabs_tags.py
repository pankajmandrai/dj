# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from classytags.arguments import MultiKeywordArgument
from classytags.core import Options
from dengun_cms.core.options import CmsInclusionTag
from django import template
from django.utils.translation import ugettext_lazy as _

from dengun_cms.contrib.tabs.forms import TabsTableBlockForm
from dengun_cms.contrib.tabs.models import Table


register = template.Library()


class TabsTableTag(CmsInclusionTag):
    """
    CMS template tag that displays the selected Table instance.
    """
    name = 'display_tabs_table'
    app = _('Tabs')
    template = 'cms/tabs_table_block.html'
    form = TabsTableBlockForm

    icon = 'table'
    verbose_name = _('Tabs Table')
    verbose_name_plural = _('Tabs Tables')

    options = Options(
        MultiKeywordArgument('options', required=False),
    )
    
    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template
    
    def get_context(self, context, options):
        default_options = {
            'table_id': None,
            'template': 'Default',
        }
        default_options.update(options or {})
        options = default_options
        
        table = Table.objects.filter(id=options['table_id']).first()
        context.update({
            'table': table, 
            'options': options
        })
        return context


register.tag(TabsTableTag)
