# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db.models import Manager


class TableManager(Manager):
    """
    Custom queryset manager for the model Table.
    """

    def active(self):
        return self.filter(is_active=True)
