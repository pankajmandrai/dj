# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from dengun_cms.core.translator import TranslationStackedInline
from dengun_cms.media.admin import MediaPhotoAdmin
from django.conf import settings
from django.contrib import admin

from dengun_cms.contrib.tabs.models import Table, Tab

from dengun_cms.contrib.tabs.models import TabMediaPhoto


class TabMediaPhotoAdmin(MediaPhotoAdmin):
    pass


class TabInlineAdmin(TranslationStackedInline):
    model = Tab
    fields = ('title', 'subtitle', 'content', 'photos', 'slider', 'caption', 'file')
    min_num = 2
    extra = 0
    max_num = getattr(settings, 'DENGUN_CMS_TABS_MAX_NUMBER', 4)

    class Media:
        js = (
            '/static/js/force_jquery.js',
            '/static/js/tabbed_translation_fields.js',
            '/static/ckeditor/ckeditor.js',
        )
        css = {
            'screen': ('/static/css/tabbed_translation_fields.css',),
        }


class TableAdmin(admin.ModelAdmin):
    inlines = (TabInlineAdmin,)
    list_display = ('name', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name',)
    ordering = ('-is_active',)

    class Media:
        js = (
            '/static/js/force_jquery.js',
            '/static/js/tabbed_translation_fields.js',
            '/static/ckeditor/ckeditor.js',
        )
        css = {
            'screen': ('/static/css/tabbed_translation_fields.css',),
        }


admin.site.register(TabMediaPhoto, TabMediaPhotoAdmin)
admin.site.register(Table, TableAdmin)
