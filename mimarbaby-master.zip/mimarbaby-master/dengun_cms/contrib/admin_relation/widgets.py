# -*- coding: utf-8 -*-
from itertools import chain
from django import forms
from django.contrib.admin.templatetags.admin_static import static
from django.utils.encoding import force_text, python_2_unicode_compatible
from django.utils.html import conditional_escape, format_html, format_html_join
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext_lazy as _

from django.forms.widgets import CheckboxSelectMultiple, CheckboxInput


class CheckboxSelectMultiple(CheckboxSelectMultiple):
    @property
    def media(self):
        js = ["checkbox_multiple_select.js",]
        return forms.Media(js=[static("admin/js/%s" % path) for path in js])
        
    def render(self, name, value, attrs=None, choices=()):
        if value is None: value = []
        has_id = attrs and 'id' in attrs
        if "class" in attrs:
            del attrs["class"]
            
        final_attrs = self.build_attrs(attrs, name=name)
        
        output = ['<ul class="checkbox_multiple_select span8 unstyled">']
        # Normalize to strings
        str_values = set([force_text(v) for v in value])
        for i, (option_value, option_label) in enumerate(chain(self.choices, choices)):
            # If an ID attribute was given, add a numeric index as a suffix,
            # so that the checkboxes don't all have the same ID attribute.
            if has_id:
                final_attrs = dict(final_attrs, id='%s_%s' % (attrs['id'], i))
                label_for = format_html(' for="{0}"', final_attrs['id'])
            else:
                label_for = ''

            cb = CheckboxInput(final_attrs, check_test=lambda value: value in str_values)
            option_value = force_text(option_value)
            rendered_cb = cb.render(name, option_value)
            option_label = force_text(option_label)
            output.append(format_html('<li class="option"><label{0}>{1} {2}</label></li>',
                                      label_for, rendered_cb, option_label))

        if self.choices:                
            output.append('<li><label><input type="checkbox" class="select-all" /> %s</label></li>' % force_text(_('Select all')))                             
        output.append('</ul>')
        return mark_safe('\n'.join(output))
