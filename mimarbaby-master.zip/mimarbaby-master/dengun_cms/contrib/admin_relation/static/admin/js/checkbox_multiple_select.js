(function($) {
  
    $(document).ready(function(){
        
    
        $(".checkbox_multiple_select").each(function(i,el){
            
            var self = $(el);
            var select_all = self.find(".select-all");
            var options = self.find(".option :input");
            
            var check_all = function(){
                var all_selected = true;
                
                options.each(function(i, el){
                    var self = $(el);
                    if(!self.prop("checked")){
                        all_selected = false;
                    }
                });
                
                if(all_selected){
                    select_all.prop("checked","checked");
                } else {
                    select_all.prop("checked","");
                }
            };
            
            options.change(check_all);
            
            
            select_all.change(function(){
                if($(this).prop("checked")){
                    options.prop("checked","checked");
                } else {
                    options.prop("checked","");
                }
            });
            
            
            check_all();
        });
        
    });
    
})(django.jQuery);