DENGUN CMS Redirect Admin
==========================


###Dependencies
```
django
django-import-export
```

###Setup

* Start by adding django-import-export to requirements and installing it.
* Add the following to the INSTALLED_APPS.
    ```
    'django.contrib.redirects',
    'import_export',
    'dengun_cms.contrib.redirect_admin',
    ```
* Add the following to the MIDDLEWARE_CLASSES.
    ```
    'django.contrib.redirects.middleware.RedirectFallbackMiddleware',
    ```
* Add this to the settings file.
    ```
    IMPORT_EXPORT_USE_TRANSACTIONS = False
    ```
* Make sure you run migrations.

* Test it and you're done.

###Extra Notes
When importing keep in mind you have to have a header named old_path, new_path, and site.

The old_path is equivalent to old url.

The new_path is where you want to redirect to.

The site is recommended to keep the value at 1.
