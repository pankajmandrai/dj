from django.contrib import admin
from import_export import resources, fields
from import_export.admin import ImportExportModelAdmin
from django.contrib.redirects.models import Redirect
from django.contrib.sites.models import Site

class RedirectResource(resources.ModelResource):
    class Meta:
        model = Redirect
        import_id_fields = ('old_path',)
        fields = ('old_path', 'new_path', 'site')

class RedirectAdmin(ImportExportModelAdmin):
    resource_class = RedirectResource

admin.site.unregister(Redirect)
admin.site.register(Redirect, RedirectAdmin)