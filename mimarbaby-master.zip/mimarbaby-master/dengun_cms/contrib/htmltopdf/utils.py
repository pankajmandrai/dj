from __future__ import absolute_import

from copy import copy
from itertools import chain
from subprocess import check_output
import os
import sys
import shlex

from django.conf import settings
from django.utils import six
from django.http import HttpResponse
from django.core.files import File

from .helpers import (options_to_args, content_disposition_filename)


# Downlad/Show File
def download_file(file_path, filename, show_in_browser=True):
    fileheader = 'attachment; filename={0}'
    if show_in_browser:
        fileheader = 'inline; filename={0}'

    filename = content_disposition_filename(filename)
    header_content = fileheader.format(filename)

    with open(file_path, 'rb') as pdf:
        response = HttpResponse(pdf.read(), content_type='application/pdf')
        response['Content-Disposition'] = header_content
        return response
    pdf.closed
    return response


# Open File
def openFile(filename, mode, context):
    try:
        filehandler = open(filename, mode)
        return {'opened': True, 'handler': filehandler}
    except IOError:
        raise Exception('Unable to open file ' + filename + '\n')
    except:
        raise Exception('Unexpected exception in openFile method.\n')
    return {'opened': False, 'handler': None}


# Save File
def writeFile(content, filename, context):
    filehandler = openFile(filename, 'w', context)
    if filehandler['opened']:
        file = File(filehandler['handler'])
        file.write(content)
        file.flush()
        file.close()


def wkhtmltopdf(pages, output=None, **kwargs):
    """
    Converts html to PDF using http://wkhtmltopdf.org/.

    pages: List of file paths or URLs of the html to be converted.
    output: Optional output file path. If None, the output is returned.
    **kwargs: Passed to wkhtmltopdf via _extra_args() (See
              https://github.com/antialize/wkhtmltopdf/blob/master/README_WKHTMLTOPDF
              for acceptable args.)
              Kwargs is passed through as arguments. e.g.:
                  {'footer_html': 'http://example.com/foot.html'}
              becomes
                  '--footer-html http://example.com/foot.html'

              Where there is no value passed, use True. e.g.:
                  {'disable_javascript': True}
              becomes:
                  '--disable-javascript'

              To disable a default option, use None. e.g:
                  {'quiet': None'}
              becomes:
                  ''

    example usage:
        wkhtmltopdf(pages=['/tmp/example.html'],
                    dpi=300,
                    orientation='Landscape',
                    disable_javascript=True)
    """
    if isinstance(pages, six.string_types):
        # Support a single page.
        pages = [pages]

    if output is None:
        # Standard output.
        output = '-'

    # Default options:
    options = getattr(settings, 'WKHTMLTOPDF_CMD_OPTIONS', None)
    if options is None:
        options = {'quiet': True}
    else:
        options = copy(options)
    options.update(kwargs)

    # Force --encoding utf8 unless the user has explicitly overridden this.
    options.setdefault('encoding', 'utf8')

    env = getattr(settings, 'WKHTMLTOPDF_ENV', None)
    if env is not None:
        env = dict(os.environ, **env)

    #WKHTMLTOPDF_CMD = 'wkhtmltopdf'
    #WKHTMLTOPDF_CMD = '/usr/bin/wkhtmltopdf'

    cmd = 'WKHTMLTOPDF_CMD'
    cmd = getattr(settings, cmd, os.environ.get(cmd, '/usr/local/bin/wkhtmltopdf'))  # 'wkhtmltopdf', '/usr/bin/wkhtmltopdf', '/usr/local/bin/wkhtmltopdf'

    ck_args = list(chain(shlex.split(cmd),
                         options_to_args(**options),
                         list(pages),
                         [output]))
    ck_kwargs = {'env': env}
    try:
        sys.stderr.fileno()
        ck_kwargs['stderr'] = sys.stderr
        ck_kwargs['shell'] = False
    except AttributeError:
        # can't call fileno() on mod_wsgi stderr object
        pass

    return check_output(ck_args, **ck_kwargs)
