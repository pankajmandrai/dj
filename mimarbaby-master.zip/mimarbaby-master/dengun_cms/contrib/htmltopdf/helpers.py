# -*- coding: utf-8 -*-
import os
import re

try:
    from urllib.request import pathname2url
    from urllib.parse import urljoin
except ImportError:  # Python2
    from urllib import pathname2url
    from urlparse import urljoin

from django.conf import settings
from django.utils import six


def options_to_args(**options):
    """Converts ``options`` into a list of command-line arguments."""
    flags = []
    for name in sorted(options):
        value = options[name]
        if value is None:
            continue
        flags.append('--' + name.replace('_', '-'))
        if value is not True:
            flags.append(six.text_type(value))
    return flags


def content_disposition_filename(filename):
    """
    Sanitize a file name to be used in the Content-Disposition HTTP
    header.

    Even if the standard is quite permissive in terms of
    characters, there are a lot of edge cases that are not supported by
    different browsers.

    See http://greenbytes.de/tech/tc2231/#attmultinstances for more details.
    """
    filename = filename.replace(';', '').replace('"', '')
    return http_quote(filename)


def http_quote(string):
    """
    Given a unicode string, will do its dandiest to give you back a
    valid ascii charset string you can use in, say, http headers and the
    like.
    """
    if isinstance(string, six.text_type):
        try:
            import unidecode
            string = unidecode.unidecode(string)
        except ImportError:
            string = string.encode('ascii', 'replace')
    # Wrap in double-quotes for ; , and the like
    string = string.replace(b'\\', b'\\\\').replace(b'"', b'\\"')
    return '"{0!s}"'.format(string.decode())


def pathname2fileurl(pathname):
    """Returns a file:// URL for pathname. Handles OS-specific conversions."""
    return urljoin('file:', pathname2url(pathname))


def get_override_paths():
    overrides = [{
        'root': settings.MEDIA_ROOT,
        'url': settings.MEDIA_URL
    }, {
        'root': settings.STATIC_ROOT,
        'url': settings.STATIC_URL
    }]

    # TODO - better way to check if we are in dev mode
    # print settings.DEBUG
    # if os.environ['DJANGO_SETTINGS_MODULE'].split('.', 1)[1] == 'settings_local':
    if settings.DEBUG:
        # ON Local use Assets Folder
        overrides[1]['root'] = os.path.join(settings.APPLICATION_ROOT, 'assets')

    return overrides


def make_absolute_paths(content):
    """Convert all MEDIA files into a file://URL paths in order to
    correctly get it displayed in PDFs."""

    overrides = get_override_paths()
    has_scheme = re.compile(r'^[^:/]+://')

    for x in overrides:
        if not x['url'] or has_scheme.match(x['url']) and x['url'] != settings.MEDIA_URL:
            continue

        if not x['root'].endswith('/'):
            x['root'] += '/'

        occur_pattern = '''["|']({0}.*?)["|']'''
        occurences = re.findall(occur_pattern.format(x['url']), content)
        occurences = list(set(occurences))  # Remove dups
        for occur in occurences:
            content = content.replace(occur,
                                      pathname2fileurl(x['root']) +
                                      occur[len(x['url']):])

    return content


# def make_absolute_paths(content):
#     """Convert all MEDIA files into a file://URL paths in order to
#     correctly get it displayed in PDFs."""

#     overrides = [
#         {
#             'root': settings.MEDIA_ROOT,
#             'url': settings.MEDIA_URL,
#         },
#         {
#             'root': settings.STATIC_ROOT,
#             'url': settings.STATIC_URL,
#         }
#     ]
#     has_scheme = re.compile(r'^[^:/]+://')

#     for x in overrides:
#         if not x['url'] or has_scheme.match(x['url']):
#             continue

#         if not x['root'].endswith('/'):
#             x['root'] += '/'

#         occur_pattern = '''["|']({0}.*?)["|']'''
#         occurences = re.findall(occur_pattern.format(x['url']), content)
#         occurences = list(set(occurences))  # Remove dups
#         for occur in occurences:
#             content = content.replace(occur,
#                                       pathname2fileurl(x['root']) +
#                                       occur[len(x['url']):])

#     return content

# on localhost is assets folder
# on online is static
# def get_static_url():
#     static_url = settings.STATIC_ROOT
#     if os.environ['DJANGO_SETTINGS_MODULE'].split('.', 1)[1] == 'settings_local':
#         static_url = os.path.join(settings.APPLICATION_ROOT, 'assets')
#     return static_url
