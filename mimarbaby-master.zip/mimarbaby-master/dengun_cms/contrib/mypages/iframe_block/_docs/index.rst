.. Dengun CMS IFrame Block documentation master file, created by
   sphinx-quickstart on Wed Sep  6 11:55:30 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Dengun CMS IFrame Block
-----------------------

This template tag provides adds a draggable iFrame block to Dengun CMS's MyPages Editor.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Using the IFrame Block
======================

In order to enable the block in the MyPages Editor, please add 'dengun_cms.contrib.mypages.iframe_block' to the installed apps

Basic Templatetags
==================

.. autoclass:: templatetags.dengun_cms_iframe_tags.IFrameTag
   :members:

.. autoclass:: templatetags.dengun_cms_iframe_tags.IFrameTagForm
   :members:

Compiling Documentation
=======================

.. warning::
   More detailed instructions for compilation of this documentation will soon be ready.


In order to compile the documentation, you need to have the following packages:

- django==1.8.9
- sphinx==1.6.3
- sphinx-rtd-theme==0.1.9
- dengun_cms (version matching django1.8, including all dependencies)

