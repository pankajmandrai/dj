# IFrame Template Tag for Dengun CMS

This template tag provides adds a draggable iFrame block to Dengun CMS's MyPages Editor.
