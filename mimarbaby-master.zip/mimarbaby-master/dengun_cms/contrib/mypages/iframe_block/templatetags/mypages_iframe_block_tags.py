# -*- coding: utf-8 -*-
from django import template
from django import forms
from django.utils.translation import ugettext_lazy as _

from classytags.helpers import InclusionTag
from classytags.arguments import MultiKeywordArgument
from classytags.core import Options

from dengun_cms.core.options import CmsTag

register = template.Library()

class IFrameTagForm(forms.Form):
    """
    This form sets options for the :class:`templatetags.dengun_cms_iframe_tags.IFrameTag`.
    
    These options behave just like the iFrame tag attributes of the corresponding name:
    
    - src, a string
    - width, an optional integer
    - height, an optional integer
    """
    src=forms.URLField(
        label=_('src'),
        required=False,
        help_text=_('iFrame src attribute')
    )
    width=forms.IntegerField(
        label=_('width'),
        required=False,
        help_text=_('iFrame width attribute')
    )
    height = forms.IntegerField(
        label=_('height'),
        required=False,
        help_text=_('iFrame height attribute')
    )


class IFrameTag(InclusionTag, CmsTag):
    """
    Renders an IFrame HTML element that can either be included directly or through a block component for the MyPages Editor.
    It renders an iFrame tag with a specific src, and also width and height, which are both set to 0 by default.
    
    Its options can be set via the :class:`templatetags.dengun_cms_iframe_tags.IFrameTagForm` form.
    
    :Example:
    
    .. code-block:: html

       {% iframe src='//slides.com/costaman/djadefdoc/embed' width=500 height=400 %}
       <!-- will output -->
       <iframe src='//slides.com/costaman/djadefdoc/embed' width='500' height='400' frameborder='0'></iframe>

    """
    name = 'iframe'
    template = 'cms/iframe/iframe.html'
    icon = 'code'
    # app = _('Other')

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    verbose_name = _('iFrame')
    form = IFrameTagForm

    def get_context(self, context, options):

        default_options = {
            'src': '',
            'width': 0,
            'height': 0
        }

        default_options.update(options or {})
        options = default_options

        return options

register.tag(IFrameTag)
