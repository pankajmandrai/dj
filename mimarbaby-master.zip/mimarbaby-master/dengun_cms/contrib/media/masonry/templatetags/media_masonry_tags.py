from django import template
from django.utils.translation import ugettext_lazy as _
from django.contrib.staticfiles.templatetags.staticfiles import static
from classytags.core import Options
from classytags.arguments import Argument, MultiKeywordArgument

from dengun_cms.core.options import CmsInclusionTag
from dengun_cms.contrib.media.masonry.forms import MediaMasonryGalleryForm

register = template.Library()


class MediaMasonryGallery(CmsInclusionTag):
    name = 'media_masnory_gallery'
    template = 'cms/media_masonry_gallery.html'

    options = Options(
        Argument('gallery_id'),
        MultiKeywordArgument('options', required=False),
    )

    icon = 'camera'
    form = MediaMasonryGalleryForm
    required = True
    verbose_name = _('Masonry Gallery')
    app = _('Media')

    class Media:
        css = (
            static('css/blueimp-gallery.min.css'),
        )
        js = (
            static('js/masonry.pkgd.min.js'),
            static('js/jquery.blueimp-gallery.min.js')
        )

    def get_template(self, context, gallery_id, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, gallery_id, options):
        from dengun_cms.media.models import MediaGallery

        gallery = MediaGallery.objects.get(pk=gallery_id)
        show_more = False
        default_options = {
            'limit': 25,
            'offset': 0,
            'grid': 4,
            'title': gallery.title
        }

        default_options.update(options or {})
        options = default_options

        count = gallery.photos.count()
        photos = gallery.photos.all()[options['offset']:options['limit']]

        if count < options['limit']:
            show_more = True

        grid_size = {
            'sm': 12,
            'md': options['grid']
        }

        if options['grid'] == "1":
            grid_size['sm'] = 2

        if options['grid'] == "2":
            grid_size['sm'] = 4

        if options['grid'] == "3":
            grid_size['sm'] = 6

        if options['grid'] == "4":
            grid_size['sm'] = 6

        new_context = {
            'gallery': gallery,
            'photos': photos,
            'options': options,
            'grid_size': grid_size,
            'show_more': show_more,
            'cid': id(self)
        }

        return new_context


register.tag(MediaMasonryGallery)
