from django import forms
from django.utils.translation import ugettext_lazy as _

GRID_CHOICES = (
    (12, '1'),
    (6, '2'),
    (4, '3'),
    (3, '4'),
    (2, '6'),
    (1, '12'),
)


class MediaMasonryGalleryForm(forms.Form):
    arg0 = forms.ModelChoiceField(label=_('Gallery'), queryset=None)
    limit = forms.IntegerField(label=_("Limit"), required=False, initial=25)
    offset = forms.IntegerField(label=_("Offset"), required=False)
    grid = forms.ChoiceField(label=_("Photos per row"), choices=GRID_CHOICES, initial=3)
    title = forms.CharField(label=_("title"), required=False)

    def __init__(self, *args, **kwargs):
        from dengun_cms.media.models import MediaGallery
        super(MediaMasonryGalleryForm, self).__init__(*args, **kwargs)
        self.fields['arg0'].queryset = MediaGallery.objects.all()
