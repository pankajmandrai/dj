from django import template
from django.utils.translation import ugettext_lazy as _
from classytags.core import Options
from classytags.arguments import MultiKeywordArgument
from dengun_cms.core.options import CmsInclusionTag
from dengun_cms.contrib.forms.cvform.utils import get_cv_contact_form
from dengun_cms.contrib.forms.cvform.forms import CvContactFormTagForm


register = template.Library()


class CvContactFormTag(CmsInclusionTag):
    name = 'cv_contact_form'
    template = 'cms/cvform/vertical.html'

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    icon = "paperclip"
    form = CvContactFormTagForm
    verbose_name = _('CV Contact')
    app = _('Forms')

    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, options):

        default_options = {
            'prefix': 'cvcf',
            'show_phone': False,
            'recipients': None,
            'subject': None,
            "submit_text": _("Submit"),
            'title': _("Contact Form")
        }

        default_options.update(options or {})
        options = default_options
        request = context['request']

        submit_handle = "s%s" % options['prefix']

        Form = get_cv_contact_form()

        if request.method == "POST" and request.POST.get(submit_handle, False):
            form = Form(request.POST, request.FILES, prefix=options['prefix'])
            if form.is_valid():
                form.response(request, options)
        else:
            form = Form(prefix=options['prefix'])

        context.update({
            'csrf_token': context['csrf_token'],
            'submit_handle': submit_handle,
            'form': form,
            'options': options,
            'title': options['title']
        })
        return context


register.tag(CvContactFormTag)
