from django import forms
from django.utils.translation import ugettext_lazy as _
from dengun_cms.core.forms import NULL_FIELD_CHOICES


CONTACT_FORM_TEMPLATE_CHOICES = (
    ('cms/cvform/vertical.html', 'Vertical'),
    ('cms/cvform/horizontal.html', 'Horizontal'),
    ('cms/cvform/columns.html', 'Side by Side'),
)


class CvContactFormTagForm(forms.Form):
    prefix = forms.CharField(label=_("prefix"), required=False, initial='cf')
    show_phone = forms.ChoiceField(label=_("show phone"), choices=NULL_FIELD_CHOICES, required=False)
    recipients = forms.CharField(label=_("recipients"), required=False)
    subject = forms.CharField(label=_("subject"), required=False)
    submit_text = forms.CharField(label=_("Submit text"), required=False)
    title = forms.CharField(label=_("title"), required=False)
    template = forms.ChoiceField(label=_("template"), choices=CONTACT_FORM_TEMPLATE_CHOICES, required=False)


# MAIN CONTACT FORM
class CvContactForm(forms.Form):
    def __init__(self, *args, **kwargs):
        from django.conf import settings
        super(CvContactForm, self).__init__(*args, **kwargs)
        self.is_done = False
        if getattr(settings, 'CV_CONTACT_FORM_IS_REQUIRED', False):
            self.fields['cv'].required = True

    name = forms.CharField(label=_("name"), max_length=100)
    email = forms.EmailField(label=_("email"))
    phone = forms.CharField(label=_("phone number"), max_length=100, required=False)
    message = forms.CharField(label=_("message"), widget=forms.widgets.Textarea())
    cv = forms.FileField(label=_("CV"), required=False)

    def response(self, request, options):
        from dengun_cms.contrib.forms.cvform.mail import send_cv_contact_email

        if request.POST.get('addrhfldp'):
            self.is_done = True
        elif self.is_valid():
            send_cv_contact_email(request, self.cleaned_data, options)
            self.is_done = True
