from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from dengun_cms.core.mail import email_settings


def send_cv_contact_email(request, data, options):

    to, bcc, from_email = email_settings(
        to=options['recipients'] if 'recipients' in options else None)

    mail_context = {
        'data': data,
        'request': request,
        'options': options
    }

    subject = options['subject'] if options['subject'] else "CV Contact form received."

    text_content = render_to_string('email/cv_contact_form.txt', mail_context)
    html_content = render_to_string('email/cv_contact_form.html', mail_context)

    msg = EmailMultiAlternatives(subject, text_content, from_email, to, bcc)
    msg.attach_alternative(html_content, "text/html")

    file = data['cv']

    if file:
        msg.attach(file.name, file.read(), file.content_type)
    msg.send(fail_silently=True)
