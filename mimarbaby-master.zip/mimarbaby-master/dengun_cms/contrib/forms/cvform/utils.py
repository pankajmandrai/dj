from django.conf import settings
from django.utils.module_loading import import_string


def get_cv_contact_form():
    default_form_class = 'dengun_cms.contrib.forms.cvform.forms.CvContactForm'
    load_manager = getattr(settings, "CV_CONTACT_FORM", default_form_class)
    ContactForm = import_string(load_manager)
    return ContactForm
