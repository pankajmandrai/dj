from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.core.exceptions import ImproperlyConfigured
from django.apps import apps
import re

EMAIL_REGEX = re.compile(("([a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`"
                    "{|}~-]+)*(@|\sat\s)(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(\.|"
                    "\sdot\s))+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)"))


def get_emails(s):
    """Returns an iterator of matched emails found in string s."""
    # Removing lines that start with '//' because the regular expression
    # mistakenly matches patterns like 'http://foo@bar.com' as '//foo@bar.com'.
    return (email[0] for email in re.findall(EMAIL_REGEX, s) if not email[0].startswith('//'))


def email_settings(to=None, bcc=None, from_email=None):
    from django.conf import settings

    if not hasattr(settings, 'EMAIL'):
        raise ImproperlyConfigured("Please Configure the 'EMAIL' settings (not found)")

    if not to and 'recipients' not in settings.EMAIL:
        raise ImproperlyConfigured("Please Configure the 'EMAIL' settings (no recipients)")
    elif not to:
        to = settings.EMAIL['recipients']

    # CONVERT MULTIPLE STR EMAILS TO LIST
    if isinstance(to, (str, unicode)):
        to = [email for email in get_emails(to)]

    # CONVERT TO STR TO LIST
    if not isinstance(to, (list, tuple)) and isinstance(to, (str, unicode)):
        to = [to, ]

    if not bcc and 'bcc_recipients' in settings.EMAIL:
        bcc = settings.EMAIL['bcc_recipients']

    if not from_email and 'from_email' in settings.EMAIL:
        from_email = settings.EMAIL['from_email']

    return to, bcc, from_email


# CONTACT FORM EMAIL HANDLER
def send_contact_email(request, data, options):

    to, bcc, from_email = email_settings(
        to=options['recipients'] if 'recipients' in options else None)

    # LEED
    if apps.is_installed('dengun_cms.leads'):
        from dengun_cms.leads.utils import create_lead
        admin_url = create_lead("Contact Form", request, data)
    else:
        admin_url = None

    mail_context = {
        'data': data,
        'request': request,
        'options': options
    }

    subject = options['subject'] if options['subject'] else "Contact form received."

    text_content = render_to_string('email/contact_form.txt', mail_context)
    html_content = render_to_string('email/contact_form.html', mail_context)

    msg = EmailMultiAlternatives(subject, text_content, from_email, to, bcc)
    msg.attach_alternative(html_content, "text/html")

    msg.send(fail_silently=True)


def send_advanced_email(request, data, options, file=None):

    to, bcc, from_email = email_settings(
        to=options['recipients'] if 'recipients' in options else None)

    # LEED
    if apps.is_installed('dengun_cms.leads'):
        from dengun_cms.leads.utils import create_lead
        admin_url = create_lead("Contact Form", request, data)
    else:
        admin_url = None

    mail_context = {
        'data': data,
        'request': request,
        'options': options
    }

    subject = options['subject'] if options['subject'] else "Contact form received."

    text_content = render_to_string('email/contact_form.txt', mail_context)
    html_content = render_to_string('email/contact_form.html', mail_context)

    msg = EmailMultiAlternatives(subject, text_content, from_email, to, bcc)
    msg.attach_alternative(html_content, "text/html")
    if file:
        msg.attach(file.name, file.read(), file.content_type)
    msg.send(fail_silently=True)
