(function() {


	CKEDITOR.plugins.add( 'templatetags', {
		requires: 'entities',

		// Adapt some critical editor configuration for better support
		// of BBCode environment.
		beforeInit: function( editor ) {
			var config = editor.config;

			CKEDITOR.tools.extend( config, {
				// This one is for backwards compatibility only as
				// editor#enterMode is already set at this stage (#11202).
				enterMode: CKEDITOR.ENTER_BR,
				basicEntities: false,
				entities: false,
				fillEmptyBlocks: false
			}, true );

			editor.filter.disable();

			// Since CKEditor 4.3, editor#(active)enterMode is set before
			// beforeInit. Properties got to be updated (#11202).
			editor.activeEnterMode = editor.enterMode = CKEDITOR.ENTER_BR;
		},

		init: function(editor){
			function onSetData( evt ) {
				var bbcode = evt.data.dataValue;
				evt.data.dataValue = bbcode;
			}

			// Skip the first "setData" call from inline creator, to allow content of
			// HTML to be loaded from the page element.
			if ( editor.elementMode == CKEDITOR.ELEMENT_MODE_INLINE )
				editor.once( 'contentDom', function() {
					editor.on( 'setData', onSetData );
				} );
			else
				editor.on( 'setData', onSetData );
		}
	});

})();