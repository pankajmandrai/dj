/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
    config.magicline_color =  '#2283c5';
    config.extraPlugins = 'autogrow,oembed'
    config.autoGrow_maxHeight = 480;
    config.toolbarGroupCycling = false;
    config.toolbarCanCollapse = false;
    config.forcePasteAsPlainText = true;

    config.toolbar = [
        { name: 'basicstyles', items : ['Bold','Italic','Underline','Strike' ] },
        { name: 'styles', items : [ 'Format', ] },
        { name: 'paragraph', items : [ 'NumberedList','BulletedList','-','Blockquote',
        '-','JustifyLeft','JustifyCenter','JustifyRight' ] },
        { name: 'links', items : [ 'Link','Unlink','Anchor' ] },
        { name: 'insert', items : [ 'Image', 'oembed', 'Table','HorizontalRule' ] },
        { name: 'styles', items : [ 'FontSize' ] },
        { name: 'colors', items : [ 'TextColor', ] },
        { name: 'clipboard', items: [ 'Undo', 'Redo' ] },
        { name: 'document', items: [ 'RemoveFormat', '-', 'Source' ] }
    ];

    config.dialog_backgroundCoverColor = 'rgb(0, 0, 0)';
    config.dialog_backgroundCoverOpacity = 0.7;

    config.removePlugins = 'find,flash,' +
                        'forms,newpage,' +
                        'scayt,iframe,about,' +
                        'smiley,specialchar,stylescombo,templates';
};
