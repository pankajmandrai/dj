(function($){
	var router;

	var ViewportNav = Backbone.View.extend({
		el: ".viewport-nav",
		events: {
			"click a": "toggle"
		},
		toggle: function(event){
			this.$el.find("li").removeClass("active");
			var target = $(event.target);
			target.parent().addClass("active");
			var viewport = $(".cms-viewport");
			viewport.attr("class", "cms-viewport");
			viewport.addClass(target.attr("class"));
		}
	});

	var Workspace = Backbone.Router.extend({
		routes: {
		},
		initialize: function(){
			new ViewportNav();


			$("body").wrapInner("<div id='cms-container'></div>");
			$("body").append($("#cms-tools"));
			$("#cms-container").wrapInner("<div class='cms-viewport'></div>");
			var iframe = $('<iframe id="cms-editor" allowfullscreen="true" sandbox="allow-scripts allow-pointer-lock allow-same-origin allow-popups allow-forms"></iframe>');

			$("#cms-tools .edit").on('click', function(){

				$("#cms-container .cms-viewport").html("").append(iframe);

				iframe.attr("src", $(this).attr("href") + "?edit=1");

				$(this).hide();

				$("#cms-tools .save").removeClass("hide");
				return false;
			});

			$("#cms-tools .save").on('click', function(){


				iframe[0].contentWindow.location.hash = "#save"

			});



		},
	});

	$(document).ready(function(){
		router = new Workspace();
		Backbone.history.start({pushState: true});
	});

})(jQuery)