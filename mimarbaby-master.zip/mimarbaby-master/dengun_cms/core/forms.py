import six
from django import forms
from django.utils.translation import ugettext_lazy as _
from django.db.models.query import QuerySet
from django.utils.encoding import force_text

from dengun_cms.core.widgets import SortedCheckboxSelectMultiple

NULL_FIELD_CHOICES = (
    ('', _('default')),
    ('False', _('no')),
    ('True', _('yes'))
)


class SeperatorTagForm(forms.Form):
    show_line = forms.ChoiceField(label=_("show line"), choices=NULL_FIELD_CHOICES, required=False)


class PlaceholditTagForm(forms.Form):
    arg0 = forms.IntegerField(label=_("width"), initial=320)
    arg1 = forms.IntegerField(label=_("height"), initial=220)
    arg2 = forms.CharField(label=_("css Class"), initial='img-responsive')


CONTACT_FORM_TEMPLATE_CHOICES = (
    ('cms/contact_form/vertical.html', 'Vertical'),
    ('cms/contact_form/horizontal.html', 'Horizontal'),
    ('cms/contact_form/columns.html', 'Side by Side'),
)


class ContactFormTagForm(forms.Form):
    prefix = forms.CharField(label=_("prefix"), required=False, initial='cf')
    show_phone = forms.ChoiceField(label=_("show phone"), choices=NULL_FIELD_CHOICES, required=False)
    recipients = forms.CharField(label=_("recipients"), required=False)
    subject = forms.CharField(label=_("subject"), required=False)
    submit_text = forms.CharField(label=_("Submit text"), required=False)
    title = forms.CharField(label=_("title"), required=False)
    template = forms.ChoiceField(label=_("template"), choices=CONTACT_FORM_TEMPLATE_CHOICES, required=False)


POSITION_CHOICES = (
    ('TOP_LEFT', 'Top left'),
    ('TOP_CENTER', 'Top center'),
    ('TOP_RIGHT', 'Top right'),
    ('RIGHT_TOP', 'Right top'),
    ('RIGHT_CENTER', 'Right center'),
    ('RIGHT_BOTTOM', 'Right Bottom'),
    ('BOTTOM_RIGHT', 'Bottom Right'),
    ('BOTTOM_CENTER', 'Bottom center'),
    ('BOTTOM_LEFT', 'Bottom left'),
    ('LEFT_BOTTOM', 'Left Bottom'),
    ('LEFT_CENTER', 'Left Center'),
    ('LEFT_TOP', 'Left top')
)


TARGET_CHOICES = (
    ('', _('Open in the same Page')),
    ('_blank', _('Open in a new page (tab)'))
)

BTN_CLASSES = (
    ('btn-default', _('Default')),
    ('btn-primary', _('Primary')),
    ('btn-success', _('Success')),
    ('btn-info', _('Info')),
    ('btn-warning', _('Warning')),
    ('btn-danger', _('Danger')),
    ('btn-link', _('Link')),
)

BTN_SIZE_CLASSES = (
    ('btn-xs', _('Extra small')),
    ('btn-sm', _('Small')),
    ('', _('Default')),
    ('btn-lg', _('Large')),
)

BTN_ALIGN_CLASSES = (
    ('', _('Default')),
    ('text-left', _('Left')),
    ('text-center', _('Center')),
    ('text-right', _('Right')),
)


class CallToActionForm(forms.Form):
    label = forms.CharField(label=_("Button Label"), required=False)
    href = forms.CharField(label=_("href"), required=False)
    url = forms.CharField(label=_("url name"), required=False)
    page = forms.ChoiceField(label=_("link to another page"), choices=list(), required=False)
    target = forms.ChoiceField(label=_("target"), choices=TARGET_CHOICES, required=False)
    btn_class = forms.ChoiceField(label=_("style"), choices=BTN_CLASSES, required=False)
    btn_size = forms.ChoiceField(label=_("size"), choices=BTN_SIZE_CLASSES, required=False)
    is_block = forms.BooleanField(label=_("is block"), required=False)
    btn_align = forms.ChoiceField(label=_("align"), choices=BTN_ALIGN_CLASSES, required=False)
    btn_id = forms.CharField(label=_("btn id"), required=False)

    def __init__(self, *args, **kwargs):
        from django.conf import settings
        from dengun_cms.mypages.models import Page
        super(CallToActionForm, self).__init__(*args, **kwargs)

        # Checks for custom classes and changes choices if they exist.
        classes = getattr(settings, 'BTN_CLASSES', BTN_CLASSES)
        self.fields['btn_class'].choices = classes

        self.fields['page'].choices = [('', '')] + [(p.pk, "%s (%s)" % (p.title, p.page_url)) for p in
                                                    Page.objects.all()]


# MAIN CONTACT FORM
class ContactForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super(ContactForm, self).__init__(*args, **kwargs)
        self.is_done = False

    name = forms.CharField(label=_("name"), max_length=100)
    email = forms.EmailField(label=_("email"))
    phone = forms.CharField(label=_("phone number"), max_length=100, required=False)
    message = forms.CharField(label=_("message"), widget=forms.widgets.Textarea())

    def response(self, request, options):
        from dengun_cms.core.mail import send_contact_email

        if request.POST.get('addrhfldp'):
            self.is_done = True
        elif self.is_valid():
            send_contact_email(request, self.cleaned_data, options)
            self.is_done = True


class SortedMultipleChoiceField(forms.ModelMultipleChoiceField):
    widget = SortedCheckboxSelectMultiple

    def clean(self, value):
        queryset = super(SortedMultipleChoiceField, self).clean(value)
        if value is None or not isinstance(queryset, QuerySet):
            return queryset

        # GIVE NEW ORDER
        object_list = dict((str(key), value) for key, value in six.iteritems(queryset.in_bulk(value)))
        return [object_list[str(pk)] for pk in value]

    def _has_changed(self, initial, data):
        if initial is None:
            initial = []
        if data is None:
            data = []
        if len(initial) != len(data):
            return True
        initial_set = [force_text(value) for value in self.prepare_value(initial)]
        data_set = [force_text(value) for value in data]
        return data_set != initial_set


NULL_FIELD_CHOICES = (
    ('', _('default')),
    ('False', _('no')),
    ('True', _('yes'))
)

# ints 1 to 21
MAP_ZOOM_CHOICES = [(i, str(i)) for i in range(1, 21)]

MAP_TYPE_CHOICES = (
    ('ROADMAP', _('Roadmap')),
    ('HYBRID', _('Hybrid')),
    ('SATELLITE', _('Satellite')),
    ('TERRAIN', _('Terrain')),
)

CONTROL_CHOICES = (
    ('DEFAULT', 'Default'),
    ('DROPDOWN_MENU', 'Drop-down menu'),
    ('HORIZONTAL_BAR', 'Horizontal bar'),
)


# Simple marker Map
class GoogleMapTagForm(forms.Form):
    arg0 = forms.CharField(label=_("latitude"))
    arg1 = forms.CharField(label=_("longitude"))
    height = forms.IntegerField(label=_("height"), required=False, initial=300)
    zoom = forms.ChoiceField(label=_("zoom"), choices=MAP_ZOOM_CHOICES, required=False, initial=8)
    show_marker = forms.ChoiceField(label=_("show marker"), choices=NULL_FIELD_CHOICES, required=False)
    marker_content = forms.CharField(label=_("marker content"), required=False)
    map_type = forms.ChoiceField(label=_("map type"), choices=MAP_TYPE_CHOICES, required=False)
    show_control = forms.ChoiceField(label=_("show control"), choices=NULL_FIELD_CHOICES, required=False)
    control_type = forms.ChoiceField(label=_("control type"), choices=CONTROL_CHOICES, required=False)
    show_navigation = forms.ChoiceField(label=_("show navigation"), choices=NULL_FIELD_CHOICES, required=False)
    enable_scroll = forms.ChoiceField(label=_("enable scrolling"), choices=NULL_FIELD_CHOICES, required=False)
    draggable = forms.ChoiceField(label=_("enable dragging"), choices=NULL_FIELD_CHOICES, required=False)
