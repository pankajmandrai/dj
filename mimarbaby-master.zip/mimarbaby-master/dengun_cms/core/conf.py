# -*- coding: utf-8 -*-
from django.conf import settings
from dengun_cms.core.utils import check_set_dict_defaults


# ABSTRACT SEO MODEL CONF
def get_seo_model_conf():
    # Defaults
    default_seo_model_conf = {
        'seo_title': {
            'max_length': 70,  # Max 255
        },
        'seo_description': {
            'max_length': 155,  # Max 255
        },
    }

    seo_model_conf = getattr(settings, "CMS_SEO_MODEL_CONF", None)
    if not seo_model_conf:
        # Return Default Configuration
        return default_seo_model_conf

    # Check configurations or set defaults
    seo_model_conf = check_set_dict_defaults(seo_model_conf, default_seo_model_conf)
    return seo_model_conf

# SEO_MODEL_CONF['seo_title']['max_length']
# SEO_MODEL_CONF['seo_description']['max_length']
SEO_MODEL_CONF = get_seo_model_conf()
