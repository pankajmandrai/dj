
from django.conf import settings
from django.core.urlresolvers import (
    LocaleRegexURLResolver, get_resolver
)
from django.utils.cache import patch_vary_headers
from django.template.loader import get_template
from django.core.cache import cache
from dengun_cms.core.options import MediaTag
from django.template.loader_tags import ExtendsNode, IncludeNode


def parse_nodelist(item, context):
    if hasattr(item, 'nodelist'):
        for node in item.nodelist:
            if isinstance(node, ExtendsNode):
                parent_template_name = node.parent_name.resolve(context)
                backend = get_template(parent_template_name)
                for n in parse_nodelist(backend.template, context):
                    yield n
            if isinstance(node, IncludeNode):
                inclusion_template_name = node.template.resolve(context)
                backend = get_template(inclusion_template_name)
                for n in parse_nodelist(backend.template, context):
                    yield n
            if isinstance(node, MediaTag):
                yield node
            else:
                for n in parse_nodelist(node, context):
                    yield n


def media_template_parser(template, context):
    # GET MEDIA TAGS ONLY
    media_tags = list()
    for node in parse_nodelist(template, context):
        if node in media_tags:
            continue
        media_tags.append(node)

    return media_tags


class CmsMiddleware(object):
    def __init__(self):
        self._is_multiple_languages_used = False
        self._is_language_prefix_patterns_used = False
        for url_pattern in get_resolver(None).url_patterns:
            if isinstance(url_pattern, LocaleRegexURLResolver):
                self._is_language_prefix_patterns_used = True
                break

        if len(settings.LANGUAGES) > 1 and self._is_language_prefix_patterns_used:
            self._is_multiple_languages_used = True

    def process_template_response(self, request, response):
        if hasattr(response, 'template_name') and response.template_name and not isinstance(response.template_name, (list, tuple)):

            backend = get_template(response.template_name)

            media = media_template_parser(backend.template, response.context_data)
            if media:
                response.context_data['TAGS_MEDIA'] = media

        return response

    def process_response(self, request, response):
        if hasattr(response, 'template_name') and response.template_name and not isinstance(response.template_name, (list, tuple)):
            if response.context_data.get('current_page_update_cache', False):
                page = response.context_data.get('current_page', None)
                page_cache = response.context_data.get('current_page_cache', None)

                if page and page_cache:
                    cache_name = u"template.cache.mypage.%s" % page.pk
                    cache_value = {k: page_cache[k].keys() for k in page_cache.keys()}
                    cache.set(cache_name, cache_value, 3600)

        if self._is_multiple_languages_used:
            patch_vary_headers(response, ('Accept-Language',))

        return response
