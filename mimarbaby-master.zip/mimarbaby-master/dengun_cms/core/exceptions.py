
class CmsTagRedirect(Exception):
    pass
