from django.contrib.admin import FieldListFilter


class DateRangeFieldFilter(FieldListFilter):
    template = 'admin/filters/date.html'
    label = 'Date'  # Default value, please edit when extending

    def __init__(self, field, request, params, model, model_admin, field_path):
        self.field_generic = '%s__' % field_path
        self.date_params = dict([(k, v) for k, v in params.items()
                                 if k.startswith(self.field_generic)])

        self.lookup_kwarg_since = '%s__gte' % field_path
        self.lookup_kwarg_until = '%s__lt' % field_path
        self.links = (
            ('current', {}),
        )

        if not self.lookup_kwarg_since in self.date_params:
            self.date_params[self.lookup_kwarg_since] = ''
            self.date_params[self.lookup_kwarg_until] = ''

        super(DateRangeFieldFilter, self).__init__(field, request, params, model, model_admin, field_path)

    def expected_parameters(self):
        return [self.lookup_kwarg_since, self.lookup_kwarg_until]

    def choices(self, cl):
        """
        FieldListFilter expects a list of choice values.
        Instead, DateRangeFieldFilter has one single choice
        value "current" containing start/end date inputs.
        """
        for title, param_dict in self.links:

            # Preserves all other params in query string
            params = [(key, value) for key, value in cl.params.items() if key not in self.date_params.keys()]

            # These items will be available as context in filter's template
            yield {
                'field': self.field_generic,
                'query_string': cl.get_query_string(
                                    param_dict, [self.field_generic]),
                'params': params,
                'label': self.label,
                'display': title,
                'starting_date':  self.date_params[self.lookup_kwarg_since],
                'ending_date': self.date_params[self.lookup_kwarg_until],
            }
