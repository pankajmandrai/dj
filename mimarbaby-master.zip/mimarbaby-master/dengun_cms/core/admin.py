from django.utils.translation import ugettext_lazy as _
from django.http import Http404, HttpResponse
from django.contrib import admin
from django.forms.models import BaseInlineFormSet
from django.core.exceptions import ImproperlyConfigured

from django.db import models
from dengun_cms.core.widgets import SlugWidget
from dengun_cms.core.translator import TranslationAdmin
from taggit.models import Tag as TaggitTag
from dengun_cms.core.models import Tag, TaggedItem

from taggit.admin import TagAdmin as TaggitTagAdmin

import json


def get_model_admin_url(model, url_name='add', url_args=(), url_kwargs={}):
    from django.core.urlresolvers import reverse
    if model not in admin.site._registry:
        raise ImproperlyConfigured("%s is not register in the admin, (required to get model admin url)" % model.__name__)
    info = model._meta.app_label, model._meta.model_name, url_name
    return reverse("admin:%s_%s_%s" % info, *url_args, **url_kwargs)


def is_request_from_model(request, model):
    if model not in admin.site._registry:
        raise ImproperlyConfigured("%s is not register in the admin, (required to check if request is from model admin)" % model.__name__)

    try:
        destroy_url = request.path.split("/")[:4]
        build_url = "/".join(destroy_url)
        if build_url in get_model_admin_url(model, 'changelist'):
            return True
    except:
        pass

    return False


class RequiredInlineFormSet(BaseInlineFormSet):
    """
    Generates an inline formset that is required
    """

    def _construct_form(self, i, **kwargs):
        """
        Override the method to change the form attribute empty_permitted
        """
        form = super(RequiredInlineFormSet, self)._construct_form(i, **kwargs)
        form.empty_permitted = False
        return form


class TaggedItemInline(admin.StackedInline):
    model = TaggedItem
    extra = 0
    is_accordion = True
    read_only = True
    max_num = 0
    fieldsets = (
        (None, {
            'fields': ()
        }),
    )

    def has_add_permissions(self, request):
        return False

    def has_change_permissions(self, request, obj=None):
        return False


class TagAdmin(TaggitTagAdmin, TranslationAdmin):

    formfield_overrides = {
        models.SlugField: {'widget': SlugWidget},
    }

    inlines = [TaggedItemInline, ]

    def get_autocomplete_url(self):
        from django.core.urlresolvers import reverse
        info = self.model._meta.app_label, self.model._meta.model_name
        return reverse("admin:%s_%s_autocomplete" % info)

    def get_urls(self):
        from django.conf.urls import url, patterns
        info = self.model._meta.app_label, self.model._meta.model_name
        urls = super(TagAdmin, self).get_urls()
        my_urls = patterns('',
            url(r'^autocomplete/$', self.admin_site.admin_view(self.ajax_autocomplete, cacheable=False), name="%s_%s_autocomplete" % info),
        )
        return my_urls + urls

    def ajax_autocomplete(self, request):
        tags = list()
        for tag in self.get_queryset(request).filter(name__startswith=request.GET.get("term", "")):
            tag_name = tag.name
            if (' ' in tag_name) == True:
                tag_name = '"%s"'%tag_name
            tags.append({'value': tag_name, 'text': tag_name})
        return HttpResponse(json.dumps(tags), content_type="application/json")

    class Media:
        js = (
            '/static/js/force_jquery.js',
            '/static/js/tabbed_translation_fields.js'
        )
        css = {
            'screen': ('/static/css/tabbed_translation_fields.css',),
        }

admin.site.unregister(TaggitTag)
admin.site.register(Tag, TagAdmin)
