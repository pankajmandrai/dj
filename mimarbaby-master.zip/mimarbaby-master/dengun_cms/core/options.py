from classytags.helpers import InclusionTag
from django.core.cache import cache
from django.template import TemplateDoesNotExist, TemplateSyntaxError
from django.template.loader import render_to_string
from django.core.exceptions import ObjectDoesNotExist
from django.utils import translation

from django.conf import settings
import hashlib


class MediaTag(object):

    def __eq__(self, other):
        return self.__class__.__name__ == other.__class__.__name__


class CmsTag(MediaTag):
    form = None
    icon = 'puzzle-piece'
    required = False
    verbose_name = ''
    verbose_name_plural = ''
    order = 0
    app = ''


"""
from django.core.cache import caches

for cache in caches.all():
    print cache._cache.keys()

"""


def cms_context(context, new_context):
    new_context.update({
        'current_page': context.get('current_page', None),
        'current_page_cache': context.get('current_page_cache', None),
        'current_page_update_cache': context.get('current_page_update_cache', False)
    })

    return new_context


def get_or_cache_pk(model, pk, context):
    obj = None

    if 'current_page_cache' in context:
        is_cache_enabled = True
        current_page_cache = context.get('current_page_cache', None)
    else:
        is_cache_enabled = False
        current_page_cache = {}

    if is_cache_enabled:
        model_name = "%s|%s" % (model._meta.app_label, model.__name__)
        pk = int(pk)

        if current_page_cache and model_name in current_page_cache:
            model_cache = current_page_cache.get(model_name)
            obj = model_cache.get(pk, None)
        elif current_page_cache:
            current_page_cache[model_name] = {}
        else:
            current_page_cache = {}
            current_page_cache[model_name] = {}

    if obj is None:
        obj = model.objects.get(pk=pk)
        if is_cache_enabled:
            current_page_cache[model_name][pk] = obj
            context.update({
                'current_page_cache': current_page_cache,
                'current_page_update_cache': True
            })

    return obj


class CmsInclusionTag(InclusionTag, CmsTag):
    cache = 0
    _tag_hash = None

    def create_tag_hash(self, **kwargs):
        try:
            if self._tag_hash is None:
                tag_name = u"templatetag.%s" % self.name.lower()
                # sort kwargs
                kwargs.update(kwargs.pop('options', None))
                tag_params = {k: v for k, v in kwargs.iteritems() if not isinstance(v, (dict, list))}
                tag_code = ''
                for key in sorted(tag_params.iterkeys()):
                    tag_code = "%s-%s:%s" % (tag_code, key, tag_params[key])

                code = (tag_name, self.template, tag_code)
                self._tag_hash = hashlib.md5("%s-%s-%s" % code).hexdigest()[:8]
        except:
            pass

    def hash_tag(self, kwargs):
        data = kwargs.copy()
        options = data.pop('options')
        result = sorted(data.items()) + sorted(options.items())
        cache_name = "%sLANG[%s]" % (str([u"%s=%s" % x for x in result]), translation.get_language())
        cache_name = u"templatetag.cache.%s.%s" % (self.name.lower(), hashlib.md5(cache_name).hexdigest())
        return cache_name

    def render_tag(self, context, **kwargs):
        # Create TAG_ID
        self.create_tag_hash(**kwargs)

        is_editing_mypage = 'is_editing_mypage' in context
        safe_context = {
            'tag': self
        }
        # GET CACHED TAGS
        cache_name = None
        if self.cache and not is_editing_mypage:
            cache_name = self.hash_tag(kwargs)
            cached_result = cache.get(cache_name)
            if cached_result is not None:
                return cached_result

        # escape template tag errors
        try:
            output = super(CmsInclusionTag, self).render_tag(context, **kwargs)
            if self.cache and not is_editing_mypage and cache_name:
                cache.set(cache_name, output, self.cache)
            return output

        except TemplateSyntaxError as e:
            safe_context.update({
                'exception': e,
                'exception_type': 'TemplateSyntaxError'
            })
        except TemplateDoesNotExist as e:
            safe_context.update({
                'exception': e,
                'exception_type': 'TemplateDoesNotExist'
            })
        except ObjectDoesNotExist as e:
            safe_context.update({
                'exception': e,
                'exception_type': 'DoesNotExist'
            })

        if is_editing_mypage or settings.DEBUG:
            return render_to_string('cms/template_tag_error.html', safe_context)

        return ''

    @property
    def tag_hash(self):
        return self._tag_hash
