from django.utils.translation import ugettext_lazy as _
from django.conf import settings
from modeltranslation.utils import get_translation_fields
from taggit.managers import TaggableManager as TaggitTaggableManager
from taggit.managers import _TaggableManager as _TaggitTaggableManager
from dengun_cms.core.fields import TagField
from dengun_cms.core.models import TaggedItem
from django.utils import six
from django.db.models import Q

def get_tag_from_language(TAG_MODEL, tag):
    for field in get_translation_fields('name'):
        query = {}
        query[field] = tag
        try:
            return TAG_MODEL.objects.get(**query)
        except TAG_MODEL.DoesNotExist:
            pass
    return None


class _TaggableManager(_TaggitTaggableManager):
    def add(self, *tags):
        str_tags = set()
        tag_objs = set()

        TAG_MODEL = self.through.tag_model()

        for t in tags:
            if isinstance(t, TAG_MODEL):
                tag_objs.add(t)
            elif isinstance(t, six.string_types):
                str_tags.add(t)
            else:
                raise ValueError("Cannot add {0} ({1}). Expected {2} or str.".format(
                    t, type(t), type(TAG_MODEL)))

        # If str_tags has 0 elements Django actually optimizes that to not do a
        # query.  Malcolm is very smart.
        existing = TAG_MODEL.objects.filter(
            name__in=str_tags
        )
        tag_objs.update(existing)

        for new_tag in str_tags - set(t.name for t in existing):
            tag_obj = get_tag_from_language(TAG_MODEL, new_tag)
            if not tag_obj:
                tag_obj = TAG_MODEL.objects.create(name=new_tag)
            tag_objs.add(tag_obj)

        for tag in tag_objs:
            self.through.objects.get_or_create(tag=tag, **self._lookup_kwargs())

        for tag in TAG_MODEL.objects.filter(Q(slug_pt=None) | Q(slug_es=None)):
            if tag.slug_pt is None:
                tag.slug_pt = tag.slug
                tag.save()
            if tag.slug_es is None:
                tag.slug_es = tag.slug            
                tag.save()

class TaggableManager(TaggitTaggableManager):
    max_items = None

    def __init__(self, **kwargs):
        if 'max_items' in kwargs:
            self.max_items = kwargs['max_items']
            del kwargs['max_items']
        super(TaggableManager, self).__init__(**kwargs)
        self.through = kwargs.get('through', TaggedItem)
        try:
            self.tag_model = self.through._meta.get_field('tag').rel.to
        except:
            self.tag_model = None

        self.manager = _TaggableManager

    def formfield(self, form_class=TagField, **kwargs):
        form_class.tag_model = self.tag_model
        form_class.max_items = self.max_items
        return super(TaggableManager, self).formfield(form_class=form_class, **kwargs)



# Add introspection rules for South database migrations
# See http://south.aeracode.org/docs/customfields.html
try:
    import south
except ImportError:
    south = None

if south is not None and 'south' in settings.INSTALLED_APPS:
    from south.modelsinspector import add_ignored_fields
    add_ignored_fields(["^taggit\.managers",r'^dengun_cms\.core\.managers\.TaggableManager'])