default_app_config = 'dengun_cms.core.apps.DengunCmsConfig'
