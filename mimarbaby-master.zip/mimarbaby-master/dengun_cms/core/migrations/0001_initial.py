# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.utils.timezone
import mptt.fields


class Migration(migrations.Migration):

    dependencies = [
        ('contenttypes', '0002_remove_content_type_name'),
        ('sites', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Page',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('seo_title', models.CharField(help_text='Leave blank to use the default page title.', max_length=70, verbose_name='SEO Title', blank=True)),
                ('seo_title_pt', models.CharField(help_text='Leave blank to use the default page title.', max_length=70, null=True, verbose_name='SEO Title', blank=True)),
                ('seo_title_en', models.CharField(help_text='Leave blank to use the default page title.', max_length=70, null=True, verbose_name='SEO Title', blank=True)),
                ('seo_title_es', models.CharField(help_text='Leave blank to use the default page title.', max_length=70, null=True, verbose_name='SEO Title', blank=True)),
                ('seo_description', models.CharField(help_text='Leave blank to use the default page description.', max_length=155, verbose_name='SEO Description', blank=True)),
                ('seo_description_pt', models.CharField(help_text='Leave blank to use the default page description.', max_length=155, null=True, verbose_name='SEO Description', blank=True)),
                ('seo_description_en', models.CharField(help_text='Leave blank to use the default page description.', max_length=155, null=True, verbose_name='SEO Description', blank=True)),
                ('seo_description_es', models.CharField(help_text='Leave blank to use the default page description.', max_length=155, null=True, verbose_name='SEO Description', blank=True)),
                ('title', models.CharField(max_length=140, verbose_name='title')),
                ('title_pt', models.CharField(max_length=140, null=True, verbose_name='title')),
                ('title_en', models.CharField(max_length=140, null=True, verbose_name='title')),
                ('title_es', models.CharField(max_length=140, null=True, verbose_name='title')),
                ('creation_date', models.DateTimeField(auto_now_add=True)),
                ('changed_date', models.DateTimeField(auto_now=True)),
                ('publication_date', models.DateTimeField(default=django.utils.timezone.now, help_text='When the page should go live.', verbose_name='publication date', db_index=True)),
                ('publication_end_date', models.DateTimeField(help_text='When to expire the page. Leave empty to never expire.', null=True, verbose_name='publication end date', db_index=True, blank=True)),
                ('is_active', models.BooleanField(default=True, help_text='Designates whether this page should be treated as active. Unselect this instead of deleting pages.', verbose_name='active')),
                ('page_url', models.CharField(help_text="Example: 'about/contact'.", max_length=140, verbose_name='Url / Handle', db_index=True)),
                ('page_url_pt', models.CharField(help_text="Example: 'about/contact'.", max_length=140, null=True, verbose_name='Url / Handle', db_index=True)),
                ('page_url_en', models.CharField(help_text="Example: 'about/contact'.", max_length=140, null=True, verbose_name='Url / Handle', db_index=True)),
                ('page_url_es', models.CharField(help_text="Example: 'about/contact'.", max_length=140, null=True, verbose_name='Url / Handle', db_index=True)),
                ('extend_template', models.CharField(help_text="Example: 'mypages/new_base.html'. If this isn't provided, the system will use 'base.html'.", max_length=70, verbose_name='template', blank=True)),
                ('registration_required', models.BooleanField(default=False, help_text='If this is checked, only logged-in users will be able to view the page.', verbose_name='registration required')),
                ('auto_page_url', models.BooleanField(default=True, help_text='I know what i am doing.', verbose_name='Automatic Page Handler')),
                ('in_navigation', models.BooleanField(default=True, db_index=True, verbose_name='in navigation')),
                ('is_home', models.BooleanField(default=False, db_index=True)),
                ('lft', models.PositiveIntegerField(editable=False, db_index=True)),
                ('rght', models.PositiveIntegerField(editable=False, db_index=True)),
                ('tree_id', models.PositiveIntegerField(editable=False, db_index=True)),
                ('level', models.PositiveIntegerField(editable=False, db_index=True)),
                ('parent', mptt.fields.TreeForeignKey(related_name='children', verbose_name='Parent Page', blank=True, to='cms.Page', null=True)),
                ('site', models.ForeignKey(related_name='denguncms_pages', default=b'1', verbose_name='site', to='sites.Site', help_text='The site the page is accessible at.')),
            ],
            options={
                'ordering': ('page_url',),
                'db_table': 'mypage',
                'verbose_name': 'Page',
                'verbose_name_plural': 'Pages',
            },
        ),
        migrations.CreateModel(
            name='PageContent',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('unique_name', models.SlugField(unique=True, verbose_name='unique name')),
                ('content', models.TextField(verbose_name='content')),
                ('content_pt', models.TextField(null=True, verbose_name='content')),
                ('content_en', models.TextField(null=True, verbose_name='content')),
                ('content_es', models.TextField(null=True, verbose_name='content')),
            ],
            options={
                'db_table': 'mypage_content',
                'verbose_name': 'Page Content',
                'verbose_name_plural': 'Pages Content',
            },
        ),
        migrations.CreateModel(
            name='Tag',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(unique=True, max_length=100, verbose_name='Name')),
                ('name_pt', models.CharField(max_length=100, unique=True, null=True, verbose_name='Name')),
                ('name_en', models.CharField(max_length=100, unique=True, null=True, verbose_name='Name')),
                ('name_es', models.CharField(max_length=100, unique=True, null=True, verbose_name='Name')),
                ('slug', models.SlugField(unique=True, max_length=100, verbose_name='Slug')),
                ('slug_pt', models.SlugField(max_length=100, unique=True, null=True, verbose_name='Slug')),
                ('slug_en', models.SlugField(max_length=100, unique=True, null=True, verbose_name='Slug')),
                ('slug_es', models.SlugField(max_length=100, unique=True, null=True, verbose_name='Slug')),
            ],
            options={
                'db_table': 'tags',
                'verbose_name': 'Tag',
                'verbose_name_plural': 'Tags',
            },
        ),
        migrations.CreateModel(
            name='TaggedItem',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('object_id', models.IntegerField(verbose_name='Object id', db_index=True)),
                ('content_type', models.ForeignKey(related_name='cms_taggeditem_tagged_items', verbose_name='Content type', to='contenttypes.ContentType')),
                ('tag', models.ForeignKey(related_name='cms_taggeditem_items', to='cms.Tag')),
            ],
            options={
                'db_table': 'tagged_items',
                'verbose_name': 'Tag',
                'verbose_name_plural': 'Tags',
            },
        ),
    ]
