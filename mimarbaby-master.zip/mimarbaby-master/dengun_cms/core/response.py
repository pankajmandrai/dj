from django.http import HttpResponseRedirect
from django.template.response import TemplateResponse
from dengun_cms.core.exceptions import CmsTagRedirect


class CmsTemplateResponse(TemplateResponse):
    # handle CmsTagRedirect
    def render(self):
        try:
            return super(TemplateResponse, self).render()
        except CmsTagRedirect as redirect_url:
            return HttpResponseRedirect(redirect_url)
