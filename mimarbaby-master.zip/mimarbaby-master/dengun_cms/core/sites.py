import os
import inspect
from django.template.base import (
    InvalidTemplateLibrary, get_library, get_templatetags_modules,
    libraries,
)
from importlib import import_module
from functools import update_wrapper
from django.http import HttpResponse, Http404, HttpResponseRedirect, HttpResponseForbidden
from django.views.decorators.csrf import csrf_protect
from django.core.exceptions import ImproperlyConfigured
from django.core.urlresolvers import reverse, NoReverseMatch
from django.template.response import TemplateResponse
from django.conf import settings
from django.utils import six
from django.utils.text import capfirst
from django.utils.translation import ugettext as _
from django.views.decorators.cache import never_cache
from django.utils._os import upath

from dengun_cms.core.options import CmsTag

import json


# GET TEMPLATE TAG LIBRARIES
def load_all_installed_cms_template_libraries():
    # Load/register all template tag libraries from installed apps.
    for module_name in get_templatetags_modules():

        mod = import_module(module_name)
        try:
            libraries = [
                os.path.splitext(p)[0]
                for p in os.listdir(os.path.dirname(upath(mod.__file__)))
                if p.endswith('.py') and p[0].isalpha()
            ]
        except OSError:
            continue
        else:
            for library_name in libraries:
                try:
                    get_library(library_name)
                except InvalidTemplateLibrary:
                    pass


# GET TAG BY NAME
def get_cms_template_tag(name):
    if name:
        load_all_installed_cms_template_libraries()
        for lib_name, lib in six.iteritems(libraries):
            if lib_name.endswith("_tags"):
                for tag_name, tag in six.iteritems(lib.tags):
                    if inspect.isclass(tag) and issubclass(tag, CmsTag) and tag.name == name:
                        return tag
    return None


# GET THEM ALL
def get_all_cms_template_tags():
    load_all_installed_cms_template_libraries()
    for lib_name, lib in six.iteritems(libraries):
        if lib_name.endswith("_tags"):
            for tag_name, tag in six.iteritems(lib.tags):
                if inspect.isclass(tag) and issubclass(tag, CmsTag):
                    yield tag


class CMS(object):
    """
    An CMS object encapsulates an instance of the Dengun cms application, ready
    to be hooked in to your URLconf.
    """

    def __init__(self, name='cms', app_name='cms'):
        self.name = name
        self.app_name = app_name

    def has_permission(self, request):
        """
        Returns True if the given HttpRequest has permission to view
        *at least one* page in the admin site.
        """
        return request.user.is_active and request.user.is_staff

    def cms_view(self, view, cacheable=False):
        """
        Decorator to create an cms view attached to this ``CMS``. This
        wraps the view and provides permission checking by calling
        ``self.has_permission``.

        You'll want to use this from within ``CMS.get_urls()``:

            class MyCMS(CMS):

                def get_urls(self):
                    from django.conf.urls import patterns, url

                    urls = super(CMS, self).get_urls()
                    urls += patterns('',
                        url(r'^my_view/$', self.cms_view(some_view))
                    )
                    return urls

        By default, admin_views are marked non-cacheable using the
        ``never_cache`` decorator. If the view can be safely cached, set
        cacheable=True.
        """
        def inner(request, *args, **kwargs):
            if not self.has_permission(request):
                return HttpResponseForbidden()
            return view(request, *args, **kwargs)

        if not cacheable:
            inner = never_cache(inner)
        # We add csrf_protect here so this function can be used as a utility
        # function for any view, without having to repeat 'csrf_protect'.
        if not getattr(view, 'csrf_exempt', False):
            inner = csrf_protect(inner)
        return update_wrapper(inner, view)

    def get_urls(self):
        from django.conf.urls import patterns, url, include

        def wrap(view, cacheable=False):
            def wrapper(*args, **kwargs):
                return self.cms_view(view, cacheable)(*args, **kwargs)
            return update_wrapper(wrapper, view)

        # Admin-site-wide views.
        urlpatterns = patterns('',
            url(r'^ajax/set/$', wrap(self.ajax_set_view), name='ajax_set'),
            url(r'^ajax/tag/form/$', wrap(self.tag_form), name='tag_form'),
            url(r'^language/(?P<lang_code>[a-zA-Z0-9_-]+)/$', wrap(self.language), name='language'),
            url(r'^kitchen/$', wrap(self.kitchen), name='kitchen')
        )

        return urlpatterns

    @property
    def urls(self):
        return self.get_urls(), self.app_name, self.name

    # VIEWS
    def kitchen(self, request):
        if request.user.is_authenticated() and request.user.is_staff:
            return TemplateResponse(request, 'cms/kitchen.html', {})
        raise Http404

    def language(self, request, lang_code):
        if request.user.is_authenticated() and request.user.is_staff:
            request.session['editor_language'] = lang_code
            return HttpResponseRedirect(request.META['HTTP_REFERER'])
        raise Http404

    def ajax_set_view(self, request):
        if request.user.is_authenticated() and request.user.is_staff and request.is_ajax():
            context = {}
            # SESSION SETTER
            session_value = request.GET.get('value', None)
            session_name = request.GET.get("session", None)
            if session_name:
                request.session[session_name] = session_value
                context.update({session_name: session_value})
            return HttpResponse(json.dumps(context), content_type="application/json")
        raise Http404

    def tag_form(self, request):
        if request.method == "POST":
            cms_tag_name = request.POST.get("cms_tag_name", None)
            create = request.POST.get("cms_create", False)
        elif request.method == "GET":
            cms_tag_name = request.GET.get("cms_tag_name", None)
            create = request.GET.get("cms_create", False)

        tag = get_cms_template_tag(cms_tag_name)
        name = getattr(tag, 'verbose_name', tag.name)
        icon = getattr(tag, 'icon', None)

        form = None
        if tag.form:
            if request.method == "POST":
                form = tag.form(request.POST)
                if form.is_valid():
                    return HttpResponse(json.dumps({"status": "ok"}), content_type="application/json")
            else:
                if create:
                    form = tag.form()
                else:
                    form = tag.form(request.GET)

        context = {
            'name': name,
            'icon': icon,
            'form': form,
            'cms_tag_name': cms_tag_name,
            'editor_language': request.session.get('editor_language', settings.LANGUAGE_CODE)
        }

        return TemplateResponse(request, 'cms/tag_form.html', context)





site = CMS()
