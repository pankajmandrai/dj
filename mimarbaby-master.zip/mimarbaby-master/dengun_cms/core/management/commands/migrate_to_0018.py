# -*- coding: utf-8 -*-
from django.core.management.base import NoArgsCommand
from django.db import connection, OperationalError
from django.apps import apps


class Command(NoArgsCommand):
    help = 'Migrate a cms django1.6 project to django1.8'

    def alter_table(self, old_name, new_name, schema_editor):
        try:
            schema_editor.alter_db_table(None, old_name, new_name)
        except OperationalError, msg:
            self.stdout.write('SKIP: %s ' % msg)

    def handle_noargs(self, **options):
        """
        Command execution.
        """
        with connection.schema_editor() as schema_editor:
            # MIGRATE BLOG APP
            if apps.is_installed('dengun_cms.blog'):
                self.stdout.write('Migrating Blog')
                self.alter_table('blog_archive', 'cms_blog_archive', schema_editor)
                self.alter_table('blog_article', 'cms_blog_article', schema_editor)
                self.alter_table('blog_article_photos', 'cms_blog_article_photos', schema_editor)
                self.alter_table('blog_author', 'cms_blog_author', schema_editor)
                self.alter_table('blog_authorimage', 'cms_blog_authorimage', schema_editor)

            # MIGRATE EVENTS APP
            if apps.is_installed('dengun_cms.events'):
                self.stdout.write('Migrating Events')

            # MIGRATE DOCUMENTS APP
            if apps.is_installed('dengun_cms.documents'):
                self.stdout.write('Migrating Documents')
                self.alter_table('documents_archive', 'cms_documents_archive', schema_editor)
                self.alter_table('documents_filesupload', 'cms_documents_filesupload', schema_editor)

            # MIGRATE FAQS APP
            if apps.is_installed('dengun_cms.faqs'):
                self.stdout.write('Migrating Faqs')
                self.alter_table('faqs_faq', 'cms_faqs_faq', schema_editor)
                self.alter_table('faqs_faqcategory', 'cms_faqs_faqcategory', schema_editor)

            # MIGRATE EVENTS APP
            if apps.is_installed('dengun_cms.testimonials'):
                self.stdout.write('Migrating Testimonials')
                self.alter_table('testimonials_testimonial', 'cms_testimonials_testimonial', schema_editor)
                self.alter_table('testimonials_testimonialcategory', 'cms_testimonials_testimonialcategory', schema_editor)
                self.alter_table('testimonials_testimonialimage', 'cms_testimonials_testimonialimage', schema_editor)

        self.stdout.write('Successfully migrated database to 1.8')
