# -*- coding: utf-8 -*-
import os
from urlparse import urlparse
from django.core.management.base import BaseCommand, CommandError

import shutil
import urllib2
import requests
import requests.packages.urllib3

from django.core.files import File
from django.utils.text import slugify

from django.contrib.sites.models import Site
from dengun_cms.mypages.models import Page, PageContent
from dengun_cms.documents.models import FilesUpload
from dengun_cms.media.models import MediaPhoto, MediaGallery
import json
import re


requests.packages.urllib3.disable_warnings()


def get_title_from_object(content_object, lang=None):
    if lang and lang in content_object['modeltranslation']:
        content_object = content_object['modeltranslation'][lang]

    if content_object['title']:
        return content_object['title']

    return None


def get_content_from_object(content_object, lang=None):
    if lang and 'modeltranslation' in content_object and lang in content_object['modeltranslation']:
        content_object = content_object['modeltranslation'][lang]

    if content_object['content']:
        # handle iframes
        output = content_object['content']
        iframe_regex = r'(<iframe(.*)>.*?<\/iframe>)'
        m = re.search(iframe_regex, content_object['content'])
        attrs_regex = r'(?P<attr>src|height)=["\'](?P<value>\S*?)["\']'
        if m:
            result = m.groups()
            height = 400
            src = ""
            for attr in re.findall(attrs_regex, result[1]):
                if 'height' == attr[0]:
                    height = attr[1]
                elif 'src' == attr[0]:
                    src = attr[1]

            # Handle youtube
            if src and re.search(r'youtube\.com', src):
                replace_iframe_attrs = ' allowfullscreen="true" allowscriptaccess="always" frameborder="0" height="%s" scrolling="no" src="%s" width="100%%"' % (height, src)
                new_iframe = result[0].replace(result[1], replace_iframe_attrs)
                iframe_handle = '<div class="embeddedContent oembed-provider-youtube" data-align="none" data-maxheight="%s" data-maxwidth="100%%" data-oembed="%s" data-oembed_provider="youtube" data-resizetype="custom">%s</div>' % (height, src, new_iframe)
                output = output.replace(result[0], iframe_handle)

                return output

        return content_object['content']

    return None


def get_description_from_object(content_object, lang=None):
    if lang and lang in content_object['modeltranslation']:
        content_object = content_object['modeltranslation'][lang]

    if content_object['description']:
        return content_object['description']

    return None


def get_seo_title_from_object(content_object, lang=None):
    if lang and lang in content_object['modeltranslation']:
        content_object = content_object['modeltranslation'][lang]

    if content_object['seo_title']:
        return content_object['seo_title']

    return None


def get_seo_description_from_object(content_object, lang=None):
    if lang and lang in content_object['modeltranslation']:
        content_object = content_object['modeltranslation'][lang]

    if content_object['seo_description']:
        return content_object['seo_description']

    return None


def get_title_and_content_from_object(content_object, lang=None):
    if lang and lang in content_object['modeltranslation']:
        content_object = content_object['modeltranslation'][lang]

    title = ""
    if content_object['title']:
        title = "<h2>%s</h2>" % content_object['title']

    content = get_content_from_object(content_object, lang=lang)

    if not content_object['title'] and not content:
        return None
    return "%s%s" % (title, content)


def get_display_text_from_object(content_object, lang=None):
    if lang and lang in content_object['modeltranslation']:
        content_object = content_object['modeltranslation'][lang]

    if content_object['display_text']:
        return content_object['display_text']

    return None


def get_target_from_object(content_object, lang=None):
    if lang and lang in content_object['modeltranslation']:
        content_object = content_object['modeltranslation'][lang]

    if content_object['target']:
        return content_object['target']

    return None


def get_filename_from_url(url):
    return os.path.basename(urlparse(url).path)


def cleanup_url(url):
    if url.startswith("/"):
        url = url[1:]
    if url.endswith("/"):
        url = url[:-1]
    return url


def clean_up_page_url(content_object, lang=None):
    if lang and lang in content_object['modeltranslation']:
        content_object = content_object['modeltranslation'][lang]

    if content_object['url']:
        return cleanup_url(content_object['url'])

    return None


def get_col_size(block):
    if block['size'] == 6:
        return 'col-md-12'
    elif block['size'] == 5:
        return 'col-md-10'
    elif block['size'] == 4:
        return 'col-md-8'
    elif block['size'] == 3:
        return 'col-md-6'
    elif block['size'] == 2:
        return 'col-md-4'
    elif block['size'] == 1:
        return 'col-md-2'
    else:
        return 'col-md-12'


class Command(BaseCommand):
    help = ('Import CMS content from a json file.')

    def add_arguments(self, parser):
        parser.add_argument('source', type=file)

    def handle(self, *args, **options):
        from django.conf import settings

        current_languages = [l[0] for l in settings.LANGUAGES]

        source = options.get('source')
        data = json.load(source)

        if 'domain' in data:
            domain = data['domain']
        else:
            raise CommandError("Source requires 'domain'")

        if 'files_path' in data:
            files_path = data['files_path']
        else:
            raise CommandError("Source requires 'files_path'")

        self.stdout.write('Copying content from "%s" to these languages: %s' % (source.name, ', '.join(current_languages)))

        content_slugs = {}
        # import content
        if 'content' in data:
            for item in data['content']:
                if item['title']:
                    slug_name = slugify(item['title'])
                else:
                    slug_name = "imported-content-%s" % item['id']

                # if slug_name exists, append id
                if slug_name in content_slugs.values():
                    slug_name = "%s-%s" % (slug_name, item['id'])

                obj, created = PageContent.objects.get_or_create(
                    unique_name=slug_name,
                    defaults={'content': get_title_and_content_from_object(item)},
                )

                for lang in current_languages:
                    lang_content = get_title_and_content_from_object(item, lang=lang)
                    if lang_content:
                        setattr(obj, 'content_%s' % lang, lang_content)

                obj.save()

                content_slugs[item['id']] = slug_name

            print content_slugs

        # import files
        if 'files' in data:
            all_file_ids = FilesUpload.objects.values_list('id', flat=True).all()
            for item in data['files']:
                if item['id'] in all_file_ids:
                    continue
                url = "%s/%s" % (files_path, item['file'])
                self.stdout.write("Downloading %s" % url, ending='')
                response = requests.get(url, stream=True, verify=False)
                filename = "/tmp/%s" % get_filename_from_url(url)
                self.stdout.write(" ..[%s]" % response.status_code)
                if response.status_code == 200:
                    with open(filename, "wb") as f:
                        f.write(response.content)

                    reopen = open(filename, "rb")
                    django_file = File(reopen)

                    obj, created = FilesUpload.objects.get_or_create(
                        id=item['id'],
                        defaults={
                            'title': get_title_from_object(item),
                            'upfile': django_file
                        },
                    )
                    for lang in current_languages:
                        lang_title = get_title_from_object(item, lang=lang)
                        if lang_title:
                            setattr(obj, 'title_%s' % lang, lang_title)

                    obj.save()

                    # CLEAN UP TMP
                    if obj.id:
                        try:
                            os.remove(filename)
                        except OSError:
                            pass

        # import images
        if 'images' in data:
            all_images_ids = MediaPhoto.objects.values_list('id', flat=True).all()
            for item in data['images']:
                if item['id'] in all_images_ids:
                    continue
                url = "%s/%s" % (files_path, item['image'])
                self.stdout.write("Downloading %s" % url, ending='')
                response = requests.get(url, stream=True, verify=False)
                filename = "/tmp/%s" % get_filename_from_url(url)
                self.stdout.write(" ..[%s]" % response.status_code)
                if response.status_code == 200:
                    with open(filename, "wb") as f:
                        f.write(response.content)

                    reopen = open(filename, "rb")
                    django_file = File(reopen)

                    obj, created = MediaPhoto.objects.get_or_create(
                        id=item['id'],
                        defaults={
                            'caption': get_title_from_object(item),
                            'image': django_file
                        },
                    )

                    # CLEAN UP TMP
                    if obj.id:
                        try:
                            os.remove(filename)
                        except OSError:
                            pass

        # import galleries
        if 'galleries' in data:
            gallery_slugs = {}
            for item in data['galleries']:
                slug_title = slugify(item['title'])

                # if slug_name exists, append id
                if slug_title in gallery_slugs.values():
                    slug_title = "%s-%s" % (slug_title, item['id'])

                obj, created = MediaGallery.objects.get_or_create(
                    id=item['id'],
                    defaults={
                        'slug': slug_title,
                        'title': get_title_from_object(item),
                        'description': get_description_from_object(item),
                    },
                )

                for lang in current_languages:
                    lang_title = get_title_from_object(item, lang=lang)
                    if lang_title:
                        setattr(obj, 'title_%s' % lang, lang_title)

                    lang_description = get_description_from_object(item, lang=lang)
                    if lang_description:
                        setattr(obj, 'description_%s' % lang, lang_description)

                obj.photos.clear()
                obj.save()

                for image in item['images']:
                    obj.photos.add(image)

                gallery_slugs[item['id']] = slug_name

        context = {
            'content': content_slugs,
            'domain_name': domain,
            'languages': current_languages
        }
        # import pages
        if 'pages' in data:
            default_site = Site.objects.get_current()
            for item in data['pages']:
                default_url = clean_up_page_url(item)
                default_title = get_title_from_object(item)

                obj, created = Page.objects.get_or_create(
                    page_url=default_url,
                    defaults={
                        'auto_page_url': False,
                        'site': default_site,
                        'title': default_title,
                        'page_url': default_url,
                        'seo_title': get_seo_title_from_object(item),
                        'seo_description': get_seo_description_from_object(item),
                        'registration_required': item['registration_required'],
                    },
                )

                for lang in current_languages:
                    lang_title = get_title_from_object(item, lang=lang)
                    if lang_title:
                        setattr(obj, 'title_%s' % lang, lang_title)

                    lang_url = clean_up_page_url(item, lang=lang)
                    if lang_url:
                        setattr(obj, 'page_url_%s' % lang, lang_url)

                    lang_seo_title = get_seo_title_from_object(item, lang=lang)
                    if lang_seo_title:
                        setattr(obj, 'seo_title_%s' % lang, lang_seo_title)

                    lang_seo_description = get_seo_description_from_object(item, lang=lang)
                    if lang_seo_description:
                        setattr(obj, 'seo_description_%s' % lang, lang_seo_title)

                obj.save()

                # generate page template based on blocks
                if 'blocks' in item:
                    for lang in current_languages:
                        output = '<div class="container">\n\t<div class="row">'
                        block_buffer = 0
                        for block in item['blocks']:
                            if block_buffer >= 6:
                                output += '\n\t</div>\n\t<div class="row">'
                                block_buffer = 0

                            output += '\n\t\t<div class="col-xs-12 %s">' % get_col_size(block)
                            output += '\n\t\t\t'
                            output += render_block(block, context, lang=lang)
                            output += '\n\t\t</div>'

                            block_buffer += block['size']

                        output += '\n\t</div>\n</div>'

                        template_content = "{% extends current_page.extends %}\n"
                        template_content += "{% load cms_tags static mypage_tags media_tags document_tags %}\n\n"
                        template_content += "{% block content %}\n"
                        template_content += output
                        template_content += "\n{% endblock content %}\n"
                        obj.write_to_template(template_content, lang=lang)

        self.stdout.write('Done.')


def render_block(block, context, lang=None):
    if block['type'] == 'blankblock':
        return render_block_blankblock(block, context, lang=lang)
    elif block['type'] == 'seperatorblock':
        return render_block_seperatorblock(block, context, lang=lang)
    elif block['type'] == 'galleryblock':
        return render_block_galleryblock(block, context, lang=lang)
    elif block['type'] == 'imageblock':
        return render_block_imageblock(block, context, lang=lang)
    elif block['type'] == 'contentblock':
        return render_block_contentblock(block, context, lang=lang)
    elif block['type'] == 'calltoactionblock':
        return render_block_calltoactionblock(block, context, lang=lang)
    elif block['type'] == 'fileblock':
        return render_block_fileblock(block, context, lang=lang)
    elif block['type'] == 'googlemapblock':
        return render_block_googlemapblock(block, context, lang=lang)
    elif block['type'] == 'specialcontactformblock':
        return render_block_specialcontactformblock(block, context, lang=lang)
    elif block['type'] == 'contactformblock':
        return render_block_contactformblock(block, context, lang=lang)
    return block['type']


def render_block_blankblock(block, context, lang=None):
    default_title = get_title_from_object(block)
    lang_title = get_title_from_object(block, lang=lang)
    title = lang_title if lang_title else default_title

    default_content = get_content_from_object(block)
    lang_content = get_content_from_object(block, lang=lang)
    content = lang_content if lang_content else default_content

    output = "{% textblock %}"
    if title:
        output += "\n\t\t\t\t"
        output += "<h2>%s</h2>" % title
    if content:
        output += "\n\t\t\t\t"
        output += content

    output += "\n\t\t\t"
    output += "{% endtextblock %}"

    return output


def render_block_seperatorblock(block, context, lang=None):

    show_line = True
    if 'line' in block:
        show_line = True if block['line'] else False

    output = "{%% seperator show_line=%s %%}" % show_line
    return output


def render_block_galleryblock(block, context, lang=None):

    gallery_id = int(block['id'])
    if MediaGallery.objects.filter(id=gallery_id).exists():
        gallery_limit = ""
        if 'limit' in block:
            gallery_limit = " limit='%d'" % int(block['limit'])

        gallery_template = ""
        if 'display_type' in block and block['display_type'] != "gallery_s":
            gallery_template = " template='cms/media_gallery_cover.html'"
        output = "{%% media_gallery '%d'%s grid='3'%s title=None %%}" % (gallery_id, gallery_limit, gallery_template)
        return output
    else:
        return ""


def render_block_imageblock(block, context, lang=None):
    image_id = int(block['id'])
    try:
        photo = MediaPhoto.objects.get(id=image_id)
        image_alt = photo.caption
        if not image_alt:
            image_alt = "{{ current_page }}"
        image_tag = "{%% media_photo_src '%d' %%}" % photo.id
        return '<img src="%s" alt="%s" />' % (image_tag, image_alt)

    except MediaPhoto.DoesNotExist:
        pass

    return ""


def render_block_contentblock(block, context, lang=None):
    slug = context['content'][block['id']]
    return "{%% page_content '%s' %%}" % slug


def render_block_calltoactionblock(block, context, lang=None):
    default_display_text = get_display_text_from_object(block)
    lang_display_text = get_display_text_from_object(block, lang=lang)
    display_text = lang_display_text if lang_display_text else default_display_text

    display_text = display_text.replace("'", "")

    default_target = get_target_from_object(block)

    linkage = " href='%s'" % default_target

    if default_target:
        internal_page = test_target_for_internal_page(default_target, context)
        if internal_page:
            linkage = " page='%d'" % internal_page.pk

    output = "{%% call_to_action label='%s'%s %%}" % (display_text, linkage)
    return output


def test_target_for_internal_page(target, context):

    http = "http://"
    https = "https://"
    domain = context['domain_name']
    test_target = None
    if target.startswith(http):
        proto_domain = "%s%s" % (http, domain)
        proto_www_domain = "%swww.%s" % (http, domain)
        if target.startswith(proto_domain):
            test_target = target.replace(proto_domain, "")
        elif target.startswith(proto_www_domain):
            test_target = target.replace(proto_www_domain, "")
    elif target.startswith(https):
        proto_domain = "%s%s" % (https, domain)
        proto_www_domain = "%swww.%s" % (http, domain)
        if target.startswith(proto_domain):
            test_target = target.replace(proto_domain, "")
        elif target.startswith(proto_www_domain):
            test_target = target.replace(proto_www_domain, "")
    elif target.startswith("://"):
        proto_domain = "://%s" % domain
        proto_www_domain = "://www.%s" % domain
        if target.startswith(proto_domain):
            test_target = target.replace(proto_domain, "")
        elif target.startswith(proto_www_domain):
            test_target = target.replace(proto_www_domain, "")

    if test_target:
        lang_target = None
        for lang in context['languages']:
            if test_target.startswith("/%s" % lang):
                lang_target = lang
                test_target = test_target.replace("/%s" % lang, "")
                break

        if lang_target:
            cleaned_url = cleanup_url(test_target)
            try:
                page = Page.objects.get(page_url__exact=cleaned_url)
            except Page.DoesNotExist:
                page = None

            if not page:
                query_kwargs = {}
                query_kwargs["page_url_%s__exact" % lang] = cleaned_url
                try:
                    page = Page.objects.get(**query_kwargs)
                except Page.DoesNotExist:
                    page = None

            if page:
                return page

    return None


def render_block_fileblock(block, context, lang=None):
    file_id = int(block['id'])
    try:
        file = FilesUpload.objects.get(id=file_id)
        output = "{%% document_tag File='%d' %%}" % file.id
        return output
    except FilesUpload.DoesNotExist:
        pass

    return ""


def render_block_googlemapblock(block, context, lang=None):

    lat = block['latitude']
    lng = block['longitude']
    height = block['height']
    zoom = block['zoom']
    map_type = block['map_type']
    content_type = block['control_type']

    marker_content = ""
    if 'marker_description' in block and block['marker_description']:
        marker_content = " marker_content='%s'" % block['marker_description']

    show_navigation = ""
    if 'navigation' in block and not block['navigation']:
        show_navigation = " show_navigation=False"

    show_marker = ""
    if 'show_marker' in block and block['show_marker']:
        show_marker = " show_marker=True"

    output_args = (
        lat,
        lng,
        height,
        zoom,
        marker_content,
        show_navigation,
        show_marker,
        map_type,
        content_type
    )

    output = "{%% google_map '%s' '%s' height='%s' zoom='%s'%s%s%s map_type='%s' control_type='%s' enable_scroll=False %%}" % output_args
    return output


def render_block_contactformblock(block, context, lang=None):
    show_phone = ""
    if 'display_type' in block and block['display_type'] != "simple":
        show_phone = " show_phone=True"

    recipients = ""
    if 'specific_recipients' in block and block['specific_recipients']:
        recipients = " recipients='%s'" % block['specific_recipients']

    output = "{%% contact_form%s%s template='cms/contact_form/vertical.html' %%}" % (show_phone, recipients)
    return output


def render_block_specialcontactformblock(block, context, lang=None):
    return render_block_contactformblock(block, context, lang=lang)
