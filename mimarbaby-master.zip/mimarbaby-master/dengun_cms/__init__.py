VERSION = (1, 0, 1)

from dengun_cms.core.sites import site
