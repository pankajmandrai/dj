from django.db import models
from django.utils.encoding import python_2_unicode_compatible
from django.utils.translation import ugettext_lazy as _
from django.contrib.auth.models import Group
from dengun_cms.mypages.models import Page


@python_2_unicode_compatible
class Category(models.Model):
    name = models.CharField(_('Name'), max_length=140)
    mypages = models.ManyToManyField(Page, related_name='categories_mypages', blank=True)
    groups = models.ManyToManyField(
        Group, related_name='categories_groups', blank=True)
    extend_template = models.CharField(_('template'), max_length=70, blank=True,
        help_text=_("Example: 'mypages/new_base.html'. If this isn't provided, the system will use 'base.html'."))

    class Meta:
        app_label = 'cms_categories'
        ordering = ['pk']
        verbose_name = _("Category")
        verbose_name_plural = _("Categories")

    def __str__(self):
        return self.name
