from django import forms
from django.contrib import admin
from dengun_cms.mypages.forms import PageMpttForm
from .models import Category
from dengun_cms.mypages.models import Page


'''
 Admin form called by mypages in admin if categories is installed.

 adds category select field to mypage
'''


class CategoriesAdminForm(PageMpttForm):
    category = forms.ModelChoiceField(
        queryset=Category.objects.all(),
        required=True,
        widget=forms.Select(),
        empty_label=None,
        help_text='Change category to change permissions group',

    )

    def __init__(self, *args, **kwargs):
        super(CategoriesAdminForm, self).__init__(*args, **kwargs)

        groups = [x.pk for x in self.request.user.groups.all()]
        if not self.request.user.is_superuser:
            self.fields['category'].queryset = Category.objects.filter(
                groups__pk__in=groups)
            self.fields['parent'].queryset = Page.objects.filter(
                categories_mypages__groups__pk__in=groups)

        else:
            self.fields['category'].queryset = Category.objects.all()
            self.fields['parent'].queryset = Page.objects.all()

        if self.instance and self.instance.pk:
            self.fields['category'].initial = self.instance.categories_mypages.first()

    def save(self, commit=True):
        mypage = super(CategoriesAdminForm, self).save(commit=False)

        if commit:
            mypage.save()

        if mypage.pk:
            if self.cleaned_data['category']:
                mypage.categories_mypages = [self.cleaned_data['category']]
            else:
                mypage.categories_mypages = []
            self.save_m2m()

        return mypage

'''
Categories Admin app

'''


class CategoriesAdmin(admin.ModelAdmin):
    exclude = ('mypages',)
    filter_horizontal = ('groups',)


admin.site.register(Category, CategoriesAdmin)
