default_app_config = 'dengun_cms.categories.apps.DengunCmsCategoryConfig'
