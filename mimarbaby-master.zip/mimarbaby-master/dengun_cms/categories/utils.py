from dengun_cms.categories.models import Category

'''
 checks if user is on same category/group as page
'''


def has_mypages_permission(request, obj=None):

    category = Category.objects.filter(
        mypages=obj,
        groups__pk__in=request.user.groups.values_list('pk', flat=True)).exists()

    if not category and not request.user.is_superuser:
        return False

    return True
