# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('cms_categories', '0002_auto_20161116_1147'),
    ]

    operations = [
        migrations.AddField(
            model_name='category',
            name='extend_template',
            field=models.CharField(help_text="Example: 'mypages/new_base.html'. If this isn't provided, the system will use 'base.html'.", max_length=70, verbose_name='template', blank=True),
        ),
    ]
