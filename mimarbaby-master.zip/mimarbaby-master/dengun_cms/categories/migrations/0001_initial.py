# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('cms', '__first__'),
        ('auth', '0006_require_contenttypes_0002'),
    ]

    operations = [
        migrations.CreateModel(
            name='Category',
            fields=[
                ('id', models.AutoField(verbose_name='ID',
                                        serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=140, verbose_name='Name')),
                ('groups', models.ManyToManyField(
                    related_name='categories_groups', to='auth.Group', blank=True)),
                ('mypages', models.ManyToManyField(
                    related_name='categories_mypages', to='cms.Page', blank=True)),
            ],
        ),
    ]
