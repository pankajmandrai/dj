default_app_config = 'dengun_cms.auth.apps.DengunCmsAuthConfig'
