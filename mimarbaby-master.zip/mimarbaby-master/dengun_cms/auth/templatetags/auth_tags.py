from django import template
from classytags.core import Options
from classytags.arguments import MultiKeywordArgument
from classytags.helpers import InclusionTag

register = template.Library()


# LANGUAGE HELPER TAG
class AuthTools(InclusionTag):
    name = 'auth_tools'
    template = 'cms/auth_tools.html'

    options = Options(
        MultiKeywordArgument('options', required=False),
    )

    def get_template(self, context, options):
        if 'template' in options:
            return options['template']
        return self.template

    def get_context(self, context, options):

        default_options = {
            'show_user': True,
        }

        default_options.update(options or {})
        options = default_options

        context['show_user'] = options['show_user']
        return context

# UTIL TAGS
register.tag(AuthTools)
