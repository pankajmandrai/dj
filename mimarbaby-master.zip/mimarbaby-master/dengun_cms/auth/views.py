from django.template.response import TemplateResponse
from django.utils.translation import ugettext as _
from django.views.decorators.debug import sensitive_post_parameters
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.decorators import login_required
from dengun_cms.auth.forms import UserChangeForm


@sensitive_post_parameters()
@csrf_protect
@never_cache
@login_required
def profile(request, template_name='cms/profile.html', current_app=None, extra_context=None):
    """
    Displays the profile for the logged in user.
    """
    # SWITCH VIEW
    user = request.user
    if hasattr(user, 'get_profile_view_func'):
        return user.get_profile_view_func(request, current_app=current_app, extra_context=extra_context)

    context = {}
    if extra_context is not None:
        context.update(extra_context)
    return TemplateResponse(request, template_name, context,
                            current_app=current_app)


@sensitive_post_parameters()
@csrf_protect
@never_cache
@login_required
def edit_profile(request, template_name='cms/edit_profile.html', current_app=None, extra_context=None):
    """
    Displays the profile form and handles the profile changing action.
    """
    # SWITCH VIEW
    user = request.user
    if hasattr(user, 'get_edit_profile_view_func'):
        return user.get_edit_profile_view_func(request, current_app=current_app, extra_context=extra_context)

    form_done = False
    if request.method == "POST":
        form = UserChangeForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            form_done = True
    else:
        form = UserChangeForm(instance=request.user)

    context = {
        'form_done': form_done,
        'form': form
    }
    if extra_context is not None:
        context.update(extra_context)
    return TemplateResponse(request, template_name, context,
                            current_app=current_app)
