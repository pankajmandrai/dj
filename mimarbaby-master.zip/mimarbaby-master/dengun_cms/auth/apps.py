from django.apps import AppConfig
from django.utils.translation import ugettext_lazy as _


class DengunCmsAuthConfig(AppConfig):
    name = 'dengun_cms.auth'
    label = "cms_auth"
    verbose_name = _("Auth")
