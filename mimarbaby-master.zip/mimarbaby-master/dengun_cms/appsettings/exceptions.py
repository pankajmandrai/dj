class SettingsException(Exception):
    pass


class MultipleSettingsException(Exception):
    pass


class FormSettingsException(Exception):
    pass
