from django import forms


class IntegerField(forms.IntegerField):
    def __init__(self, *args, **kwargs):
        try:
            self.translate = kwargs.pop('translate')
        except:
            self.translate = False

        super(IntegerField, self).__init__(*args, **kwargs)


class FloatField(forms.FloatField):
    def __init__(self, *args, **kwargs):
        try:
            self.translate = kwargs.pop('translate')
        except:
            self.translate = False

        super(FloatField, self).__init__(*args, **kwargs)


class DecimalField(forms.DecimalField):
    def __init__(self, *args, **kwargs):
        try:
            self.translate = kwargs.pop('translate')
        except:
            self.translate = False

        super(DecimalField, self).__init__(*args, **kwargs)


class BooleanField(forms.BooleanField):
    def __init__(self, *args, **kwargs):
        try:
            self.translate = kwargs.pop('translate')
        except:
            self.translate = False

        super(BooleanField, self).__init__(*args, **kwargs)


class ChoiceField(forms.ChoiceField):
    def __init__(self, *args, **kwargs):
        try:
            self.translate = kwargs.pop('translate')
        except:
            self.translate = False

        super(ChoiceField, self).__init__(*args, **kwargs)


class CharField(forms.CharField):
    def __init__(self, *args, **kwargs):
        try:
            self.translate = kwargs.pop('translate')
        except:
            self.translate = False

        super(CharField, self).__init__(*args, **kwargs)
