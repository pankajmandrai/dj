import inspect
import copy
from django import forms
from django.conf import settings as base_settings
from django.contrib.sites.models import Site
from django.core.cache import cache
from django.utils import translation
from django.utils.encoding import force_unicode, force_text
from dengun_cms import appsettings
from dengun_cms.appsettings.models import Setting
from dengun_cms.appsettings.utils import proxy_settings, check_translate, field_langcode, remove_langcode
from dengun_cms.appsettings.exceptions import *


class Settings(object):
    discovered = False
    _state = {}

    def __new__(cls, *p, **k):
        self = object.__new__(cls, *p, **k)
        self.__dict__ = cls._state
        return self

    @classmethod
    def _reset(cls):
        """Reset all `Settings` object to the initial empty condition."""
        cls._state = {}

    def _register(self, appname, verbose_name, classobj, readonly=False, main=False):
        if not hasattr(self, appname):
            setattr(self, appname, App(appname, verbose_name))
        getattr(self, appname)._add(classobj, readonly, main, getattr(proxy_settings, appname)._dct)

    def update_from_db(self):
        settings = Setting.objects.all()
        for setting in settings:
            app = getattr(self, setting.app)
            if setting.group in app._vals:
                group = app._vals[setting.group]
                if setting.key in group._vals:
                    group._vals[setting.key].initial = group._vals[setting.key].clean(setting.value)
                else:
                    ## the app removed the setting... shouldn't happen
                    ## in production. maybe error? or del it?
                    pass


class App(object):
    def __init__(self, app, verbose_name):
        self._name = app
        self._vals = {}
        self._main = None

        if verbose_name:
            self._verbose_name = verbose_name
        else:
            self._verbose_name = app.title()

    def _add(self, classobj, readonly, main, preset):
        name = classobj.__name__.lower()
        # if isinstance(self._vals, collections.Iterable):
        #     if name in self._vals or (self._main is not None and name in self._vals[self._main]):
        #         raise SettingsException('duplicate declaration of settings group %s.%s' % (self._name, name))

        if name in ('_vals', '_add', '_name'):
            raise SettingsException('invalid group name: %s' % name)

        if not main:
            preset = preset.get(name, {})
        self._vals[name] = Group(self._name, name, classobj, preset, main)

        if readonly:
            self._vals[name]._readonly = readonly

        if main:
            if self._main is not None:
                raise SettingsException('multiple "main" groups defined for app %s' % self._name)
            self._main = name

    def __getattr__(self, name):
        if name not in ('_vals', '_name', '_add', '_main'):   # '_verbose_name'

            if name not in self._vals and self._main:

                print self._main
                print name
                print self._vals[self._main]._vals
                if name in self._vals[self._main]._vals:
                    return getattr(self._vals[self._main], name)
                # Set by Att KEY LANG - return cur language value
                try:
                    lang_code = translation.get_language()
                    return getattr(self._vals[self._main], name + '_' + lang_code)
                except:
                    pass

                raise SettingsException('group not found: %s' % name)

            return self._vals[name]

        return super(App, self).__getattribute__(name)

    def __setattr__(self, name, val):
        if name not in ('_vals', '_name', '_add', '_main') and self._main:  # , '_verbose_name'

            if name in self._vals[self._name]._vals:
                return setattr(self._vals[self._name], name, val)

            raise SettingsException('groups are immutable')
        super(App, self).__setattr__(name, val)


class Group(object):
    def __init__(self, appname, name, classobj, preset, main=False):
        self._appname = appname
        self._name = name

        self._vals = {}
        self._readonly = False
        self._cache_prefix = 'appsetting-%s-%s-%s-' % (Site.objects.get_current().pk, self._appname, self._name)

        self._verbose_name = name
        self._verbose_name_plural = '%ss' % name
        self._help_text = ''
        self._sorting = 0
        self._fieldsets = None
        self._translated_fields = []

        for attr in inspect.classify_class_attrs(classobj):
            # for Python 2.5 compatiblity, we use tuple indexes
            # instead of the attribute names (which are only available
            # from Python 2.6 onwards).  Here's the mapping:
            #   attr[0]  attr.name   Attribute name
            #   attr[1]  attr.kind   class/static method, property, data
            #   attr[2]  attr.defining_class  The `class` object that created this attr
            #   attr[3]  attr.object Attribute value
            #

            #print 'attr 0: %s   -    attr 3: %s' % (attr[0],attr[3])  # -  attr 1: %s  -  attr 2: %s  -
            if attr[2] != classobj or attr[1] != 'data':
                continue

            if attr[0].startswith('_'):
                continue

            if attr[0] == 'Meta':
                try:
                    self._verbose_name = attr[3].verbose_name
                except:
                    pass

                try:
                    self._verbose_name_plural = attr[3].verbose_name_plural
                except:
                    pass

                try:
                    self._help_text = attr[3].help_text
                except:
                    pass

                try:
                    self._sorting = attr[3].sorting
                except:
                    pass

                try:
                    self._fieldsets = attr[3].fieldsets
                except:
                    pass

                continue

            val = attr[3]
            key = attr[0]

            if type(val) == int:
                val = forms.IntegerField(label=key.title(), initial=val)

            elif type(val) == float:
                val = forms.FloatField(label=key.title(), initial=val)

            elif type(val) == str:
                val = forms.CharField(label=key.title(), initial=val)

            elif val in (True, False):
                val = forms.BooleanField(label=key.title(), initial=val)

            elif not isinstance(val, forms.Field):
                raise SettingsException('settings must be of a valid form field type')

            # is translated field?
            try:
                translate = val.translate
            except:
                translate = False

            if not translate:

                field = val

                if key in preset:
                    field.initial = preset[key]

                try:
                    field.initial = field.clean(field.initial)
                except forms.ValidationError:
                    if main:
                        raise SettingsException('setting %s.%s not set. Please set it in your settings.py' % (appname, key))
                    raise SettingsException('setting %s.%s.%s not set. Please set it in your settings.py' % (appname, name, key))

                # Append field
                field.class_name = '%s%s%s' % (self._appname, self._name, key)
                field.lang = ''
                field.label = force_text(field.label) if field.label else key.title()
                field._parent = self
                self._vals[key] = field

            else:

                self._translated_fields.append(key)
                # Translated Fields
                for lang_code, language in base_settings.LANGUAGES:

                    lang_key = key + '_' + lang_code

                    field = copy.deepcopy(val)

                    if key in preset:
                        field.initial = preset[lang_key]

                    try:
                        field.initial = val.clean(field.initial)
                    except forms.ValidationError:
                        if main:
                            raise SettingsException('setting %s.%s not set. Please set it in your settings.py' % (appname, key))
                        raise SettingsException('setting %s.%s.%s not set. Please set it in your settings.py' % (appname, name, key))

                    # Append field
                    field.class_name = '%s%s%s-%s' % (self._appname, self._name, key, lang_code)  # name-pt
                    field.lang = lang_code
                    field.label = '%s [%s]' % (force_text(field.label) if field.label else key.title(), lang_code)
                    field._parent = self
                    self._vals[lang_key] = field

            # check for updated values in table
            settings = Setting.objects.all().filter(app=self._appname, group=self._name)
            for setting in settings:
                if not translate:
                    if setting.key in self._vals:
                        self._vals[setting.key].initial = self._vals[setting.key].clean(setting.value)
                    else:
                        ## the app removed the setting... shouldn't happen
                        ## in production. maybe error? or del it?
                        pass
                else:
                    # Trasnlated Fields
                    for lang_code, language in base_settings.LANGUAGES:

                        setting_key = setting.key+'_'+lang_code

                        if setting_key in self._vals:
                            setting_value = setting.__dict__['value_'+lang_code]
                            self._vals[setting_key].initial = self._vals[setting_key].clean(setting_value)
                        else:
                            ## the app removed the setting... shouldn't happen
                            ## in production. maybe error? or del it?
                            pass

    # Get Value by key
    def __getattr__(self, name):

        if name not in ('_vals', '_name', '_appname', '_readonly', '_cache_prefix', '_verbose_name', '_verbose_name_plural', '_help_text', '_sorting', '_fieldsets', '_translated_fields'):

            translate = check_translate(name)

            if translate is True:

                lang_code = field_langcode(name)
                setting_key = name

                try:
                    setting = Setting.objects.get(app=self._appname, group=self._name, key=name)
                    return self._vals[setting_key].clean(setting.__dict__['value_'+lang_code])
                except Setting.DoesNotExist:
                    pass
            else:
                try:
                    setting = Setting.objects.get(app=self._appname, group=self._name, key=name)
                    return self._vals[setting.key].clean(setting.value)
                except:
                    pass

            # Set by Att KEY LANG - return cur language value
            try:
                lang_code = translation.get_language()
                setting = Setting.objects.get(app=self._appname, group=self._name, key=name)
                setting_key = name+'_'+lang_code
                return self._vals[setting_key].clean(setting.__dict__['value_'+lang_code])
            except:
                pass

            if name not in self._vals:
                raise AttributeError('setting "%s" not found' % name)

            if appsettings.USE_CACHE and self._cache_prefix+name in cache:
                return cache.get(self._cache_prefix+name)

            translate = check_translate(name)
            origin_name = remove_langcode(name)
            lang_code = field_langcode(name)

            if translate is True:
                try:
                    setting = Setting.objects.get(app=self._appname, group=self._name, key=origin_name)
                except Setting.DoesNotExist:
                    pass
                else:

                    setting_key = setting.key+'_'+lang_code
                    setting_value = setting.__dict__['value_'+lang_code]
                    return self._vals[setting_key].clean(setting_value)

            return self._vals[name].initial
        return super(Group, self).__getattribute__(name)

    def __setattr__(self, name, value):
        if name in ('_vals', '_name', '_appname', '_readonly', '_cache_prefix', '_verbose_name', '_verbose_name_plural', '_help_text', '_sorting', '_fieldsets', '_translated_fields'):
            return object.__setattr__(self, name, value)

        if self._readonly:
            raise AttributeError('settings group %s is read-only' % self._name)

        if not name in self._vals:
            raise AttributeError('setting "%s" not found' % name)

        self._vals[name].initial = self._vals[name].clean(value)

        translate = check_translate(name)

        if translate:
            origin_name = remove_langcode(name)
            lang_code = field_langcode(name)
        else:
            origin_name = name

        try:
            setting = Setting.objects.get(
                app=self._appname,
                site=Site.objects.get_current(),
                group=self._name,
                key=origin_name
            )
        except Setting.DoesNotExist:
            setting = Setting(
                site=Site.objects.get_current(),
                app=self._appname,
                group=self._name,
                key=origin_name
            )

        serialized = value
        if hasattr(self._vals[name].widget, '_format_value'):
            serialized = self._vals[name].widget._format_value(value)
        serialized = force_unicode(serialized)

        field_name = 'value'
        if translate:
            field_name = 'value_%s' % lang_code

        setattr(setting, field_name, serialized)
        setting.save()

        if appsettings.USE_CACHE:
            cache.set(self._cache_prefix+name, value)
