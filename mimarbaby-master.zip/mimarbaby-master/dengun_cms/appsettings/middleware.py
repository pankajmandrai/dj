from dengun_cms.appsettings.settingsobj import Settings
settingsinst = Settings()


class AppSettingsMiddleware(object):
    """
    Load the settings for each request.
    """
    def process_request(self, request):
        #settingsinst.update_from_db()
        request.appsettings = settingsinst
