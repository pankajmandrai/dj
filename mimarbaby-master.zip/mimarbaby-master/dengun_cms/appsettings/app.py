from dengun_cms.appsettings import settingsobj
appsettings = settingsobj.Settings()
if not settingsobj.Settings.discovered:
    from dengun_cms.appsettings import autodiscover
    autodiscover()
