from django.db import models
from django.contrib.sites.models import Site


class Setting(models.Model):
    site = models.ForeignKey(Site)
    app = models.CharField(max_length=255)
    group = models.CharField(max_length=255, blank=True)
    key = models.CharField(max_length=255)
    value = models.TextField(blank=True)
