from django.conf import settings as base_settings
from itertools import chain


def check_translate(name=None):
    checklang = name[-3:]
    lang_code = checklang.replace("_", "")
    if lang_code in chain(*base_settings.LANGUAGES):
        return True
    else:
        return False


def field_langcode(name=None):
    return name[-3:].replace("_", "")


def remove_langcode(name=None):
    return name[:-3].strip()


def get_translation_fields(key):
    trans_field = ()
    for lang_code, language in base_settings.LANGUAGES:
        lang_key = key + '_' + lang_code
        trans_field += (lang_key,)
    return trans_field


def get_translated_fieldsets(app, group):

    trans_fieldsets = []
    fieldsets = group._fieldsets
    trans_fields = group._translated_fields

    for name, data in fieldsets:

        title = name
        fields = data.get('fields', ())
        classes = ' '.join(map(str, data.get('classes', ())))
        description = data.get('description')
        new_fields = []

        for field in fields:
            field_name = '%s-%s-%s' % (app._name, group._name, field)

            # Fields in Tuple
            if isinstance(field, (tuple, list)):
                key_fields = ()
                for key in field:
                    field_name = ('%s-%s-%s' % (app._name, group._name, key))

                    # Translated Fields
                    if key in trans_fields:
                        trans_field = get_translation_fields(field_name)
                        key_fields += tuple(f for f in trans_field)
                    # Simple Fields
                    else:
                        key_fields += (field_name,)

                new_fields += (key_fields,)

            # Normal Fields
            else:
                # Translated Fields
                if field in trans_fields:
                    trans_field = get_translation_fields(field_name)
                    new_fields += tuple(f for f in trans_field)
                # Simple Fields
                else:
                    new_fields += (field_name,)

        trans_fieldsets.append((title, {'fields': new_fields, 'classes': classes, 'description': description},))

    return trans_fieldsets


class ProxyDict(object):
    def __init__(self, name, dct):
        self._name = name
        self._dct = dct[name] = {}
        self._proxies = {}

    def __getattr__(self, name):
        if name in ('_name', '_dct', '_proxies'):
            return super(ProxyDict, self).__getattr__(name)

        if name not in self._proxies:
            if name in self._dct:
                return self._dct[name]
            self._proxies[name] = ProxyDict(name, self._dct)
        return self._proxies[name]

    def __setattr__(self, name, val):
        if name in ('_name', '_dct', '_proxies'):
            return super(ProxyDict, self).__setattr__(name, val)
        self._dct[name] = val

proxy_settings = ProxyDict('main', {})
