from django.utils.translation import ugettext_lazy as _
from django.conf import settings
from django import forms
from dengun_cms.appsettings import fields
from dengun_cms import appsettings

"""
REGISTER
register = appsettings.register(app_slug, _("App Name"))
##( "App Name" is not required )
"""

register = appsettings.register('appsettings', _('Main Settings'))


@register(main=True, readonly=False)  # can only have one main class
class Main:

    """
    This "Class Name" is the "Group Name" (in lowercase) for this app.
    in this case is "main"
    """

    """ The FormFields """
    site_name = fields.CharField(translate=True, initial='Un-named Website', label=_('Site Name'), help_text=_('The name of the website for page titles and for use around the site.'),)
    site_slogan = fields.CharField(translate=True, initial='', required=False, label=_('Site Slogan'), help_text=_('The slogan of the website for page titles and for use around the site'),)
    meta_topic = fields.CharField(translate=True, initial='Content Management.', required=False, label=_('Meta Topic'), help_text=_('Two or three words describing this type of company/website.'),)
    date_format = fields.CharField(initial='F j, Y', label=_('Date Format'), help_text=_('How should dates be displayed across the website and control panel? Using the <a target="_blank" href="http://php.net/manual/en/function.date.php">date format</a> from PHP - OR - Using the format of <a target="_blank" href="http://php.net/manual/en/function.strftime.php">strings formatted as date</a> from PHP.'),)
    records_per_page = fields.IntegerField(initial='25', label=_('Records Per Page'), help_text=_('How many records should we show per page in the admin section?'),)
    site_lang = fields.ChoiceField(initial=settings.LANGUAGE_CODE, label=_('Site Language'), help_text=_('The native language of the website, used to choose templates of e-mail notifications, contact form, and other features that should not depend on the language of a user.'), choices=settings.LANGUAGES,)
    unavailable_message = fields.CharField(translate=True, initial='Sorry, this website is currently unavailable.', required=False, widget=forms.Textarea(attrs={'class': 'ckeditor'}), label=_('Unavailable Message'), help_text=_('When the site is turned off or there is a major problem, this message will show to users.'),)

    class Meta:
        #this is the sorting for groups in this app, no required
        sorting = 1
        # this is no required
        help_text = _('Allows administrators to update settings like Site Name, messages and email address, etc.')
        verbose_name = _('Geral Configuration')
        verbose_name_plural = _('Geral Configurations')

        # this is the fields order
        fieldsets = (
            ('title 1', {
                'classes': ('collapse',),
                'fields': (('site_name'), ('site_slogan'), ('meta_topic')),
                'description': 'SEO'
            }),
            ('title 2', {
                'classes': ('collapse',),
                'fields': ('site_lang', 'date_format', 'records_per_page'),
                'description': 'Options'
            }),
            ('title 3', {
                'classes': ('collapse',),
                'fields': ('unavailable_message',),
                'description': _('Control whether this author can be seen on your frontend.')
            })
        )


@register(main=False)
class Email:

    """
    Another Group of settings for this app.
    in this case is "email"
    """

    contact_email = fields.CharField(initial='', required=False, widget=forms.EmailInput(), label=_('Contact E-mail'), help_text=_('All e-mails from users, guests and the site will go to this e-mail address.'))
    server_email = fields.CharField(initial='admin@localhost', required=False, label=_('Server E-mail'), help_text=_('All e-mails to users will come from this e-mail address.'))
    smtp_host = fields.CharField(initial='', required=False, label=_('SMTP Host Name'), help_text=_('The host name of your smtp server.'))
    smtp_pass = fields.CharField(initial='', required=False, widget=forms.PasswordInput(), label=_('SMTP password'), help_text=_('SMTP password.'))
    smtp_port = fields.IntegerField(initial='', required=False, label=_('SMTP Port'), help_text=_('SMTP port number.'))
    smtp_user = fields.CharField(initial='', required=False, label=_('SMTP User Name'), help_text=_('SMTP user name.'))
    smtp_tls = forms.ChoiceField(choices=[(True, _('Yes')), (False, _('No'))], initial=True, required=True, widget=forms.RadioSelect(), label=_("Use TLS"), help_text=_('Transport Layer Security (TLS)'))

    class Meta:
        sorting = 2
        help_text = _('Email Configuration')
        verbose_name = _('Email Configuration')
        verbose_name_plural = _('Email Configurations')

        fieldsets = (
            ('HOST mail', {
                'classes': ('collapse',),
                'fields': (('contact_email', 'server_email',), ('smtp_host', 'smtp_port', 'smtp_user',), ('smtp_pass', 'smtp_tls',),),
                'description': _('Some email configuration')
            }),
        )


"""
HOW TO USE THIS

PUT the AUTODISCOVER in your project URLS

# Load AppSettings
from dengun_cms import appsettings
appsettings.autodiscover()


################# SET FORMS, KEY - VALUES ##################

integer_field = 1 (not translated)
string_field = '2' (not translated)
float_field = 0.0 (not translated)

OR

DEFAULT FIELDS
forms.FieldInstance()

OR

FOR TRANSLATED FIELDS
Attr: translate = True
fields.FieldInstance(translate = True)

Attr
**(translate = True, initial=True, label="Title Field" required=False, choices=(('key','val')), help_text= _("number of houses"))






################ GET FORMS VALUES ##########################


# Use the TEMPLATE_CONTEXT_PROCESSORS
eg.
TEMPLATE_CONTEXT_PROCESSORS = (
    "dengun_cms.appsettings.context_processors.appsettings",
)

in template

{{ appsettings.app.group.key}}


# if your app only have one group or key is in main* Group Class of settings you don't need to pass the group

{{ appsettings.app.key}}




# Use the AppSettingsMiddleware
eg.
MIDDLEWARE_CLASSES = (
    'dengun_cms.appsettings.middleware.AppSettingsMiddleware',
)

IN REQUEST get in this way

value = request.appsettings.app.group.key

# if your app only have one group or key is in main* Group Class of settings you don't need to pass the group

value = request.appsettings.app.key




OR
IMPORT and get in views

from dengun_cms.appsettings.app import appsettings

value = appsettings.app.group.myvalue

# if your app only have one group or key is in main* Group Class of settings you don't need to pass the group

value = appsettings.app.myvalue




OR
use TEMPLATE TAG in templates

{% load appsettings_tags %}


{% appsettings app group key as myvar %}

# if your app only have one group or key is in main* Group Class of settings you don't need to pass the group

{% appsettings app key as myvar %}

"""
