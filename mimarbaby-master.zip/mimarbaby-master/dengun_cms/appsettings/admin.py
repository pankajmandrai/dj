import forms
from django.contrib import admin
from django.contrib.admin import helpers
from django.utils.translation import ugettext_lazy as _
from django.utils.encoding import force_text
from modeltranslation.admin import TranslationAdmin
from dengun_cms.appsettings.models import Setting
from dengun_cms.appsettings.settingsobj import Settings
settingsinst = Settings()
from django.contrib import messages


class SettingAdmin(TranslationAdmin):

    list_display = ('app',  'group', 'key', 'value',)

    fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('key', 'value',)}),
    )

    change_form_template = 'appsettings/admin/change_form.html'

    def __init__(self, model, admin_site):
        super(SettingAdmin, self).__init__(model, admin_site)

    def has_add_permission(self, request):
        return False

    def changelist_view(self, request, extra_context=None):
        app_list = []

        # save settings
        if request.POST:

            _forms = {}
            for app_name in sorted(vars(settingsinst).keys()):
                app = getattr(settingsinst, app_name)
                for group_name, group in app._vals.iteritems():

                    form_name = '%s_%s' % (app_name, group_name)
                    form = forms.settings_form(app=app, group=group)
                    _forms[form_name] = form(request.POST)

                    success = True
                    if _forms[form_name].is_valid():
                        _forms[form_name].save()
                    else:
                        success = False
                        errors = _forms[form_name].errors

            if success:
                self.message_user(request, "The message", level=messages.SUCCESS)
            else:
                self.message_user(request, errors, level=messages.ERROR)

        # Get settings and forms
        for app_name in sorted(vars(settingsinst).keys()):
            app = getattr(settingsinst, app_name)
            app_groups = []
            for group_name, group in app._vals.iteritems():

                if group._readonly:
                    continue

                form = forms.settings_form(app=app, group=group)

                # Set Group
                app_groups.append({
                    'name': group._verbose_name.title(),
                    'name_plural': group._verbose_name_plural.title(),
                    'description': group._help_text,
                    'sorting': group._sorting,
                    'form': form(),
                })

            # Set App
            app_list.append({
                'name': app._name,
                'title':  app._verbose_name,
                'groups': sorted(app_groups, key=lambda x: int(x['sorting'])),
            })

        obj = None
        ModelForm = self.get_form(request)
        form = ModelForm()
        adminForm = helpers.AdminForm(
            form,
            list(self.get_fieldsets(request, obj)),
            self.get_prepopulated_fields(request, obj),
            self.get_readonly_fields(request, obj),
            model_admin=self)
        media = self.media + adminForm.media
        opts = self.model._meta

        context = {
            'title': _('Edit %s') % force_text(opts.verbose_name),
            #'adminform': adminForm,
            'is_popup': False,
            'media': media,
            'app_list': app_list,
            #'inline_admin_formsets': inline_admin_formsets,
            #'errors': helpers.AdminErrorList(form, formsets),
            'app_label': opts.app_label,
            'preserved_filters': self.get_preserved_filters(request),
        }
        context.update(extra_context or {})
        return self.render_change_form(request, context, form_url='', add=False)

    class Media:
        js = (
            '/static/js/force_jquery.js',
            '/static/js/tabbed_translation_fields.js',
            '/static/ckeditor/ckeditor.js',
        )
        css = {
            'screen': ('/static/css/tabbed_translation_fields.css',),
        }

admin.site.register(Setting, SettingAdmin)
