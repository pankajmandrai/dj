from modeltranslation.translator import translator, TranslationOptions
from dengun_cms.appsettings.models import Setting


class SettingTranslationOptions(TranslationOptions):
    fields = ('value',)

translator.register(Setting, SettingTranslationOptions)
