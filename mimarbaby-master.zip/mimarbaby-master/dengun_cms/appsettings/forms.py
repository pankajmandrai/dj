from django import forms
from dengun_cms.appsettings.settingsobj import Settings, check_translate
from dengun_cms.appsettings.exceptions import FormSettingsException
from dengun_cms.appsettings.utils import get_translated_fieldsets  # , get_translation_fields,

settings = Settings()

# Set all the apps settings forms
_forms = {}
for app_name in sorted(vars(settings).keys()):
    app = getattr(settings, app_name)
    for group_name, group in app._vals.iteritems():
        if group._readonly:
            continue
        form_name = '%s_%s' % (app_name, group_name)
        _forms[form_name] = None


class Fieldset(object):
    def __init__(self, form, fields, name, description, classes):
        self.form = form
        self.fields = fields
        self.name = name
        self.description = description
        self.classes = classes

    def __iter__(self):
        """ Similar to how a form can iterate through it's fields... """
        for name in self.fields:
            if isinstance(name, (tuple, list)):
                for field in name:
                    yield self.form[field]
            else:
                yield self.form[name]

    def __getitem__(self, name):
        "Returns a BoundField with the given name."
        try:
            field = self.fields[name]
        except KeyError:
            raise KeyError('Key %r not found in Form' % name)
        return field


class FieldsetForm(forms.BaseForm):
    def __init__(self, *args, **kwargs):
        super(FieldsetForm, self).__init__(*args, **kwargs)
        self.fieldsets = []

        for name, data in self.base_fieldsets:
            fields = ()
            for field in data.get('fields', ()):
                if isinstance(field, (tuple, list)):
                    group_fields = ()
                    for group_field in field:
                        group_fields += (group_field,)
                    fields += (group_fields,)
                else:
                    fields += (field,)

            description = data['description']
            classes = data.get('classes', '')

            self.fieldsets.append(Fieldset(self, fields, name, description, classes))

    def save(self):
        for key, value in self.fields.iteritems():
            app, group, name = key.split('-')

            val = self.cleaned_data[key]

            if check_translate(name):
                setattr(getattr(settings, app)._vals[group], name, val)
            else:
                if val != getattr(settings, app)._vals[group]._vals[name].initial:
                    # Update setting
                    setattr(getattr(settings, app)._vals[group], name, val)


def settings_form(**kwargs):

    if 'app' in kwargs and 'group' in kwargs:

        app = kwargs['app']
        group = kwargs['group']
        form_name = '%s_%s' % (app._name, group._name)
        global _forms

        try:
            form = _forms[form_name]
        except KeyError:
            form = None

        if not form:
            fields = {}
            fieldsets = []

            fieldset_fields = []
            for key, value in group._vals.iteritems():
                field_name = '%s-%s-%s' % (app._name, group._name, key)

                fields[field_name] = value

            if group._fieldsets:
                fieldset_fields = get_translated_fieldsets(app, group)

            fieldsets.append(fieldset_fields)

            _forms[form_name] = type('SettingsForm_'+form_name, (FieldsetForm,), {'base_fieldsets': fieldset_fields, 'base_fields': fields})
        return _forms[form_name]
    else:
        raise FormSettingsException('app and group required')
