from django import template
#from django.utils.translation import ugettext_lazy as _
#from django.conf import settings
#from django.utils.safestring import mark_safe
from classytags.core import Tag, Options
#from classytags.blocks import BlockDefinition, VariableBlockName
from classytags.arguments import Argument  # , ChoiceArgument, Flag, MultiKeywordArgument
#from classytags.helpers import InclusionTag

#from dengun_cms import appsettings


register = template.Library()


class GetAppSetting(Tag):
    name = 'appsettings'
    options = Options(
        Argument('app', required=True, resolve=False),
        Argument('group', required=True, resolve=False),
        Argument('key', required=False, resolve=False),
        'as',
        Argument('varname', required=False, resolve=False)
    )

    def render_tag(self, context, app, group, key, varname):
        from dengun_cms.appsettings.app import appsettings
        app = getattr(appsettings, app)

        #appname.group.key
        if group and key:
            group = app._vals[group]
            key = group._vals[key]

        #appname.key
        if not key and group and len(app._vals) == 1:
            key = group
            group = app._vals.values()[0]
            key = group._vals[key]

        output = key.initial

        if varname:
            context[varname] = output
            return ''
        else:
            return output

register.tag(GetAppSetting)
