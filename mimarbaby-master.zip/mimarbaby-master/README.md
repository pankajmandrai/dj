mimarbaby
=================

## Status

Master - 
[![build status](https://gitlab.dengun.org/project/mimarbaby/badges/master/build.svg)](https://gitlab.dengun.org/project/mimarbaby/commits/master)
[![coverage report](https://gitlab.dengun.org/project/mimarbaby/badges/master/coverage.svg)](https://gitlab.dengun.org/project/mimarbaby/commits/master)

- **Name**: mimarbaby 
- **Client**: Client Name
- **Version (Project Template)**: gulped1.8
- **Urls**:
	- dev: n/a
	- prod: n/a
- **Phase (development)**: Development
- **Team**:
	- name (@gitlabtag), role, company_e-mail
- **Dates**:
	- *Development start*: YYYY-MM-DD
	- *Release*: YYYY-MM-DD
	- *Last Update*: YYYY-MM-DD
- **Languages**: *main*, secondary, ...
- **Internal Modules** (ex.: *webshop*, *properties*...): n/a 
- **Production branch**: n/a
- **Google Analytics**: no

---

## Table of contents

- [Quick setup](#quick-setup)
- [Project-specific specs](#project-specific-specs)
- [Tips and recipes](#tips-and-recipes)

## Quick setup

In order to quickly start working in your new project, follow these instructions:

```bash
git submodule init
git submodule update
```

- if previous step didn't work ( or no output was emitted ), try:

```bash
git submodule add git@gitlab.dengun.org:project/django_admin_botox_package.git
git submodule add git@gitlab.dengun.org:project/dengun_cms_package.git
```

- Finally, Docker up ! :whale:

```bash
docker-compose up
```

## Project-specific specs

These instructions are specific for this project. The steps required to set your machine up for project development in general can be found [here][mainsetup].

### Front-end setup

All front-end-related files are **stored** in the main app folder. The main app folder is the one with the **name of the project** and it's located, usually and ironically, inside ANOTHER folder sharing the name of the project :imp:! 

> It is of utmost importance to understand that **CSS and JS files** in the **assets** folder are generated automatically and must **NOT BE TAMPERED WITH DIRECTLY!**

For front-end setup, we use SASS-based magic powers for stylesheets and concatenation-based strategies for scripts. And in order to set up your front-end environment, you must follow these steps:

> If you have any trouble running any steps, please contact a member of the front-end team, like @painatalman.

1. **install nodejs**, in case you don't have it installed, yet. [Need instructions?](https://nodejs.org/) We recommend the LTS version!
> If you need to know whether nodejs is installed or not, or check its version, run the 'node -v' command on your *terminal/bash/powershell/whatever*!

2. *run the following command on your -- here we go, again! -- *terminal/bash/powershell/whatever*

```bash
npm install
```

3. After everything's installed, all you need to do is run another command -- we promise you, it's the last one!

```bash
npm start
```

This will run our task manager of choice, *gulp* and monitor .js files in your *scripts* folder and .scss files in the *sass* one!

#### Regarding stylesheets

We adopted the SASS 'language' for better organizing stylesheet rules. If you're not familiar with SASS, you may read more about it *[here][sasslang]*, or check with one of your fellow BFFs on the front-end department.

- Stylesheet rules are added to files in the *sass* folder.
- These 'partial files' names must start with an underscore '_' must also be '@import'-ed in the 'app.scss' file, the main file.

#### Regarding scripts

We use [jQuery][jquery] for DOM manipulation and all that *whatnot* cool kids use, these days! We also use [slick.js][slickjs] for creating and configuring sliders. Hence, we've **already included these libraries for you**!... Oh, and [Bootstrap scripts][bootstrapjs]! We've included that, too! 

As we're not adopting a modular workflow right now, scripts are directly concatenated. What's this, you ask? It means that scripts added directly to the 'scripts' folder are joined together into one file, in alphabetical order. 

Some notes regarding script concatenation:

- *scripts* should be included directly in the 'scripts' folder
- vendor-specific scripts (like *jquery-ui.js* or *some-kind-of-datepicker.js*) may be added to the 'scripts/vendor' folder
- the [jQuery][jquery], [slick.js][slickjs] and [bootstrap.js][bootstrapjs] libraries are already included in a concatenated 'critical.js' file, so you may use them as expected... good for you :smirk:!

### Back-end setup

Well, no need to set a virtual machine up. Docker is there to help you. There should be no trouble as long as you have Docker running.

However, you may need to [some additional commands](#tips-and-recipes) to migrate or create a superuser.

Also, you may need to [restart your web container](#restart-your-web-container) afterwards.

---

## Tips and recipes

Here are a few useful commands (mostly docker-based) you might need to run a project properly:

### Migrate with docker

```bash
docker-compose run --rm web python manage.py migrate
```

### Create super user with docker

```bash
docker-compose run --rm web python manage.py createsuperuser
```

### View logs

Sometimes, you may need to see what's going on with either your server or your node setup. Here are two commands to help with that!

```bash
docker-compose logs web
docker-compose logs node
```

### Restart your web container

```bash
docker-compose restart web
```

<!--
TODO: Replace mainsetup link, for it has changed!
-->

[bootstrapjs]: http://getbootstrap.com/javascript/
[django18]: https://docs.djangoproject.com/en/1.8/
[jquery]: https://jquery.com/
[mainsetup]: https://gitlab.dengun.org/project/project_template#about-this-manual
[sasslang]: http://sass-lang.com/
[slickjs]: http://kenwheeler.github.io/slick/