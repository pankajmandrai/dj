<TODO: First, remember to update the last revision and changelog, please>

#### Just looking for that cool command to create a new project?
Click **[here](#mounting-the-template)**

# Dengun Project Template

A manual describing the installation process for creating projects at Dengun, complete with its CMS tool. It also provides the reader with some of the motives behind some choices regarding the current workflow of the project development.

Good sense of humour is optional, but highly recommended.

## General Information

+ **Development team:** [Dengun Web Agency](www.dengun.pt)
+ **Created on:** 2015-03-23
+ **Last Revision on:** 2017-03-13
+ **Version:** 2.0.0

*Copyright 2017 Dengun Web Agency*

***

## Table of Contents

Because you're lazy and don't care about this manual at all!

1. [About this manual](#about-this-manual)
2. [Setting up your Environment](#setting-up-your-environment)
3. [Mounting the Template](#mounting-the-template)
    4. [Configuring Settings](#configuring-settings)
5. [Sync-ing the Database](#sync-ing-the-database)
6. [Extras and CMS](#extras-and-cms)
8. [Build an app](#build-an-app)
7. [Troubleshooting and FAQ](#troubleshooting-and-faq)
    2. [Site matching query does not exist](#site-matching-query-does-not-exist)
    3. [Unknown column with _en or some other language prefix in it](#unknown-column-with-_en-or-some-other-language-prefix-in-it)
    4. [SSL issue when starting a project](#ssl-issue-when-starting-a-project)
    5. [mysql_config not found](#mysql_config-not-found)
    6. [GEOS is required](#geos-is-required)
3. [Glossary](#glossary)
3. [Contacts and Support](#contacts-and-support)

***

## About this Manual

> I'm batman!

So you're the new recruit/intern? Congratulations! Welcome to the Dengun Web Development Team!

Unfortunately, we don't provide you with a complimentary cake just yet, only after you complete your first project! &mdash; *ahem, lie* &mdash; So let's get started and build your first project, shall we?

You know, back in the day, we used to have a tough time with this part: there are quite a few things to set up properly, and it's important for them to be in the proper version, otherwise results might be... unexpected. But don't worry, we now have an AMAZING template to help you out &mdash; we want our assets to be productive, after all!

But you're probably SO productive that you don't even care about this intro, right? So here's a rundown of what this manual is all about:

+ Starting a virtual environment for safe development
+ Setting up a web project in Django
+ Getting the database ready
+ Working with the Dengun CMS apps
+ Playing ping-pong

So... you know **Django**, right?

Ok, maybe not, but you DO know **Python**, correct?

**HTML** and CSS? **SASS**, maybe?

**Git**?... Git, anyone?

Nope? No problem, there are other manuals that can help you around... just not yet!
<TODO: Reference to another manual... maybe>

Also, both the project template and this document are still **ongoing development**... I have kids, you know!

------

## What you'll be doing for us

As you know :wink:, **Dengun Web Agency** is this *o-mah-gawd-its-so-cool* company that specializes in Table Tennis tournaments. Also, if a few people are to be believed, it also develops web applications &mdash; *don't know where they got that idea from, but oh well...* &mdash;. Furthermore, based on the fact that someone ~~forced you to~~ suggested you read this introduction, you'll probably be going for the latter.

I'll give you a minute to cry, here! :cry:

Now that you're over the fact that you won't be getting that "best table tennis player ever" award anytime soon, here's a *brief summary* of what we expect you to do for us:

+ build websites
+ support your teammates
+ build websites
+ be kind
+ build websites
+ do foot massages
+ build yet more websites
+ ...

Based on the fact that a few items appear more than once in this list, it is naturally expected you to be asking yourself one very simple question:

>"How the hell am I supposed to do this with no previous training?"

But don't worry! Back when this job started for us, we didn't know how to do foot massages, either and we still don't so do NOT count on us to help you there!

We CAN, however, help you get ready for developing *web applications*, and what better way to start than by briefly introducing you to the **overall workflow** and to the **tools** you'll be using?

So here's the **major plot point** of the story: for creating web apps, we use the **Django framework** &mdash; not much of a twist if you read this document's first section, but stick with us, okay? &mdash;. *[Django](http://djangoproject.com)* is a web *framework*, which is on its own a fancy name for *tool-for-creating-websites-faster*. Is is based on the Python programming language, which is kinda fun as far as programming languages go, yet requires you to structure your code in a readable and peculiar way, in order to maintain some kind of philosophy. You may check out more about that *pythonista* mumbo-jumbo at their *[official webpage](http://www.python.org)*. Regarding databases, we mostly use **MySql** here, yet thanks to the Django framework, there *probably* won't be a major factor to worry about.

And if this *framework-django-and-database-and-also-git-whatever* talk has been not much more than gibberish to you, then you're probably here as a **FRONT-END** web developer. Good for you, as you'll be doing *HTML layouts*, *CSS styles* and *Javascript... scripts*...

... except for the fact that you'll be using *SASS/SCSS* for styling. Don't worry: you'll love it if you've never used it, yet... oh, and *[Bootstrap 3](www.bootstrap.com)*! We use it for setting up grids, and buttons, and some components every **web designer needs**. Also, we're kind of *bffs* with *jQuery*, and you're probably glad we took that option!

Either way, whether you're a *back-end* or *front-end* developer, chances are you'll be the one responsible for **creating a new project**. And even if you're not, you need to **set up your machine** for working on the project, anyway.

And that's the main reason this document exists!

Just be glad you haven't gotten to the part where we tell you that you MUST use [Git](www.git.org) AND have a [GitLab](gitlab.dengun.org) account in order to update your project remotely, for it is the service we use to update projects in a collaborative and coordinated way... you DO have [Git](www.git.org) installed, and DO have a [GitLab account set up](gitlab.org), don't you?

<!-- TODO: link to the Gitlab set up instructions -->

## Setting up your environment

Before setting up the project, you must first set up your machine for proper development... and make sure python is installed. To do so, write the following line in your terminal (with an uppercase 'V'):

```bash
python -V
```

If it works, this will output a number corresponding to the python version you're using (like 2.7.3). Then, check if it is version 2.7. If it is, let's move on. Otherwise, install python 2 first. At https://www.python.org/, you will find instructions for installing python.

Please note that most of these instructions are intended at Linux and MacOSX users. Although the processes can be adapted to Windows operating systems, we highly recommend that you install a Linux-based operating system like [Ubuntu](http://www.ubuntu.com/) or [Mint](http://linuxmint.com/).

We also recommend that you install the [Sublime Text](http://www.sublimetext.com/) text editor: it's quite popular around these parts. More info and tips for using Sublime Text as a sophisticated and optimized work tool can be found in a document... that does not exist, yet!

<TODO: add that document>

### About this so-called "environment"

Well you can't have life without an environment, can you? We're doing the same thing to you. Trust us, this will ease your work and allow you to better separate it from other activities. It's a win-win situation &mdash; for us, at least!

But first, we **highly** suggest you install the following components:

+ *pip* &mdash; a python package manager to easily install extensions for python, like django or virtualenv
+ *virtualenv* &mdash; an extension to create virtual environments
+ *virtualenvwrapper* &mdash; it makes managing virtual environments that much easier

### And a virtual environment is...

Basically, a virtual environment is, in the context of python, a python configuration in which you install stuff specific for a certain context. Imagine for example that you have projects in both django 1.5 and django 1.8, and they only work in their proper versions &mdash; it happens a lot, trust us! &mdash;. In this case, you should have a virtual environment in which python uses django 1.5, and another separate one in which it uses django 1.8. This only gets worse when extensions are involved, as there are always incompatibilities that can be unexpected and, thus, quite a headache!

### Setting up a python environment... finally!

There is a high probability that you already have pip installed, so try installing virtualenv in your command line (might require sudo):

```sh
pip install virtualenv
```

If it does not work, you might have to install pip first. A nice tutorial can be found at https://pip.pypa.io/en/latest/installing.html.

After virtualenv is installed &mdash; you may want to write 'pip freeze' in the command line to see which packages are installed &mdash;, it's time to install virtualenvwrapper. Trust us, it may be tough to configure, but it will be worth in in the long run.

Step one is installing it, of course:

```python
pip install virtualenvwrapper
```

Then, you will have to configure your environment variables for the shell you'll be using (it is a ~/.bashrc, ^/.profile or something). If you are on a mac or linux, these lines must be added at the end of the file:

    export WORKON_HOME=$HOME/.virtualenvs
    export PROJECT_HOME=$HOME/Devel
    source /usr/local/bin/virtualenvwrapper.sh

To edit this file with sublime text, you could write this in the command line:

```bash
sudo <vim> ~/.bashrc
```
\<vim\> can be replaced with another text editor, like *gedit*, *nano* or even *sublime_text* by creating a [soft link](https://scotch.io/tutorials/open-sublime-text-from-the-command-line-using-subl-exe-windows).

<!-- TODO: add reference to link -->

So, we suggest you create a virtual environment for your first projects here at django, or each project based on the django version it uses. As we currently use **django 1.8**, you could do something like:

```bash
mkvirtualenv django1.8
```
... or whatever you want to call it. And then run:

```bash
workon django1.8
```
... to start working on a virtual environment. Make sure that you have the virtual environment name in parenthesis (), because you're not in your virtual environment otherwise.

To list all the environments, you just need to write "workon" in the command line. Might be useful if you create too many, for some reason... or go on holidays.

And FINALLY, it's time to install all the needed requirements to run a django project with the CMS developed by Dengun.

To do that, ~~copy all the package names below to a file called requirements.txt~~ we provide a requirements.txt file, that has all the dependencies you'll need to install for setting up your django environment. So you may just run the following command, with the virtual environment enabled:

```bash
pip install -r requirements.txt
```

This command expects requirements.txt to be in the folder you're currently in, and that the file with the package names and versions is called *requirements.txt*.

And you should be done and ready for the next step... hopefully!

#### This docker thing...

Soon enough &mdash; we hope... &mdash;, all this setup thing will be eased with the use of Docker. However, it is still a method in an experimental state and with some issues, so it won't be approached in this guide, just yet!

#### References

<TODO: add references>

+ Python
+ Pip
+ Virtualenv
+ Virtualenvwrapper

---

## Mounting the template

You know Django by now... don't you?

Let's suppose you do. So here's what your REALLY want to do &mdash; drumroll, please:

```bash
django-admin.py startproject --template=https://gitlab.dengun.org/project/project_template/repository/archive.zip?ref=dengun_standards_2017 -e="py,md,gitmodules,json,yaml,yml,pip,env,txt" <project_name>﻿
```

with \<project_name\> being the name of your project. 
And please, PLEASE **read the special note** below before naming anything!

#### Notes regarding project name

There are a few **limitations** you should be aware of when naming your new project. Please note that breaking even ONE of these rules may result in a "capital penaly from a sysadmin". It is the worst type of punishment we have here, right after having to watch "Batman and Robin"... twice!

##### The actual rules for naming a project

+ Thou shall **NOT use -.** Instead, opt for an underscore character: _
+ Thou shall **NOT use caps**... please!

---

Now that this is all set up &mdash; you remebered to install the virtual environment, didn't you? &mdash;, it's time to configure your own settings.

### Configuring settings

As the name implies, we are going to configure a few settings here. As you know, all links to databases and other technologies to be used by the Django project are to be defined in the *settings.py* file. At dengun, we also use another configuration file, to be specificed for local development by each developer involved: the *settings_local.py* file.

So if everything turns out great, all you'll need to configure is in the settings_local file:

+ database username and password

### Local and global?

Imagine that, for some reason, one developer decides to use an additional extension for his "local copy" of the project, like the great [django-extensions](), which is great for debugging and live-reloading on the backend side. When the site gets online &mdash; and believe us, it won't be just once! &mdash;, this is not necessary. As a matter of fact, this won't go with the DEBUG setting defined as True, as well. This would involve **constant changes** in the settings.py file, so why not just have a settings.py file for the global settings (to be used in the server and/or that are the same to everyone), and another file that get everything from the global settings.py file and adds/changes stuff to if according to each developer's needs?

One might just place this line in the *settings_local.py* file, at the bottom (describing the case above):

```python
INSTALLED_APPS += ("django_extensions" , )
```

And since we can do this in django (just check your *manage.py* file), it makes life easier for ~~the sysadmin~~, everyone. Also, remember that each developer must have an instance of the database engine running, and might &mdash; should :smiling_imp: &mdash; have different usernames and passwords to run it! All thanks to this line, at the beginning of settings_local:

```python
from settings import *
```

... and this one, on the manage.py file:

<TODO: add examples>

Other advantages include (examples coming soon):

+ Mailtrap setup
+ Setting up the PROJECT_URL variable to run the project locally but also allow others to see it

```python
PROJECT_URL = "http://localhost:8000"
# PROJECT_URL = "http://<your.local.ip.address>:8000" # Run localhost with your local IP
```

Remember: *settings_local.py* is yours and yours only, it is **not** to be sent to the remote repository (gitlab, github, git-whatever...) or tracked by git (it is one of the reasons we have a .gitignore file, after all).

---

## Sync-ing the database

Note that, in the settings file (or settings_local), the expected database name is \<project_name\>_db, with \<project_name\> being the name of the project you just made. So it is suggested that a new database schema is created, with this name. For a project named "awesome", the database to be created would be "awesome_db". The tables for models, and administration stuff and everything else, however, is done in an entirely different way.

After creating your database schema, run this line in the folder where your manage.py file is located:

```bash
python manage.py syncdb
```

If you don't have a database schema set up, you'll probably get an error with code 1049:

```bash
django.db.utils.OperationalError: (1049, "Unknown database 'project_name_db'")
```

Otherwise, you'll be asked whether you want to create an administrator account or not. Please do, and remember the username and password, they'll be useful for later on.

If, for some reason, an admin account is not created, one can do so by running this command

```bash
python manage.py createsuperuser
```

### Languages, much languages...

> Note: this sections is related mostly to the cms-related parts of the project, and not to the translation of custom models

### MyPages

So your *MyPages* project was supposed to have more than one language? Not a problem &mdash; yet!

First of all, go to your *settings.py* file and find something similar to this:

```python
MYPAGES_HAS_LANGUAGES = True

# Local time zone for this installation. Choices can be found here:
# http://en.wikipedia.org/wiki/List_of_tz_zones_by_name
# although not all choices may be available on all operating systems.
# In a Windows environment this must be set to your system time zone.
LANGUAGE_CODE = 'pt'

MODELTRANSLATION_TRANSLATION_REGISTRY = "delta_force.translation"
MODELTRANSLATION_DEFAULT_LANGUAGE = LANGUAGE_CODE
MODELTRANSLATION_FALLBACK_LANGUAGES = (LANGUAGE_CODE,)
MODELTRANSLATION_AUTO_POPULATE = True

gettext = lambda s: s
LANGUAGES = (
    ('pt', gettext('Portuguese')),
    ('en', gettext('English')),
    #('es', gettext('Spanish')),
    #('fr', gettext('French')),
)
```

It's the **LANGUAGES** part that matters most, here! You see those ('language_short_code', gettext('Language')) items? Those are your languages! Each one has a specific LANGUAGE_CODE (which will come in handy later), and you just need to add a line inside the brackets of the *LANGUAGES = ( )* variable &mdash; because that's how tuples work, not our fault!

The line **('en', gettext('English'))**, for example adds the english language with a language code of 'en'. Easy, no?

And yet there is a chance this might **not work yet** &mdash; *SPOILERS*: it probably won't!

Well, that's because you must *sync* your fields according to these languages. For mypages, the following command should work:

```bash
python manage.py sync_translation_fields
```

And then answer *y* to everything... hopefully!

#### References

+ MySql
+ MySql Workbench

## Extras and CMS

You're ready to embrace the AMAZING power of our Content Management System: the *Dengun CMS*.

<TODO: a brief explanation of the cms backoffice, illustrated>

This might get you all set up for using the Dengun Content Management System's main tools, but you might want to use more of them:

+ Photologue &mdash; for managing photo uploads and sizes
+ Featured &mdash; for sliders and galleries that are MyPages-compatible
+ Blog &mdash; we'll let you take a guess regarding this one!
+ Testimonials &mdash; testimonial blocks for MyPages-compatible pages

In order to use these resources, make sure they're included in the INSTALLED_APPS of the settings.py (not settings_local.py):

```python
INSTALLED_APPS = (
    # ...
    # DENGUN CMS
    'dengun_cms.core',
    'dengun_cms.contrib.admin_relation',
    'dengun_cms.contrib.treeadmin',
    'dengun_cms.mypages',
    'dengun_cms.media',
    'dengun_cms.featured',
    'dengun_cms.blog',
    'dengun_cms.testimonials',
    # ...
)
```

For *photologue* and *featured*, a few additional commands must be run in the project folder (where the *manage.py* file is at).

First of all, a *migration* must be run (more on migrations soon).

```bash
python manage.py loaddata cms
```

## Build an app

Congratulations, again! You are now ready to work for us. Try running this...

```bash
python manage.py runserver
```

... everything looks cool, right? Try viewing http://localhost:8000/admin and... admin works... but maybe you need more than a simple mypage application, right?

You have the project, but now you need to build apps for the project. That's how Django is built. So let's create our app:

```bash
python manage.py startapp <app_name>

```
with \<app_name\> being our... app's name!

And now add it to the INSTALLED_APPS of the settings.py file, at the end.

```python
INSTALLED_APPS = (
    # ...
    "app_name"
)
```

---

## Regarding deployment...

Fair enough, you probably won't be deploying websites here, that's a job for one of our sysadmins. However, It is YOUR project, so need to tell the system administrator of some special conditions required for a smooth website deployment:

+ Does your app *use MyPages*? Probably yes! Remember to tell him to create a "mypages_templates" folder at the project app
+ Does it use any kind of media and stuff? Again: Probably yes! Ask him to do a *python manage.py loaddata cms* command (it only needs to run once)
+ Does it use a slider or something from the featured app? Ask him to do a *python manage.py loaddata featured* command (it only needs to run once)
+ Does your app have new migrations or stuff to be synced? Remember to tell him that, as well, for it might require a *python manage.py syncdb* or *python manage.py migrate* command.

### Settings.py configurations

Also, did you configure your settings.py file properly?

+ Did you include your own name and email into the ADMIN settings? This is important for getting error reports!

```python
ADMINS = (
    ('Dengun Backend Entry Point', 'backend@dengun.com'),
    ('A Person', 'aperson@dengun.com'),
    ('Another Person', 'anotherperson@dengun.com'),
)
```

+ Just delete or comment this altogether, if image uploads are not working properly!

```python
# PHOTOLOUGE SETTINGS
def image_file_namer(instance, filename):
    import hashlib
    m = hashlib.md5()
    key = "%s_%s" % (SECRET_KEY, filename.encode('utf-8').strip())
    m.update(key)
    ext = filename.split('.')[-1]
    return 'media/{}.{}'.format(m.hexdigest(), ext)

PHOTOLOGUE_PATH = image_file_namer
#PHOTOLOGUE_MAXBLOCK = 256*3048
```

## Troubleshooting and FAQ

###### But mostly troubleshooting...

A section dedicated to frequent questions, doubts and difficulies that can come up along your journey into the Dengun workflow.

---

#### Site matching query does not exist

If you come across a problem like this:

That might be because in the django.sites &mdash; something django uses to monitor sites, or something... &mdash; is not filled. Maybe it was due to a syncdb done way too soon, or something else... anyway, make sure these steps are filled:

1. You have SITE_ID = 1 in the *settings.py* file
2. Make sure you have *"django.contrib.sites"* in the INSTALLED_APPS of the *settings.py* file
3. Go check if there is a "django_site" table in the database, and add a column to it with the values "1" for "id", and "localhost:8000" for the other two:

<TODO: add picture>

* If this does not work, follow the two first steps, delete the database and run syncdb again in the project folder (where the *manage.py* file is):

```bash
python manage.py syncdb
```

---

#### Unknown column with _en or some other language prefix in it

So you might have come across an error kinda like this:

> OperationalError: (1054, "Unknown column 'mypage.title_en' in 'field list'")

Let me guess: you just added a new language and then *syncdb*-d &mdash; see what I did there? :curious: &mdash; it like crazy! And yet nothing! How does a man update those languages?!

Using the following command, that is!

```bash
python manage.py update_translation_fields
```

And then, you just answer *y* to whatever they ask you... probably!

---

#### SSL issue when starting a project

So you might have come across an error like this, while trying to start a project with `django-admin startproject`:

> CommandError: couldn't download URL https://gitlab.dengun.org/project/project_template/repository/archive.zip?ref=django1.8 to archive.zip?ref=django1.8: [Errno socket error] [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed (_ssl.c:590)

The problem is that the OS doesn't recognize the new certificate authority **Letsencrypt**. 

To solve this, We have to **add it** on the root trust certificate.

On the following [link](https://letsencrypt.org/certs/lets-encrypt-x3-cross-signed.pem.txt), we have the certificate key to put on the gitlab.crt file.

Then, on the terminal, you must run the following commands (let's use the batcomputOr as an example):

```bash
batman@batcomputor:~$ cd /usr/local/share/ca-certificates
batman@batcomputor:/usr/local/share/ca-certificates$ sudo vim gitlab.crt
batman@batcomputor:/usr/local/share/ca-certificates$ sudo update-ca-certificates
Updating certificates in /etc/ssl/certs...
1 added, 0 removed; done.
Running hooks in /etc/ca-certificates/update.d...
done.
```

*Voilá*!

--- 

#### mysql_config not found

This may happen to you while attempting to install some mysql-related stuff. You're probably having trouble installing **MySQL-python**, a package commonly referred to in *requirments.txt* files. 
Chances are your *mysql_config* variable, commonly used by MySQL Server (as it seems :imp:), is not set yet!

Since this error is most common in Linux platforms, maybe you should try installing this library:

```bash
$ sudo apt-get install libmysqlclient-dev
```

On a side note, do you ACTUALLY have MySQL Server installed? You may want to check out more **[here](http://stackoverflow.com/questions/7475223/mysql-config-not-found-when-installing-mysqldb-python-interface)**.

---

#### GEOS is required

Chances are you got this error while trying to run a specific project for the first time:

```bash
django.core.exceptions.ImproperlyConfigured: GEOS is required and has not been detected. Are you sure it is installed? See also https://docs.djangoproject.com/en/1.8/ref/contrib/gis/install/geolibs/
```

As the error suggests, you may need to install something for those GeoSpatial... 'thingies' &mdash; dunno why, really!

The best course of action here is to actually follow these instructions [here](https://docs.djangoproject.com/en/1.8/ref/contrib/gis/install/geolibs/)... and yes, this is the link mentioned in the above error message, so this may feel a bit redundant.

And yes, their suggestion is also our recommended course of action:

```bash
sudo apt-get install binutils libproj-dev gdal-bin
```

<!-- TODO: add more info regarding mac and windows-based systems -->

---

#### In production, we have...
TODO: complete this question!

##### Where can I buy good pizza?
At Montenegro, at the Le Coq restaurant.

##### I'm batman
Good for you!

---

## Glossary

| Term | Meaning | Referenced in |
|------------|---------|-------|
|batman|A goddamn superhero|[About](#about-this-manual)

---

## Contacts and Support

* [Dengun Web Agency][dengun]*

<!-- ----------------------------------------------- SOME REFERENCE LINKS ------------------------------------------------------ -->

[dengun]: http://www.dengun.pt