from django.apps import AppConfig


class PriceappConfig(AppConfig):
    name = 'priceapp'
