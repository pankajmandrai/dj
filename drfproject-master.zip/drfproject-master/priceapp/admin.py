from django.contrib import admin
from .models import PricingPlan,PricingPlanOption

admin.site.register(PricingPlan)
admin.site.register(PricingPlanOption)

