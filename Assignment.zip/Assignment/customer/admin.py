from customer import models
from django.contrib import admin
# Create your models here.

class RegistrationModelAdminClass(admin.ModelAdmin):
    list_display = ['id','username','password']
admin.site.register(models.RegistrationModelClass,RegistrationModelAdminClass)

class CustomerModelAdminClass(admin.ModelAdmin):
    list_display = ['first_name','last_name','email','mobile','password']
admin.site.register(models.Customer,CustomerModelAdminClass)


