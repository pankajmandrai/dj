from django.db import models

class RegistrationModelClass(models.Model):
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=20)

class Customer(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length= 20)
    email = models.EmailField(max_length=50)
    mobile = models.IntegerField()
    password = models.CharField(max_length=20)