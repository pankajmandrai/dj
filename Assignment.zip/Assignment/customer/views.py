from django.shortcuts import render
from customer import models
from .models import Customer

def showLogin(request):
    if(request.method == 'GET'):
        return render(request,"customer/login.html")

    if (request.method == 'POST'):
        username = request.POST.get('username')
        password = request.POST.get('password')
        models.RegistrationModelClass.objects.get_or_create(username=username, password=password)
        return render(request, 'customer/welcome.html')

    else:
        myDict = {'errorMessage': 'Invalid Credentials', 'color': 'red'}
        return render(request, 'customer/login.html', context=myDict)


def showIndex(request):
    res = Customer.objects.all()
    print(res)
    return render(request,"customer/thank.html")

def custView(request):
    if(request.method == 'GET'):
        return render(request,"customer/customer.html")

    if (request.method =='POST'):
        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        email = request.POST.get("email")
        mobile = request.POST.get("mobile")
        password= request.POST.get("password")
        models.RegistrationModelClass.objects.get_or_create(first_name=first_name, last_name=last_name, email=email, mobile=mobile,password=password,)
        return render(request,'customer/thank.html')

    #e1 = Customer(first_name=first_name, last_name=last_name, email=email, mobile=mobile,password=password,)
    #e1.save()
    else:
        myDict = {'errorMessage': 'Invalid Credentials', 'color': 'red'}
        return render(request, 'customer/customer.html', context=myDict)