from datetime import datetime
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.utils.decorators import method_decorator
from django.views.generic import View

from .forms import ProfileForm
from .models import Person


# @method_decorator(login_required, name='dispatch')
class ProfileInfo(View):
    form_class = ProfileForm
    template_name = 'settings/profile.html'

    def get(self, request):
        person = get_object_or_404(Person, pk=request.user.id)
        form = self.form_class(instance=person)
        data = {}
        data['form'] = form
        return render(request, ProfileInfo.template_name, data)

    def post(self, request):
        person = get_object_or_404(Person, pk=request.user.id)
        form = ProfileForm(request.POST, instance=person)
        if form.is_valid():
            person = form.save(commit=False)
            person.save()
        return redirect('/dashboard/')

    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)
