from django.db import models
from django.contrib.auth.models import User

class Person(User):
    GENDER = (('m', 'Male'),
              ('f', 'female'))
    HOBBIES = (('cricket', 'Cricket'),
               ('football', 'Football'),
               ('chess', 'Chess'),
               ('carrom', 'Carrom'))
    DEGREE = (('be', 'B.E.'),
              ('me', 'M.E.'),
              ('ca', 'C.A.'))
    phoneNo = models.PositiveIntegerField(blank=True, null=True)
    hasProfileInfo = models.BooleanField(default=False)
    fatherName = models.CharField(max_length=100,null=True)
    motherName = models.CharField(max_length=100,null=True)
    dateOfBirth = models.DateField(null=True)
    gender = models.CharField(max_length=1, choices=GENDER,null=True)
    hobbies = models.CharField(max_length=100, choices=HOBBIES,null=True)
    degree = models.CharField(max_length=100, choices=DEGREE,null=True)






