from django.contrib import admin

# Register your models here.
from person.models import Person

class PersonAdmin(admin.ModelAdmin):
    list_display = ['email', 'gender', 'dateOfBirth']

admin.site.register(Person, PersonAdmin)
