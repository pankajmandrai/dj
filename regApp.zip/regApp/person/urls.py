
from django.urls import path

from person.views import ProfileInfo


urlpatterns = [
    path('', ProfileInfo.as_view(), name='profilePage'),

]
