from datetime import datetime
from django import forms
from django.utils.translation import gettext_lazy as _
from person.models import Person



class ProfileForm(forms.ModelForm):
    # father_name = forms.CharField(label='Father Name', max_length=100)
    # mother_name = forms.CharField(label='Mother Name', max_length=100)
    # dateOfBirth = forms.DateField(label='What is your birth date?',widget=forms.SelectDateWidget)
    # GENDER_CHOICES = (('M', 'Male'), ('F', 'Female'))
    # gender = forms.CharField(widget=forms.RadioSelect(
    #     choices=GENDER_CHOICES),max_length=128)
    # hobbies = forms.CharField

    class Meta:
        model = Person
        fields = ('fatherName', 'motherName', 'gender', 'hobbies', 'degree', 'dateOfBirth')
        widgets = {
            'gender': forms.RadioSelect(attrs={'class' : 'gender'}),
            'dateOfBirth': forms.DateInput(attrs={'placeholder': "Date of Birth", 'type':"date"}),
        }
        labels = {
            'fatherName': _('Father Name'),
            'motherName': _('Mother Name'),
            'dateOfBirth': _('Date Of Birth'),
        }
