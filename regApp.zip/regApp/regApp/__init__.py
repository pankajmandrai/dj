# import pymysql
# # install pymysql as mysql database driver.
# pymysql.install_as_MySQLdb()
