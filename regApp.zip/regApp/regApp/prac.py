def myPalindrome(kwargs):
    klist = []
    vlist = []
    for k,v in kwargs.items():
        klist.append(k)
        vlist.append(v)

    print(klist)
    print(vlist)
    # list = []
    # for x,y in kwargs:
    #     list.append(y)
    # return list

    # name1 = name[::-1]
    # if(name.lower() == name1.lower()):
    #     return True
    # else:
    #     return False

dict = {'a.txt':'Rahul','b.txt':'Parbat','c.txt':'Rahul','d.txt':'Parbat'}
myPalindrome(dict)