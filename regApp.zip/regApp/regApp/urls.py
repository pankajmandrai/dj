from django.contrib import admin
from django.urls import path
from registrationapp import views
from django.views.generic import TemplateView
from django.conf.urls import include
from dashboard.views import dashboard

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/',include('django.contrib.auth.urls')),
    path('',include('registrationapp.urls')),
    path('',TemplateView.as_view(template_name='regapp/index.html')),
    path('dashboard/', dashboard, name = 'dashboard'),
    path('loginbtn/',views.validateLogin),

    path('person/', include('person.urls')),
]
