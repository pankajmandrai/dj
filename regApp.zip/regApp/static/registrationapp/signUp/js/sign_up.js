$('#signupBtn').click(function (e) {
     e.preventDefault();
     if(isSignUpFormValid()){
         $.post('/signup/',$('#my-signup-form').serialize())
             .done(function (data) {
                 if(data.success) {
                     window.location.href =  window.location.origin + data.redirect;

                 } else {
                    $('.formError').html('Email already exists..!')
                     $(window).scrollTop(0);
                 }
             })
             .fail(function (myError) {
                 alert('error : '+myError)
             })
            console.log('val success');

     } else {
          $(window).scrollTop(0);
         console.log('some error');
     }
});

function isSignUpFormValid() {
    isValid = true
    fname = $('[name=fname]')
    lname = $('[name=lname]')
    email = $('[name=email]')
    phone = $('[name=phone]')
    password = $('[name=password]')
    cpassword = $('[name=cpassword]')

    //First Name validation code
    if (fname.val().length < 3) {
        $('.fnameErrorClass').html('Name must contains min 3 alphabets..!')
        isValid = false
    }else{
        fres = /^[a-zA-Z]+$/.test(fname.val())
        if(fres){
             $('.fnameErrorClass').html('')
        }else{
            $('.fnameErrorClass').html('Name contains only alphabets..!')
             isValid = false
        }
    }


    //Last Name validation code
    if(lname.val().length < 3) {
        $('.lnameErrorClass').html('Last Name must contains min 3 alphabets..!')
        isValid = false
    }else{
        lres = /^[a-zA-Z]+$/.test(lname.val())
        if(lres){
            $('.lnameErrorClass').html('')
        }else{
            $('.lnameErrorClass').html('Last Name contains only alphabets..!')
             isValid = false
        }
    }

    //Email validation code
    if(email.val().length<=0){
        $('.emailErrorClass').html('Email field is mandatory..!');
        isValid = false;
    }else{

        var reg = /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/;
        // var reg = /^[^@]+@[a-zA-Z0-9._-]+\\.+[a-z._-]+$/;
        eres = reg.test(email.val())
        if(eres || 1){
             $('.emailErrorClass').html('');
        }else{
             //$('.emailErrorClass').html('Please provide valid email address..!');
             isValid = false
        }
    }

     //Phone validation code
    if(phone.val().length<10){
        $('.phoneErrorClass').html('Required min 10 digits..!')
        isValid = false
    }else{
        if(phone.val().length>10){
            $('.phoneErrorClass').html('Required max 10 digits..!')
            isValid = false
        }else{
            var reg = /^\d{10}$/;
            pres = reg.test(phone.val())
            if(pres){
                 $('.phoneErrorClass').html('')
            }else{
                 $('.phoneErrorClass').html('Please enter valid Phone no..!')
                 isValid = false;
            }
        }
    }
    //Password and Confirm password validation code
    passwordv = password.val()
    cpasswordv = cpassword.val()

    if(passwordv.length < 4 && cpasswordv.length < 4){
         $('.passwordErrorClass').html('Min 4 characters required..!')
         $('.cpasswordErrorClass').html('Min 4 characters required..!')
         isValid = false;
    }else{
        if(passwordv.length >= 4 && cpasswordv.length < 4){
         $('.passwordErrorClass').html('')
         $('.cpasswordErrorClass').html('Min 4 characters required..!')
         isValid = false;
        }else{
            if(cpasswordv.length >= 4 && passwordv.length < 4){
            $('.passwordErrorClass').html('Min 4 characters required..!')
            $('.cpasswordErrorClass').html('')
            isValid = false;
            }else{
                if(passwordv.length >= 4 && cpasswordv.length >= 4){
                    if(passwordv == cpasswordv){
                        $('.passwordErrorClass').html('')
                        $('.cpasswordErrorClass').html('')
                        $('.cpasswordMismatchErrorClass').html('Password Matched..!')
                    }else{
                        $('.passwordErrorClass').html('')
                        $('.cpasswordErrorClass').html('')
                        $('.cpasswordMismatchErrorClass').html('Password Doest not matched..!')
                        isValid = false;
                    }
                }

            }
        }
    }

    return isValid

}

/*if(passwordv.length < 4){
         $('.passwordErrorClass').html('Min 4 characters required..!')
         isValid = false;
    }else{
        $('.passwordErrorClass').html('')
    }

    if(cpasswordv.length < 4){
         $('.cpasswordErrorClass').html('Min 4 characters required..!')
         isValid = false;
    }else{
        $('.cpasswordErrorClass').html('')
    }
    console.log(passwordv)
    console.log(cpasswordv)
    if(passwordv == cpasswordv){
     $('.passwordErrorClass').html('Hurray matched!')
    }else{
        $('.passwordErrorClass').html('Password MisMatched!')
        isValid = false;
    }
*/