$('#postSubmit').click(function(e) {
    e.preventDefault();
    var message = $('#message').val();
    var csrfToken = $('[name=csrfmiddlewaretoken]').val();
    if (!message) {
        $('.success').html('');
        $('.error').html('Please enter message here..!!')
        return;
    }

    $.post('/posts/post-chat', {'message': message, 'csrfmiddlewaretoken': csrfToken})
    .done(function (data) {

//        var html = $.tmpl('#postRowTemplate', data).get();
var html = $("#postRowTemplate").tmpl(data).appendTo("#postLists");

        $('#postLists').html(html);
        $('#message').val('');
        $('.success').html('success..!!');
        $('.error').html('');
    })
    .fail(function (error) {
        $('.success').html('');
        $('.error').html(error);
    })
})