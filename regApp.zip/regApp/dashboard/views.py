from person.models import Person
from django.shortcuts import render, redirect


def dashboard(request):
    template_name = 'regapp/dashboard.html'
    person = Person.objects.get(id=request.user.id)
    if (not person.hasProfileInfo):
        return redirect('profilePage')
    data = {
        'name': ''
    }
    return render(request, template_name, context=data)
