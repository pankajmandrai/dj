from django.apps import AppConfig


class RegistrationappConfig(AppConfig):
    name = 'registrationapp'
