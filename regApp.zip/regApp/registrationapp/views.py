import json
from django.contrib.auth import authenticate,login
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.urls import reverse

from person.models import Person

def validateLogin(request):
    print('Login btn clicked..!')
    emailv = request.POST.get('email')
    passwordv = request.POST.get('pass')
    if(emailv == '' and passwordv == ''):
        myDict = {'errorMsgEmailKey':'Please enter email id..!','errorMsgPasswordKey': 'Please enter password..!'}
        return render(request,'registration/login.html',context=myDict)
    elif(passwordv == ''):
        myDict = {'errorMsgPasswordKey': 'Please enter password..!','emailKey':emailv}
        return render(request, 'registration/login.html', context=myDict)
    elif (emailv == ''):
        myDict = {'errorMsgEmailKey': 'Please enter email id..!','passwordKey':passwordv}
        return render(request, 'registration/login.html', context=myDict)
    else:
        user = authenticate(username = emailv,password = passwordv)
        if(user is None):
            myDict = {'successMsg': 'Invalid credentials','passwordKey':passwordv,'emailKey':emailv}
            return render(request, 'registration/login.html', context=myDict)
        else:
            login(request,user)
            person = Person.objects.get(id = request.user.id)
            if(person.hasProfileInfo):
                return redirect('/dashboard/')
            else:
                return redirect('profilePage')

def showSignUp(req):
    if(req.method == 'POST'):
        fnamev = req.POST.get('fname',None)
        lnamev = req.POST.get('lname',None)
        emailv = req.POST.get('email',None)
        phonenov = req.POST.get('phone',None)
        passwordv = req.POST.get('password',None)
        print(fnamev)
        print(lnamev)
        print(emailv)
        print(phonenov)
        print(passwordv)
        try:
            onePersonDbRow = Person.objects.get(email=emailv)
        except Person.DoesNotExist:
            onePersonDbRow = None
        if(onePersonDbRow):
            data = {'success':False,'msg':'Email already exists..!'}
            jd = json.dumps(data)
            return HttpResponse(jd,content_type='application/json')
        else:
            person = Person(
                first_name=fnamev,
                last_name=lnamev,
                email=emailv,
                password=passwordv,
                phoneNo=phonenov,
                username=emailv
            )
            person.set_password(passwordv)
            person.save()
            MyUser = authenticate(username=emailv,password = passwordv)
            print (MyUser)
            login(req,MyUser)
            dict = {'success': True, 'redirect': reverse('profilePage')}
            jd = json.dumps(dict)
            return HttpResponse(jd, content_type='application/json')

    if req.user.is_authenticated:
        return redirect('/dashboard/')

    return render(req,'registration/sign_up.html')
