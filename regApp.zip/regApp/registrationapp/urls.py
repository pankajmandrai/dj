from django.urls import path
from registrationapp import views
urlpatterns = [
    path('signup/',views.showSignUp,name = 'signup'),
    #path('signup/',views.ShowSignUp.as_view()),
    ]