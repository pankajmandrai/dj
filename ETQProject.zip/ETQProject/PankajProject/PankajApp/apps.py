from django.apps import AppConfig


class PankajappConfig(AppConfig):
    name = 'PankajApp'
