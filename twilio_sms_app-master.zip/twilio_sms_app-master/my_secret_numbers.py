# Hidden numbers

Cell_number = '+916363026769'
AUTH_TOKEN = 'c1c87483a0d100ecd2bc9c1faf6042ea'
