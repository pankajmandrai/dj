from django.contrib import admin
from PankajApp import models

class RegistrationModelAdminClass(admin.ModelAdmin):
    list_display = ['id','userName','password']
admin.site.register(models.RegistrationModelClass,RegistrationModelAdminClass)