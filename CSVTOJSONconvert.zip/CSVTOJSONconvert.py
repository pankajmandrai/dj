import json
import pandas as pd

df = pd.read_csv('data.csv')

def get_nested_rec(key, grp):
    rec = {}
    rec['BaseURL'] = key[0]
    rec['Level 1 - ID'] = key[1]
    rec['Level 1 - URL'] = key[2]
   # rec['Level 2 - ID'] =key[3]
   # rec['Level 2 URL'] =key[4]
   # rec['Level 3 - ID'] =key[5]
   # rec['Level 3 URL'] =key[6]


    for field in ['Level 1 - Name','Level 2 - Name',
                  'Level 3 - Name'
                  ]:
        rec[field] = list(grp[field].unique())

    return rec

records = []
for key, grp in df.groupby(['BaseURL','Level 1 - ID','Level 1 - URL',
                         #  'Level 2 - ID','Level 2 URL',
                          #  'Level 3 - ID','Level 3 URL'
                            ]):
    
    rec = get_nested_rec(key, grp)
    records.append(rec)

records = dict(data = records)

print(json.dumps(records, indent=4))
